### Figures across DBH classes for HJA-CNDD study


ests1 = list()
ests2 = list()
gests1 = list()
gests2 = list()
dbh = list()
dbh[[1]] = 10
dbh[[2]] = 20
dbh[[3]] = 40
dbh[[4]] = 125


load("HJA_CNDD_5-15cmDHB_Survival_Avg_Predictive_Comparisons.RData")
ests1[[1]] = realcndd.elevs[,1]
ests2[[1]] = realcndd.elevs[,3]
load("HJA_CNDD_15-25cmDHB_Survival_Avg_Predictive_Comparisons.RData")
ests1[[2]] = realcndd.elevs[,1]
ests2[[2]] = realcndd.elevs[,3]
load("HJA_CNDD_25-52cmDHB_Survival_Avg_Predictive_Comparisons.RData")
ests1[[3]] = realcndd.elevs[,1]
ests2[[3]] = realcndd.elevs[,3]
load("HJA_CNDD_52-220cmDHB_Survival_Avg_Predictive_Comparisons.RData")
ests1[[4]] = realcndd.elevs[,1]
ests2[[4]] = realcndd.elevs[,3]


load("HJA_CNDD_5-15cmDHB_Growth_Avg_Predictive_Comparisons.RData")
gests1[[1]] = realcndd.elevs[,1]
gests2[[1]] = realcndd.elevs[,3]
load("HJA_CNDD_15-25cmDHB_Growth_Avg_Predictive_Comparisons.RData")
gests1[[2]] = realcndd.elevs[,1]
gests2[[2]] = realcndd.elevs[,3]
load("HJA_CNDD_25-52cmDHB_Growth_Avg_Predictive_Comparisons.RData")
gests1[[3]] = realcndd.elevs[,1]
gests2[[3]] = realcndd.elevs[,3]
load("HJA_CNDD_52-220cmDHB_Growth_Avg_Predictive_Comparisons.RData")
gests1[[4]] = realcndd.elevs[,1]
gests2[[4]] = realcndd.elevs[,3]


upperquant = 0.975
lowerquant = 0.025


cnddLELEVupper = c()
cnddLELEVlower = c()
cnddLELEVmedian = c()
cnddHELEVupper = c()
cnddHELEVlower = c()
cnddHELEVmedian = c()
gcnddLELEVupper = c()
gcnddLELEVlower = c()
gcnddLELEVmedian = c()
gcnddHELEVupper = c()
gcnddHELEVlower = c()
gcnddHELEVmedian = c()
for(i in 1:length(ests1)) {
cnddLELEVupper[i] = quantile(ests1[[i]],c(upperquant))
cnddLELEVlower[i] = quantile(ests1[[i]],c(lowerquant))
cnddLELEVmedian[i] = median(ests1[[i]])
cnddHELEVupper[i] = quantile(ests2[[i]],c(upperquant))
cnddHELEVlower[i] = quantile(ests2[[i]],c(lowerquant))
cnddHELEVmedian[i] = median(ests2[[i]])
}
for(i in 1:length(gests1)) {
gcnddLELEVupper[i] = quantile(gests1[[i]],c(upperquant))
gcnddLELEVlower[i] = quantile(gests1[[i]],c(lowerquant))
gcnddLELEVmedian[i] = median(gests1[[i]])
gcnddHELEVupper[i] = quantile(gests2[[i]],c(upperquant))
gcnddHELEVlower[i] = quantile(gests2[[i]],c(lowerquant))
gcnddHELEVmedian[i] = median(gests2[[i]])
}







# pdf("HJA_CNDD_Across_DBH_Size_Classes_BAYES_wELEV_20220202.pdf", height = 8, width = 5.5, useDingbats=FALSE)
par(mfrow=c(2,1))
par(mar = c(5, 5, 4, 2) + 0.1)
spacing = 0.05
marginadjust = 0.7
plot(c(0,1), c(0,1), las = 1, ylab = "", type = "n", 
	main = "CNDD in annual survival across size classes", xlim=c(0.8,4.2), ylim=c(-0.069,0.014), xlab = "Tree size class (cm DBH)", xaxt = "n")
mtext(side = 2, line = 3.5, "Change in annual survival from CNDD")
abline(h=0,lty=2)
lines((1:length(cnddLELEVmedian))-spacing, cnddLELEVmedian, col = "red", lwd = 1.5)
lines((1:length(cnddHELEVmedian))+spacing, cnddHELEVmedian, col = "blue", lwd = 1.5)
for(i in 1:10) {
segments(i-spacing ,cnddLELEVupper[i],i-spacing , cnddLELEVlower[i], col = "red", lwd = 1.5)
segments(i+spacing ,cnddHELEVupper[i],i+spacing , cnddHELEVlower[i], col = "blue", lwd = 1.5)
}
for(i in c(1)) {points(i-spacing , cnddLELEVmedian[i], pch = 19, cex = 2, col = "red")}
#for(i in c(0)) {
#	points(i-spacing , cnddLELEVmedian[i], pch = 19, cex = 2, col = "red", lwd = 3)
#	points(i-spacing , cnddLELEVmedian[i], pch = 16, cex = 1.4, col = adjustcolor("white", alpha.f = marginadjust), lwd = 3)
#}
for(i in c(2:4)) {points(i-spacing , cnddLELEVmedian[i], pch = 21, bg = "white", cex = 2, col = "red", lwd = 3)}
for(i in c(1)) {points(i+spacing , cnddHELEVmedian[i], pch = 19, cex = 2, col = "blue")}
for(i in c(2:4)) {points(i+spacing , cnddHELEVmedian[i], pch = 21, bg = "white", cex = 2, col = "blue", lwd = 3)}
axis(side=1, at = 1:length(cnddLELEVmedian), labels = unlist(dbh)[1:length(cnddLELEVmedian)])
text(c(1),rep(0.011,times=2), "*", cex=2)
#text(c(3),rep(0.011,times=1), "�", cex=1)
legend(2.3,-0.047, legend = c("Low elevation", "High elevation"), pch = 19, col = c("red", "blue"), bty = "n", lwd=1.5)

plot(c(0,1), c(0,1), las = 1, ylab = "", type = "n", 
	main = "CNDD in annual growth across size classes", xlim=c(0.8,4.2), ylim=c(-0.22,0.06), xlab = "Tree size class (cm DBH)", xaxt = "n")
mtext(side = 2, line = 3.5, "Change in annual growth from CNDD")
abline(h=0,lty=2)
lines((1:length(gcnddLELEVmedian))-spacing, gcnddLELEVmedian, col = "red", lwd = 1.5)
lines((1:length(gcnddHELEVmedian))+spacing, gcnddHELEVmedian, col = "blue", lwd = 1.5)
for(i in 1:10) {
segments(i-spacing ,gcnddLELEVupper[i],i-spacing , gcnddLELEVlower[i], col = "red", lwd = 1.5)
segments(i+spacing ,gcnddHELEVupper[i],i+spacing , gcnddHELEVlower[i], col = "blue", lwd = 1.5)
}
for(i in c(1:4)) {points(i-spacing , gcnddLELEVmedian[i], pch = 19, cex = 2, col = "red")}
# for(i in c(0)) {points(i-spacing , gcnddLELEVmedian[i], pch = 21, bg = "white", cex = 2, col = "red", lwd = 3)}
for(i in c(1:3)) {points(i+spacing , gcnddHELEVmedian[i], pch = 19, cex = 2, col = "blue")}
for(i in c(4)) {
	points(i+spacing , gcnddHELEVmedian[i], pch = 19, cex = 2, col = "blue", lwd = 3)
	points(i+spacing , gcnddHELEVmedian[i], pch = 16, cex = 1.4, col = adjustcolor("white", alpha.f = marginadjust), lwd = 3)
}
# for(i in c(0)) {points(i+spacing , gcnddHELEVmedian[i], pch = 21, bg = "white", cex = 2, col = "blue", lwd = 3)}
axis(side=1, at = 1:length(gcnddLELEVmedian), labels = unlist(dbh)[1:length(gcnddLELEVmedian)])
#text(c(4,5),rep(0.08,times=2), "*", cex=2)
legend(1.2,0.08, legend = c("Low elevation", "High elevation"), pch = 19, col = c("red", "blue"), bty = "n", lwd=1.5)

# dev.off()


for(i in 1:4) {
estsL = ests1[[i]]
estsH = ests2[[i]]
print(sum((estsL - estsH) > 0) / length(estsL))
}

for(i in 1:4) {
estsL = (ests1[[i]])
print(sum(estsL > 0) / length(estsL))
}

for(i in 1:4) {
estsH = (ests2[[i]])
print(sum(estsH > 0) / length(estsH))
}


for(i in 1:4) {
estsL = gests1[[i]]
estsH = gests2[[i]]
print(sum((estsL - estsH) > 0) / length(estsL))
}

for(i in 1:4) {
estsL = (gests1[[i]])
print(sum((estsL) > 0) / length(estsL))
}

for(i in 1:4) {
estsH = (gests2[[i]])
print(sum((estsH) > 0) / length(estsH))
}








### Script to perform analyses of HJA reference stand data
### Changes in plant species richness and climate across the elevational gradient
### By: J. LaManna, reference stand data accessed: 12-23-2017

# Load necessary R packages
library(vegan)
library(doBy)
library(arm)
library(reshape)
library(nlme)
library(spatstat)
library(lme4)
library(vegan)
library(boot)
library(lmtest)
library(abind)
library(optimx)
library(nloptr)
library(parallel)
library(MASS)
library(stats)
library(rstan)
library(rstanarm)
# Code for multi-core
options(mc.cores = parallel::detectCores())
library(DHARMa)


# Load data for diversity analyses
load("HJA_LaManna_RefStand_Species_Richness_Data.RData")

# NB: For RS01, RS02, RS03, the second census was conducted between 1976-1978, so surveys in these years were combined (surveyed different quadrats of the plot), and census 1 was removed for species richness analyses only (surveyed only a portion of the plot)
# NB: For RS27, quads were 20x20 instead of 25x25, so trees with GX > 100 or GY > 75 were removed and quads reassessed at 25x25 to make it consistent with other stands
# NB: The richness analyses below only use quadrats within plots that surveyed all trees > 5 cm DBH to consistently compare species richness across plots. 
# NB: Some trees were listed as within certain quads ("PLOT") in the data, but their mapped coordinates place them in another quad, thus this somtimes places them within a different MIN_DBH category. This was checked and corrected to re-classify those trees into the proper MIN_DBH status


# Load other analysis functions
sp.by.site.within.census.function = function(test) {
test.5dbh = test[which(test$MIN_DBH == 5),]
test.5dbh$value = c(1)
test2 = cast(test.5dbh, quad ~ SPECIES, value = 'value', fun.aggregate = sum, fill = 0)
test3 = test2[which(rowSums(test2) >= 5),]
return(test3)
}

sp.by.site.function = function(test) {
test2 = lapply(test, sp.by.site.within.census.function)
return(test2)
}

# Function to calculate stand species richness rareifed to 1/4 ha
area.rarefy.function = function(test) {
test2 = do.call('rbind', lapply(test, function(x) {specaccum(x[,-1], "random", permutations = 9999)$richness[4]}))
return(test2)
}

# Function to calculate stand species richness rarefied to 51 individuals (51 was the minimum abundance per plot per census)
ind.rarefy.function = function(test, minabundacrossplots = minabundacrossplots) {
test2 = do.call('rbind', lapply(test, function(x) {rarefy(colSums(x[,-1]), sample = minabundacrossplots)}))
return(test2)
}



##################################################################################
# Calculate species richness 

div.data.mats = lapply(div.data, sp.by.site.function)
cenabund = list()
for(i in 1:length(div.data.mats)) {cenabund[[i]] = unlist(lapply(div.data.mats[[i]], function(t) {sum(colSums(t[,-1]))}))}	# minimum abundance across plots
minabundacrossplots = min(unlist(cenabund))
years = do.call('rbind', lapply(div.data, function(x) {
	do.call('rbind', lapply(x, function(x) {c(x[1,'YEAR'], x[1,'census'])}))}))
stands = do.call('rbind', lapply(div.data, function(x) {
	do.call('rbind', lapply(x, function(x) {c(as.character(x[1,'STANDID']))}))}))
div.data2 = data.frame(STANDID = stands, YEAR = years[,1], census = years[,2])
div.data2$area.rarefy = as.vector(do.call('rbind', lapply(div.data.mats, area.rarefy.function)))
div.data2$ind.rarefy = as.vector(do.call('rbind', lapply(div.data.mats, ind.rarefy.function, minabundacrossplots = minabundacrossplots)))
div.data3 = merge(div.data2, standclimate, by = "STANDID", all.x = T)


# Remove most recent census, only conducted in 3 of the 23 forest stands (data removed because these were opportunistic mortality surveys only, not full censuses, and not comparable across stands)
div.data4 = div.data3[which(div.data3$census < 9),]




#################################################################################
## Bayesian analysis of area-based species rarefied richness across gradient


ELEV = c(scale(div.data4$ELEVATION))
area.rarefy = div.data4$area.rarefy
n = nrow(div.data4)
plotnum = as.numeric(factor(as.character(factor(as.character(div.data4$STANDID)))))
censusnum = div.data4$census

x = cbind(rep(1,times = n), ELEV)	
K = ncol(x)

# Bundle data for STAN
dat <- list(y = area.rarefy, ELEV = ELEV, x = x, K = K, plotnum = plotnum, census = censusnum, 
	ncensus = length(unique(censusnum)), N = n, nplotnum = max(plotnum))

# LMER model with ML for ranef variance estimates
set.seed(314)
m1 = lme4::lmer(area.rarefy ~ ELEV + (1|censusnum) + (1|plotnum))
summary(m1)

# Check model assumptions
# plot(fitted(m1),resid(m1))

### Fit STAN model 
# HMC Parameters
nchains = 5
postburn = 5000
burnin = 1000
its = postburn + burnin
thin = 10					
hmc_seed = 55406

# Initial values from LMER model
inits <- replicate(nchains, list(
  beta = fixef(m1),
  sigma_YEAR = attr(summary(m1)$varcor$censusnum,"stddev")[[1]],
  sigma_PLOT = attr(summary(m1)$varcor$plotnum,"stddev")[[1]],
  YEAR = ranef(m1)$'censusnum'[[1]], 
  PLOT = ranef(m1)$'plotnum'[[1]], 
  sigma_res = summary(m1)$sigma
), simplify = F)


# Run model
begin = Sys.time()
fit <- stan(file = "HJA_Species_Richness_Analysis_STAN.stan", 		# Stan model
  data = dat,   										# named list of data
  init = inits,										# initial values for parameters
  chains = nchains,             							# number of Markov chains
  warmup = burnin,          								# number of warmup iterations per chain
  iter = its,            								# total number of iterations per chain
  cores = nchains,              							# number of cores (could use one per chain)
  thin = thin,
  seed = hmc_seed,
  control = list(adapt_delta = 0.99)
  )
end = Sys.time()
(duration = end - begin)

# save(fit, file = "HJA_Species_Richness_Analysis_STAN_20211124.RData")

# load("HJA_Species_Richness_Analysis_STAN_20211124.RData")

# Traceplots
traceplot(fit, pars = c("beta"), inc_warmup = TRUE, nrow = 2)
traceplot(fit, pars = c("sigma_PLOT"), inc_warmup = TRUE, nrow = 2)
traceplot(fit, pars = c("sigma_YEAR"), inc_warmup = TRUE, nrow = 2)

# test for auto-correlation in chains
draws <- extract(fit, permuted = FALSE)
acf(c(draws[,,"beta[1]"]), lag.max = 100)
acf(c(draws[,,"beta[2]"]), lag.max = 100)
acf(c(draws[,,"sigma_PLOT"]), lag.max = 100)
acf(c(draws[,,"sigma_YEAR"]), lag.max = 100)

# Summaries
summary(c(draws[,,"sigma_YEAR"]))
summary(c(draws[,,"sigma_PLOT"]))
summary(c(draws[,,"beta[1]"])); quantile(c(draws[,,"beta[1]"]), c(0.025,0.05,0.25,0.5,0.75,0.95,0.975))
summary(c(draws[,,"beta[2]"])); quantile(c(draws[,,"beta[2]"]), c(0.025,0.05,0.25,0.5,0.75,0.95,0.975))

sum(c(draws[,,"beta[2]"]) < 0) / length(c(draws[,,"beta[2]"]))

# Retrieve posteriors
beta1 = c(draws[,,"beta[1]"])
beta2 = c(draws[,,"beta[2]"])

meanELEV = mean(div.data4$ELEVATION); sdELEV = sd(div.data4$ELEVATION)
elev.trans = function(x) {(x * sdELEV) + meanELEV}
elev.back.trans = function(x) {(x - meanELEV) / sdELEV}



# Plot and perform analyses for area-based rarefication
# pdf("HJA_Species_Richness_Across_Gradient_areaRarefy_20210529.pdf", height = 9.5, width = 5, useDingbats=FALSE)
par(pty="s")
par(mfrow=c(2,1))
set.seed(314)
Col1 = rainbow(length(unique(as.numeric(factor(div.data4$STANDID)))))
plot(jitter(div.data4$ELEVATION,amount=30), div.data4$area.rarefy, pch=19, xlab = "Elevation (m)", ylab = "Species richness rarefied by area",  
	col = adjustcolor(Col1[as.numeric(factor(div.data4$STANDID))],alpha.f=0.5), las = 1, type = "n")
elevseq = seq(min(ELEV),max(ELEV),length=1000)
upper = c()
for(i in 1:1000) {upper[i] = quantile((beta1+(beta2*elevseq[i])),c(0.95))}
lower = c()
for(i in 1:1000) {lower[i] = quantile((beta1+(beta2*elevseq[i])),c(0.05))}
polygon(x = c(elev.trans(elevseq), rev(elev.trans(elevseq))), y = c(upper, rev(lower)),
        col =  adjustcolor("gray45", alpha.f = 0.15), border = NA)
curve(mean(beta1) + (mean(beta2)*elev.back.trans(x)), xlim=range(elev.trans(ELEV)), add = T, lwd = 2)
points(jitter(div.data4$ELEVATION,amount=30), div.data4$area.rarefy, pch=19, col = adjustcolor(Col1[as.numeric(factor(div.data4$STANDID))],alpha.f=0.5))

# dev.off()






#################################################################################
## Bayesian analysis of individual-based species rarefied richness across gradient


ELEV = c(scale(div.data4$ELEVATION))
ind.rarefy = div.data4$ind.rarefy
n = nrow(div.data4)
plotnum = as.numeric(factor(as.character(factor(as.character(div.data4$STANDID)))))
censusnum = div.data4$census

x = cbind(rep(1,times = n), ELEV)	
K = ncol(x)

# Bundle data for STAN
dat <- list(y = ind.rarefy, ELEV = ELEV, x = x, K = K, plotnum = plotnum, census = censusnum, 
	ncensus = length(unique(censusnum)), N = n, nplotnum = max(plotnum))

# LMER model with ML for ranef variance estimates
set.seed(314)
m1 = lme4::lmer(ind.rarefy ~ ELEV + (1|censusnum) + (1|plotnum))
summary(m1)

# Check model assumptions
# plot(fitted(m1),resid(m1))

### Fit STAN model 
# HMC Parameters
nchains = 5
postburn = 5000
burnin = 1000
its = postburn + burnin
thin = 10					
hmc_seed = 55406

# Initial values from LMER model
inits <- replicate(nchains, list(
  beta = fixef(m1),
  sigma_YEAR = attr(summary(m1)$varcor$censusnum,"stddev")[[1]],
  sigma_PLOT = attr(summary(m1)$varcor$plotnum,"stddev")[[1]],
  YEAR = ranef(m1)$'censusnum'[[1]], 
  PLOT = ranef(m1)$'plotnum'[[1]], 
  sigma_res = summary(m1)$sigma
), simplify = F)


# Run model
begin = Sys.time()
fit <- stan(file = "HJA_Species_Richness_Analysis_STAN.stan", 		# Stan model
  data = dat,   										# named list of data
  init = inits,										# initial values for parameters
  chains = nchains,             							# number of Markov chains
  warmup = burnin,          								# number of warmup iterations per chain
  iter = its,            								# total number of iterations per chain
  cores = nchains,              							# number of cores (could use one per chain)
  thin = thin,
  seed = hmc_seed,
  control = list(adapt_delta = 0.99)
  )
end = Sys.time()
(duration = end - begin)

# save(fit, file = "HJA_Species_Richness_Analysis_indRarefy_STAN_20211124.RData")

# load("HJA_Species_Richness_Analysis_indRarefy_STAN_20211124.RData")

# Traceplots
traceplot(fit, pars = c("beta"), inc_warmup = TRUE, nrow = 2)
traceplot(fit, pars = c("sigma_PLOT"), inc_warmup = TRUE, nrow = 2)
traceplot(fit, pars = c("sigma_YEAR"), inc_warmup = TRUE, nrow = 2)

# test for auto-correlation in chains
draws <- extract(fit, permuted = FALSE)
acf(c(draws[,,"beta[1]"]), lag.max = 100)
acf(c(draws[,,"beta[2]"]), lag.max = 100)
acf(c(draws[,,"sigma_PLOT"]), lag.max = 100)
acf(c(draws[,,"sigma_YEAR"]), lag.max = 100)

# Summaries
summary(c(draws[,,"sigma_YEAR"]))
summary(c(draws[,,"sigma_PLOT"]))
summary(c(draws[,,"beta[1]"])); quantile(c(draws[,,"beta[1]"]), c(0.025,0.05,0.25,0.5,0.75,0.95,0.975))
summary(c(draws[,,"beta[2]"])); quantile(c(draws[,,"beta[2]"]), c(0.025,0.05,0.25,0.5,0.75,0.95,0.975))

sum(c(draws[,,"beta[2]"]) < 0) / length(c(draws[,,"beta[2]"]))

# Retrieve posteriors
beta1 = c(draws[,,"beta[1]"])
beta2 = c(draws[,,"beta[2]"])

meanELEV = mean(div.data4$ELEVATION); sdELEV = sd(div.data4$ELEVATION)
elev.trans = function(x) {(x * sdELEV) + meanELEV}
elev.back.trans = function(x) {(x - meanELEV) / sdELEV}



# Plot and perform analyses for area-based rarefication
# pdf("HJA_Species_Richness_Across_Gradient_indRarefy_20210529.pdf", height = 9.5, width = 5, useDingbats=FALSE)
par(pty="s")
par(mfrow=c(2,1))
set.seed(314)
Col1 = rainbow(length(unique(as.numeric(factor(div.data4$STANDID)))))
plot(jitter(div.data4$ELEVATION,amount=30), div.data4$ind.rarefy, pch=19, xlab = "Elevation (m)", ylab = "Species richness rarefied by abundance",  
	col = adjustcolor(Col1[as.numeric(factor(div.data4$STANDID))],alpha.f=0.5), las = 1, type = "n")
elevseq = seq(min(ELEV),max(ELEV),length=1000)
upper = c()
for(i in 1:1000) {upper[i] = quantile((beta1+(beta2*elevseq[i])),c(0.95))}
lower = c()
for(i in 1:1000) {lower[i] = quantile((beta1+(beta2*elevseq[i])),c(0.05))}
polygon(x = c(elev.trans(elevseq), rev(elev.trans(elevseq))), y = c(upper, rev(lower)),
        col =  adjustcolor("gray45", alpha.f = 0.15), border = NA)
curve(mean(beta1) + (mean(beta2)*elev.back.trans(x)), xlim=range(elev.trans(ELEV)), add = T, lwd = 2)
points(jitter(div.data4$ELEVATION,amount=30), div.data4$ind.rarefy, pch=19, col = adjustcolor(Col1[as.numeric(factor(div.data4$STANDID))],alpha.f=0.5))

# dev.off()




##################################################################################
# Plot climate gradient across elevational gradient
par(pty="s")
y = resid(lm(meanMAP ~ meanMAT, data = standclimate))
rbPal <- colorRampPalette(c('brown','orange','green'))
Col1 <- rbPal(10)[as.numeric(cut(y,breaks = 10))]
stands.plot = standclimate
stands.plot$meanMAT[which(stands.plot$STANDID == "RS17")] = stands.plot$meanMAT[which(stands.plot$STANDID == "RS17")] - 0.04	# point adjusted very slightly so it can be seen in figure (otherwise is obscured by another point)
plot(stands.plot$ELEVATION, stands.plot$meanMAT, col = Col1, las = 1, pch = 19, cex = 1.25, xlab = "Elevation (m)", ylab = "")
par(xpd = T)
points(rep(1550,times=10),seq(8,10,length.out=10),col=rbPal(10),pch=15,cex=3.0,bty="n")
mtext("Mean annual temperature (C)", side = 2, line = 3.0)



##################################################################################
### Calculate species abundance and basal area per species per forest plot

# Add up species abundances and basal area in each census for each forest plot
sp.abund.function = function(test) {
test$ba = (((test$DBH/100)/2)^2)*pi  		# Calculate basal area for each individual (m^2)
test$SPECIES = as.character(test$SPECIES)
test$value = c(1)
test2 = tapply(test$ba, test$SPECIES, sum)
test3 = tapply(test$value, test$SPECIES, sum)
abund = data.frame(ba = test2)
abund$abund = test3
abund$sp = rownames(abund)
abund$plot = as.character(test$STANDID[1])
abund$census = c(test$census[1])
abund$YEAR = c(test$YEAR[1])
return(abund)
}

# Conduct the species abundance function on each forest plot
sp.abund.stand.function = function(test) {
test2 = do.call('rbind', lapply(test, sp.abund.function))
return(test2)
}

# Create data frame of plot areas (ha)
plotsize = data.frame(plot = c("RS01","RS02","RS03","RS04","RS05","RS07","RS08","RS10","RS12","RS15",
	"RS16","RS17","RS20","RS21","RS22","RS23","RS27","RS28","RS29","RS30",
	"RS31","RS34","RS38"), 
	area_ha = c(1, 1, 1, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 
	0.25, 0.25, 1, 1, 1, 1, 0.75, 1, 1, 1, 
	1, 2, 2.44))


# Obtain abundance metrics
sp.abund = do.call('rbind', lapply(div.data, sp.abund.stand.function))
sp.abund2 = summaryBy(ba + abund ~ plot + sp, keep.names = T, FUN = mean, data = sp.abund)
abund = merge(sp.abund2, plotsize, by = "plot", all = T)
# save(abund, file = "HJA_Species_Mean_Abundances_across_Censuses_by_Plot.RData")	# This saves the mean abundnace and basal area per species per plot 




##########################################################################################
# Plot size with elevation

plotsize2 = plotsize
names(plotsize2)[1] = "STANDID"
plotsize2 = merge(plotsize2, standclimate, by = "STANDID", all = T)

mean(plotsize2$area_ha)
sd(plotsize2$area_ha)

plot(jitter(plotsize2$ELEVATION), plotsize2$area_ha)
m5 = lm(area_ha ~ ELEVATION, data = plotsize2)
summary(m5)
abline(m5)
x1 = seq(min(plotsize2$ELEVATION), max(plotsize2$ELEVATION), length=300)
p = predict(m5, newdata = data.frame(ELEVATION = x1), se.fit = T)
lines(x1, p$fit + (2*p$se.fit), lty = 2)
lines(x1, p$fit - (2*p$se.fit), lty = 2)

cor.test(plotsize2$ELEVATION, plotsize2$area_ha)


# Relationship between plot size and abundance
abund3 = summaryBy(ba + abund ~ plot, keep.names = T, id = ~ area_ha, FUN = sum, data = abund)
plot(abund3$area_ha, abund3$abund)
cor.test(abund3$area_ha, abund3$abund)








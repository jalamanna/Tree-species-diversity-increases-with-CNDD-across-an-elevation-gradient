### Script to perform analyses of HJA reference stand data
### Data prep for survival and growth analyses
### By: J. LaManna, reference stand data accessed: 12-23-2017

# Load necessary R packages
library(vegan)
library(doBy)
library(arm)
library(reshape)
library(nlme)
library(spatstat)
library(lme4)
library(vegan)
library(boot)
library(lmtest)
library(abind)
library(optimx)
library(nloptr)
library(parallel)
library(MASS)
library(stats)
library(DescTools)
library(purrr)
library(rstan)
library(rstanarm)
# Code for multi-core
options(mc.cores = parallel::detectCores())
library(DHARMa)


# Load data for diversity analyses
load("HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData")

### IN ADDITION MAKE SURE THESE RData FILES ARE IN R WORKING DIRECTORY:
# "HJA_Species_Mean_Abundances_across_Censuses_by_Plot.RData"
# "HJA_CNDD_Analyses_Species_Colors_for_figures.RData"
# "HJA_GLMM_CENSORED_Growth_Model.stan"


# Load other analysis functions

# Function to calculate distance-weighted abundance based on methods in Uriarte et al. (2004) and Comita et al. (2010):
dist.weighted.abund.function = function(adultlocs = adultlocs, saplocs = saplocs, fix.rad = TRUE, rad = 10, alpha = 0, beta = 0.2) {
  xdist = crossdist(adultlocs[,2], adultlocs[,3], saplocs[,2], saplocs[,3])
  same.tree.row = which(adultlocs$id %in% saplocs$id == T)						# Remove the focal tree if it's in the dataset
  same.tree.col = match(adultlocs$id, saplocs$id)[which(adultlocs$id %in% saplocs$id == T)]
  xdist[as.matrix(data.frame(same.tree.row, same.tree.col))] = NA
  weight.mat = matrix((adultlocs$dbh^alpha), nrow = nrow(xdist), ncol = ncol(xdist))	# Neighborhood function for size-dependence (alpha)
  if(fix.rad) {								# Using fixed radii
    xdist2 = xdist
    xdist2[which(xdist2 > rad)] = NA
    xdist.weighted = weight.mat * exp((-beta) * xdist2) 	# Neighborhood function for distance-dependence (beta)
  } else {									# Using non-fixed radii
    xdist2 = xdist
    xdist.weighted = weight.mat * exp((-beta) * xdist2) 	# Neighborhood function for distance-dependence (beta)
  }
  xdist.weighted[is.na(xdist.weighted)] = 0
  species.names = unique(adultlocs[,1])
  adult.weights = data.frame(matrix(NA,nrow = nrow(saplocs), ncol = length(species.names)))
  colnames(adult.weights) = species.names
  rownames(adult.weights) = saplocs[,1]
  if(nrow(adult.weights) == 0) {
    return(adult.weights)						# Check that there are values to return
  } else {
    for(z in 1:ncol(adult.weights)) {				# Sum up neighborhood density values for each species
      if(ncol(xdist.weighted) > 1) {
        if(length(which(adultlocs[,1] == species.names[z])) > 1) {
          adult.weights[,z] = colSums(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
        } else {
          adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
        }
      } else {
        if(length(which(adultlocs[,1] == species.names[z])) > 1) {
          adult.weights[,z] = sum(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
        } else {
          adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
        }
      }
    }
    return(adult.weights)
  }
}



# Function to add missing species names when calculating distance-wieghted abundance 
# (add species with zero abundnace in a neighborhood to keep number of columns consistent across trees)
Add.missing.sp.names = function(test) {
  names.toAdd = sp.list[which(sp.list %in% colnames(test) == F)]
  test2 = data.frame(test, data.frame(matrix(0, nrow = nrow(test), ncol = length(names.toAdd))))
  colnames(test2) = c(colnames(test), names.toAdd)
  test2 = test2[,order(colnames(test2))]
  return(test2)
}


# Function to standardize conspecific and heterospecific densities on the same scale
std.conhet.density = function(conspp, heterospp, id, DenExp) {
  consppid = tapply(conspp, id, mean)							# Mean conspecific density across individuals
  heterosppid = tapply(heterospp, id, mean)						# Mean heterospecific density across individuals
  conhetero = c(consppid^(DenExp), heterosppid^(DenExp))				# Collective mean across all con- and heterospecific densities trasnformed with D = DenExp
  conspp.std = ((conspp^(DenExp)) - mean(conhetero)) / sd(conhetero)		# Scaled conspecific densities
  heterospp.std = ((heterospp^(DenExp)) - mean(conhetero)) / sd(conhetero)	# Scaled heterospecific densities
  return(list(conspp = conspp.std, heterospp = heterospp.std))
}


# Function to perform Bayesian bootstrap (Rubin 1981, Gustafson 2007)
# see https://en.wikipedia.org/wiki/Dirichlet_distribution#Gamma_distribution for proof of gamma distribution equivalency to Dirichlet distribution
# sample.weights is an optional agrument used to weight Bayesian bootstrap average predictive comparisons by plot area
bayesian.bootstrap = function(test_sample, nIts, sample.weights = NA) {
  weights <- matrix(rexp(length(test_sample) * nIts, 1), ncol = length(test_sample), byrow = TRUE)	# Matrix to hold weights sampled from Dirichlet distribution with equal weights
  if(is.numeric(sample.weights)) {weights <- t(t(weights) * sample.weights)}	# Weight by sample.weights (e.g. forest-plot area in ha)
  weights <- weights / rowSums(weights)							# Make sure weights sum to 1 (Dirichlet distribution)
  result = rowSums(t(t(weights) * test_sample))						# Multiply and add test_sample to weights for each iteration
  return(result)
}







########################################################################################################################
### DATA PREP FUNCTION -- Remember to set values for 'alpha' and 'beta' below, elim.radius set to 10 m

fd.focal.phi = list()
elim.radius = 10		# remove trees within 10 m of plot edge for survival/growth analyses (neighborhood density metrics, which have radii of 10 m, will be biased low for these individuals because we don't know what adults are outside the plot)
alpha = 1.1			# alpha parameter for distance-weighted abundance-based neighborhood metrics, DBH^alpha / exp(beta * distance), higher values weight larger-diameter trees more, 0 weights all trees evenly (i.e. abundance)
beta = 0.2			# Beta value determines the shape of the exponential decay of neighborhood effects across each 10-m radius neighborhood; 0 = no decay, higher values = stronger decay (Comita et al. 2010, Science)

sp.list

# The following code goes through the tree data, removes trees within 10 m of plot boundaries, and calculates distance-weighted abundance-based 
# neighborhood metrics for each tree using all trees >15 cm within 10 m of the focal tree.

for(q in 1:length(hja.survival.growth.data)) {
  test = hja.survival.growth.data[[q]]
  n.census = length(test)
  focal.phi.list = list()

  for(i in 2:n.census) {
    df = test[[i]]
    df$ba = (((df$DBH/100)/2)^2)*pi  													# Calculate basal area for each individual
    df$julian = as.numeric(julian(as.POSIXlt(df$SAMPLEDATE, format = "%Y-%m-%d")))						# Julian date for each sample occasion
    adult.sp = tapply(df$DBH[which(df$DBH >= 15)], as.character(df$SPECIES[which(df$DBH >= 15)]), length)		# Adult species in census
    adult.sp2 = names(adult.sp)
    focal = data.frame(STANDID = df$STANDID, census = df$census, YEAR = df$YEAR, DBH = df$DBH, quad = df$quad, canopy_class = df$CANOPY_CLASS, vigor = df$TREE_VIGOR,
	uniqueID = df$uniqueID, sp = df$SPECIES, gx = df$XCOORD, gy = df$YCOORD, status = df$TREE_STATUS, dbh_code = df$DBH_CODE, julian = df$julian, min_dbh = df$MIN_DBH, notes = df$CHECK_NOTES)
    focal$sp = as.character(focal$sp)													# 'focal' contains information on the trees for analysis in a given census/plot combo

    # Remove trees within 10 m of plot boundaries for current census (plots are sometimes not perfect squares, so the code is more complex).
    test.var = 1
    if(df$census[1] == 9 & df$STANDID[1] == "RS34") {test.var = 34}	# Census 9 only recorded dead trees (incomplete census), these data are removed later in the code
    if(df$census[1] == 9 & df$STANDID[1] == "RS38") {test.var = 38}
    if(test.var == 34) {focal = focal[which(focal$gx >= 10 & focal$gx <= 190 & focal$gy >= 10 & focal$gy <= 90),]}
    if(test.var == 38) {focal = focal[which(focal$gx >= 10 & focal$gx <= 165 & focal$gy >= 10 & focal$gy <= 90),]}
    if(test.var == 1) {
      maxcol = max(as.numeric(substr(df$quad,1,2)))
      maxrow = max(as.numeric(substr(df$quad,3,4)))
      mincol = min(as.numeric(substr(df$quad,1,2)))
      minrow = min(as.numeric(substr(df$quad,3,4)))
      focal.good = focal[which(focal$quad == 9999),]
      for(k in mincol:maxcol) {
        df2 = df[which(as.numeric(substr(df$quad,1,2)) == k),]
        ymax = max(as.numeric(substr(df2$quad,3,4))) * 25
        ymin = (min(as.numeric(substr(df2$quad,3,4))) - 1) * 25
        focal.good = rbind(focal.good, focal[which(as.numeric(substr(focal$quad,1,2)) == k & focal$gy >= (ymin + elim.radius) & focal$gy <= (ymax - elim.radius)),])
      }
      focal.good2 = focal.good[which(focal.good$quad == 9999),]
      for(k in minrow:maxrow) {
        df2 = df[which(as.numeric(substr(df$quad,3,4)) == k),]
        xmax = max(as.numeric(substr(df2$quad,1,2))) * 25
        xmin = (min(as.numeric(substr(df2$quad,1,2))) - 1) * 25
        focal.good2 = rbind(focal.good2, focal.good[which(as.numeric(substr(focal.good$quad,3,4)) == k & focal.good$gx >= (xmin + elim.radius) & focal.good$gx <= (xmax - elim.radius)),])
      }
    
      focal = focal.good2
      focal$sp = as.character(focal$sp)
      if(nrow(focal) == 0) {print(paste("ERROR: No individuals within plot buffer!", "STAND", q, "census", i)); next}
      if(focal$STANDID[1] == "RS01" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 10 & focal$gx <= 40 & focal$gy >= 10 & focal$gy <= 40),]}
      if(focal$STANDID[1] == "RS02" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 35 & focal$gx <= 65 & focal$gy >= 35 & focal$gy <= 65),]}
      if(focal$STANDID[1] == "RS03" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 60 & focal$gx <= 90 & focal$gy >= 60 & focal$gy <= 90),]}
    }
    focal$sp = as.character(focal$sp)
    
    # Code to plot focal trees in current census
    # plot(df$XCOORD,df$YCOORD,asp=1)
    # points(focal$gx,focal$gy,pch=19,col="red")
    # points(focal.good2$gx,focal.good2$gy,pch=19,col="purple")
    
    # Remove trees within 10 m of plot boundaries for previous census (plots are sometimes not perfect squares, so the code is more complex).
    df.prev = test[[i-1]]
    missing.and.found = df.prev[which(df.prev$uniqueID %in% c("RS03-12-6791", "RS21-14-45") == T & df.prev$TREE_STATUS %in% c(6,9) == T),]	# These trees were missing in one census, but found in next (not dead)
    df.prev = df.prev[which(df.prev$TREE_STATUS %in% c(6,9) == F),]	# Remove dead trees from previous census
    df.prev = rbind(df.prev, missing.and.found)
    df.prev$julian = as.numeric(julian(as.POSIXlt(df.prev$SAMPLEDATE, format = "%Y-%m-%d")))	# Julian date for previous sampling occasion
    focal.prev.time = df.prev
    if(df$census[1] == 9 & df$STANDID[1] %in% c("RS34", "RS38") == T) {
    	focal.prev.time$gx = focal.prev.time$XCOORD
    	focal.prev.time$gy = focal.prev.time$YCOORD
    	focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$uniqueID %in% focal$uniqueID == T),]
    } else {
      maxcol = max(as.numeric(substr(df.prev$quad,1,2)))
      maxrow = max(as.numeric(substr(df.prev$quad,3,4)))
      mincol = min(as.numeric(substr(df.prev$quad,1,2)))
      minrow = min(as.numeric(substr(df.prev$quad,3,4)))
      focal.prev.time$gx = focal.prev.time$XCOORD
      focal.prev.time$gy = focal.prev.time$YCOORD
      focal.prev.time.good = focal.prev.time[which(focal.prev.time$quad == 9999),]
      for(k in mincol:maxcol) {
        df.prev2 = df.prev[which(as.numeric(substr(df.prev$quad,1,2)) == k),]
        ymax = max(as.numeric(substr(df.prev2$quad,3,4))) * 25
        ymin = (min(as.numeric(substr(df.prev2$quad,3,4))) - 1) * 25
        focal.prev.time.good = rbind(focal.prev.time.good, focal.prev.time[which(as.numeric(substr(focal.prev.time$quad,1,2)) == k & focal.prev.time$gy >= (ymin + elim.radius) & focal.prev.time$gy <= (ymax - elim.radius)),])
      }
      focal.prev.time.good2 = focal.prev.time.good[which(focal.prev.time.good$quad == 9999),]
      for(k in minrow:maxrow) {
        df.prev2 = df.prev[which(as.numeric(substr(df.prev$quad,3,4)) == k),]
        xmax = max(as.numeric(substr(df.prev2$quad,1,2))) * 25
        xmin = (min(as.numeric(substr(df.prev2$quad,1,2))) - 1) * 25
        focal.prev.time.good2 = rbind(focal.prev.time.good2, focal.prev.time.good[which(as.numeric(substr(focal.prev.time.good$quad,3,4)) == k & focal.prev.time.good$gx >= (xmin + elim.radius) & focal.prev.time.good$gx <= (xmax - elim.radius)),])
      }
      # The first census in stands RS01 thru RS03 surveyed smaller areas than all other cenuses
      if(focal.prev.time$STANDID[1] == "RS01" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 10 & focal.prev.time$gx <= 40 & focal.prev.time$gy >= 10 & focal.prev.time$gy <= 40),]}
      if(focal.prev.time$STANDID[1] == "RS02" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 35 & focal.prev.time$gx <= 65 & focal.prev.time$gy >= 35 & focal.prev.time$gy <= 65),]}
      if(focal.prev.time$STANDID[1] == "RS03" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 60 & focal.prev.time$gx <= 90 & focal.prev.time$gy >= 60 & focal.prev.time$gy <= 90),]}
    }
    
    # plot(df.prev$XCOORD,df.prev$YCOORD,asp=1)
    # points(focal.prev.time$gx,focal.prev.time$gy,pch=19,col="red")
    # points(focal.prev.time.good2$gx,focal.prev.time.good2$gy,pch=19,col="purple")
    
    focal.prev.time = focal.prev.time.good2[,c("uniqueID", "DBH", "SPECIES", "YEAR", "gx", "gy", "STANDID", "quad", "TREE_STATUS", "julian", "DBH_CODE", "CANOPY_CLASS", "TREE_VIGOR", "MIN_DBH")]
    names(focal.prev.time) = c("uniqueID", "DBH_prev", "sp", "YEAR_prev", "gx_prev", "gy_prev", "STANDID_prev", "quad_prev", "status_prev", "julian_prev", "dbh_code_prev", "canopy_class_prev", "vigor_prev", "min_dbh_prev")
    focal.prev.time$sp = as.character(focal.prev.time$sp)
    focal2 = merge(focal, focal.prev.time, by = c("uniqueID", "sp"), all = T)
    focal2$growth = focal2$DBH - focal2$DBH_prev
    focal2$numyr = (focal2$julian - focal2$julian_prev) / 365.25
    focal2$growth.per.yr = focal2$growth / focal2$numyr						# Absolute growth per year (used in analysis b/c DBH also included to account for previous diameter)
    focal2$radial.growth.per.yr = (log(focal2$DBH/focal2$DBH_prev)) / focal2$numyr		# Relative Growth Rate per Wright et al. 2018 Ecology
    
    # plot(df$XCOORD,df$YCOORD,asp=1)
    # points(focal2$gx,focal2$gy,pch=19,col="red")
    # points(focal.good2$gx,focal.good2$gy,pch=19,col="purple")
    
    # Remove interior plot corners that are within 10 m of plot boundary (not captured in preceding code)
    if(focal2$STANDID[1] == "RS01") {if(nrow(focal2[which(focal2$gx > 40 & focal2$gx < 50 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 40 & focal2$gx < 50 & focal2$gy > 50 & focal2$gy < 60),]}}
    if(focal2$STANDID[1] == "RS03") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 40 & focal2$gy < 50),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 40 & focal2$gy < 50),]}}
    if(focal2$STANDID[1] == "RS03") {if(nrow(focal2[which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 40 & focal2$gy < 50),]) > 0) {focal2 = focal2[-which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 40 & focal2$gy < 50),]}}
    if(focal2$STANDID[1] == "RS23") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 50 & focal2$gy < 60),]}}
    if(focal2$STANDID[1] == "RS23") {if(nrow(focal2[which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 50 & focal2$gy < 60),]}}
    if(focal2$STANDID[1] == "RS38") {if(nrow(focal2[which(focal2$gx > 25 & focal2$gx < 35 & focal2$gy > 90 & focal2$gy < 100),]) > 0) {focal2 = focal2[-which(focal2$gx > 25 & focal2$gx < 35 & focal2$gy > 90 & focal2$gy < 100),]}}
    if(focal2$STANDID[1] == "RS38") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 115 & focal2$gy < 125),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 115 & focal2$gy < 125),]}}
    
    # Determine 'phi' which is survival from previous census to current census based on continued presence in census and live status
    focal2$phi = c(1)
    focal2$phi[is.na(focal2$DBH)] = 0
    focal2$phi[is.na(focal2$DBH_prev)] = NA
    focal2$gx[is.na(focal2$gx)] = focal2$gx_prev[is.na(focal2$gx)]
    focal2$gy[is.na(focal2$gy)] = focal2$gy_prev[is.na(focal2$gy)]
    focal2$quad = as.character(focal2$quad)
    focal2$quad_prev = as.character(focal2$quad_prev)
    focal2$STANDID = as.character(focal2$STANDID)
    focal2$STANDID_prev = as.character(focal2$STANDID_prev)
    focal2$quad[is.na(focal2$quad)] = focal2$quad_prev[is.na(focal2$quad)]
    focal2$STANDID[is.na(focal2$STANDID)] = focal2$STANDID_prev[is.na(focal2$STANDID)]
    focal2$census[is.na(focal2$census)] = c(unique(focal2$census[!is.na(focal2$YEAR)]))
    focal2$YEAR[is.na(focal2$YEAR)] = c(unique(focal2$YEAR[!is.na(focal2$DBH)]))
    
    # Calculate distance-based abundance metrics for neighborhood density
    adults = df[which(df$DBH >= 15),]
    adults = adults[which(adults$TREE_STATUS %in% c(6,9) == F),]
    adults.prev = df.prev[which(df.prev$DBH >= 15),]
    adults.prev = adults.prev[which(adults.prev$TREE_STATUS %in% c(6,9) == F),]
    adultlocs = data.frame(sp = adults$SPECIES, gx = adults$XCOORD, gy = adults$YCOORD, id = adults$uniqueID, dbh = adults$DBH)
    adultlocs.prev = data.frame(sp = adults.prev$SPECIES, gx = adults.prev$XCOORD, gy = adults.prev$YCOORD, id = adults.prev$uniqueID, dbh = adults.prev$DBH)
    unique.quads = unique(df$quad)
    quad.gx = c()
    quad.gy = c()
    for(z in 1:length(unique.quads)) {
      quad.gx[z] = (25*as.numeric(substr(unique.quads[z],1,2))-12.5)
      quad.gy[z] = (25*as.numeric(substr(unique.quads[z],3,4))-12.5)
    }
    quadlocs = data.frame(id = unique.quads, gx = quad.gx, gy = quad.gy)
    quad.weights.prev = dist.weighted.abund.function(adultlocs = adultlocs.prev, saplocs = quadlocs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
    quad.weights2.prev = Add.missing.sp.names(quad.weights.prev)
    if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
      quad.weights.combined = quad.weights2.prev
    } else {
      quad.weights = dist.weighted.abund.function(adultlocs = adultlocs, saplocs = quadlocs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
      quad.weights2 = Add.missing.sp.names(quad.weights)
      quad.weights.combined = (quad.weights2 + quad.weights2.prev) / 2
    }
    
    focal.phi = focal2[!is.na(focal2$DBH_prev),]
    if(nrow(focal.phi) > 0) {
      focal.phi$order = c(1:nrow(focal.phi))
      focal.phi = focal.phi[order(focal.phi$sp),]
      focal.phi.locs = data.frame(id = focal.phi$uniqueID, gx = focal.phi$gx, gy = focal.phi$gy)
      focal.phi.weights.prev = dist.weighted.abund.function(adultlocs = adultlocs.prev, saplocs = focal.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
      focal.phi.weights2.prev = Add.missing.sp.names(focal.phi.weights.prev)
      if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
        focal.phi.weights.combined = focal.phi.weights2.prev
      } else {
        focal.phi.weights = dist.weighted.abund.function(adultlocs = adultlocs, saplocs = focal.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
        focal.phi.weights2 = Add.missing.sp.names(focal.phi.weights)
        focal.phi.weights.combined = (focal.phi.weights2 + focal.phi.weights2.prev) / 2
      }
      focal.phi = data.frame(focal.phi, focal.phi.weights.combined)
      focal.phi = focal.phi[order(focal.phi$order),]
      focal.phi.list[[i-1]] = focal.phi
    }
  }
  # Combine censuses within a plot for output
  if(length(focal.phi.list) > 0) {
    focal.phi.list = focal.phi.list[which(lapply(focal.phi.list, function(x) {nrow(x) > 0}) == T)]
    focal.phi2 = do.call('rbind', focal.phi.list)
    focal.phi2$yr = focal.phi2$YEAR - 2000
    fd.focal.phi[[q]] = focal.phi2
  }
}



########################################
## Prepare data for analysis
yr.value = 2008
fd.focal.phi2 = do.call('rbind', fd.focal.phi)
fd.focal.phi2 = fd.focal.phi2[order(fd.focal.phi2$STANDID, fd.focal.phi2$sp, fd.focal.phi2$uniqueID, fd.focal.phi2$census),]
fd.focal.phi2$sizeclass = c(NA)
fd.focal.phi3 = split(fd.focal.phi2, as.character(fd.focal.phi2$uniqueID))

# Set sizeclasses for analysis (cutoff points based on data -- trees < 15 cm were only surveyed in subsets of some of the plots, so they are the first sizeclass,
# the other 3 size classes were determined by splitting the data above 15 cm into 3 approximately equal groups (equal number of individual trees)
for(i in 1:length(fd.focal.phi3)) {
  if(min(fd.focal.phi3[[i]]$DBH_prev) < 15 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] < 15) {fd.focal.phi3[[i]]$sizeclass = c(1)}			# Trees that stay in the 5-15 cm sizeclass
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 15 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] < 25.4) {fd.focal.phi3[[i]]$sizeclass = c(2)}		# Trees that stay in the 15-25 cm sizeclass (25.4 = 33rd percentile of DBH for all trees > 15 cm DBH)
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 25.4 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] < 52.06667) {fd.focal.phi3[[i]]$sizeclass = c(3)}	# Trees that stay in the 25-52 cm sizeclass (52.06667 = 67th percentile of DBH for all trees > 15 cm DBH)
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 52.06667) {fd.focal.phi3[[i]]$sizeclass = c(4)}														# Trees that stay in the >52 cm sizeclass
  if(min(fd.focal.phi3[[i]]$DBH_prev) < 15 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] >= 15) {									# Trees that start in the 5-15 cm sizeclass and transition to larger sizeclass
    fd.focal.phi3[[i]]$sizeclass[1:max(which(fd.focal.phi3[[i]]$DBH_prev < 15))] = 1
    fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 15))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 2
    if(max(fd.focal.phi3[[i]]$DBH_prev) >= 25.4) {fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 25.4))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 3}
    if(max(fd.focal.phi3[[i]]$DBH_prev) >= 52.06667) {fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 4}
  }
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 15 & min(fd.focal.phi3[[i]]$DBH_prev) < 25.4 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] >= 25.4) {	# Trees that start in the 15-25 cm sizeclass and transition to larger sizeclass
    fd.focal.phi3[[i]]$sizeclass[1:max(which(fd.focal.phi3[[i]]$DBH_prev < 25.4))] = 2
    fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 25.4))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 3
    if(max(fd.focal.phi3[[i]]$DBH_prev) >= 52.06667) {fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 4}
  }
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 25.4 & min(fd.focal.phi3[[i]]$DBH_prev) < 52.06667 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] >= 52.06667) {	# Trees that start in the 25-52 cm sizeclass and transition to larger sizeclass
    fd.focal.phi3[[i]]$sizeclass[1:max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))] = 3
    fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 4
  }
}
fd.focal.phi4 = do.call('rbind', fd.focal.phi3)
fd.focal.grow5 = merge(fd.focal.phi4, standclimate, by = "STANDID", all.x = T)
fd.focal.grow5 = fd.focal.grow5[which(fd.focal.grow5$phi == 1),]
fd.focal.grow5 = fd.focal.grow5[!is.na(fd.focal.grow5$growth.per.yr),]
fd.focal.grow5$yr2 = fd.focal.grow5$YEAR - yr.value
fd.focal.grow5$conspp = c(NA)
fd.focal.grow5$allspp = c(NA)
fd.focal.grow5$heterospp = c(NA)
adult.cols = which(colnames(fd.focal.grow5) %in% sp.list == T)
# Sum conspecific and heterospecific local densities across species in each neighborhood
for(i in 1:nrow(fd.focal.grow5)) {
  fd.focal.grow5$conspp[i] = fd.focal.grow5[i,which(colnames(fd.focal.grow5) == fd.focal.grow5$sp[i])]
  fd.focal.grow5$allspp[i] = sum(fd.focal.grow5[i,adult.cols])
  fd.focal.grow5$heterospp[i] = sum(fd.focal.grow5[i,adult.cols[which(colnames(fd.focal.grow5[,adult.cols]) != fd.focal.grow5$sp[i])]])
}
fd.focal.grow5 = fd.focal.grow5[which(fd.focal.grow5$census < 9),]			# Remove census 9 (mortality checks only conducted in a small subset of plots)
fd.focal.grow5 = fd.focal.grow5[which(fd.focal.grow5$dbh_code == "G"),]			# Remove trees where measurements were not considered accurate
fd.focal.grow5 = fd.focal.grow5[which(fd.focal.grow5$dbh_code_prev == "G"),]		# Remove trees where measurements were not considered accurate
fd.focal.grow6 = fd.focal.grow5

# Measurements removed due to sloughing bark or tags falling off tree
fd.focal.grow6$growth.per.yr[which(fd.focal.grow6$uniqueID == "RS28-11-4200" & fd.focal.grow6$YEAR == 1983)] = NA
adult.growth.update = read.csv("HJA_RefStands_Adult_negGrowth_Checks_20200807update.csv", header = T)
adult.growth.update = adult.growth.update[,c("uniqueID", "YEAR", "growth.update")]
adult.growth.update = adult.growth.update[which(adult.growth.update$growth.update == 1),]
sap.growth.update = read.csv("HJA_RefStands_Sap_negGrowth_Checks.csv", header = T)
sap.growth.update = sap.growth.update[,c("uniqueID", "YEAR", "growth.update")]
sap.growth.update = sap.growth.update[which(sap.growth.update$growth.update == 1),]
focal.growth.update = rbind(sap.growth.update, adult.growth.update)
fd.focal.grow7 = fd.focal.grow6
for(i in 1:nrow(focal.growth.update)) {fd.focal.grow7$growth.per.yr[which(fd.focal.grow7$uniqueID == as.character(focal.growth.update$uniqueID[i]) & fd.focal.grow7$YEAR == focal.growth.update$YEAR[i])] = NA}
fd.focal.grow7 = fd.focal.grow7[!is.na(fd.focal.grow7$growth.per.yr),]









#############################################################################################
### LMER Analysis for large-tree growth 
### (use data to estimate values of 'alpha' (abundance-weighting parameter), 'beta' (distance-dependence parameter), and 'D' (the nonlinearity parameter)

d = fd.focal.grow7[order(fd.focal.grow7$uniqueID, fd.focal.grow7$census),]
d = d[which(d$sizeclass == 2),]	# Trees in the 15-25 cm sizeclass

d = d[order(d$uniqueID,d$census),]
d$ID = as.character(d$uniqueID)
growth = scale(log(d$growth.per.yr+1))

uniID = as.numeric(factor(d$uniqueID))
consppid = tapply(d$conspp, uniID, mean)		# Mean conspecific density across individuals
heterosppid = tapply(d$heterospp, uniID, mean)	# Mean heterospecific density across individuals

conhetero7 = c(consppid^(0.7), heterosppid^(0.7))	# Mean across all con- and heterospecific densities trasnformed with D = 0.7
rtconspp7 = ((d$conspp^(0.7)) - mean(conhetero7)) / sd(conhetero7)
rtheterospp7 = ((d$heterospp^(0.7)) - mean(conhetero7)) / sd(conhetero7)

elevid = tapply(d$ELEVATION, uniID, mean)			# Mean Elevation across individuals (Elevation not used in first modeling step below)
dbhid = tapply(d$DBH_prev, uniID, mean)			# Mean DBH across individuals
yrid = tapply(d$julian_prev/365.25, uniID, mean)	# Census year
ELEV = (d$ELEVATION - mean(elevid)) / sd(elevid)	# Scaled Elevation (not used in first modeling step below)
dbh = (d$DBH_prev - mean(dbhid)) / sd(dbhid)		# Scaled DBH
yr = ((d$julian_prev/365.25) - mean(yrid)) / sd(yrid)	# Scaled census year
yr2 = yr^2								# census year squared
census = as.numeric(as.character(factor(as.character(d$census)))) - 1		# Census number (different from 'tinterval', all trees surveyed at the same timeframe (within a few years) receive the same value for census, but 'tinterval' depends on each individual tree and when they were first surveyed
sp = as.numeric(factor(as.character(d$sp)))			# unique numeric value for each species
sp.info = unique(data.frame(sp.name = d$sp, sp = sp))		# information table with each species' code
plotsp = as.numeric(factor(as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID)))))		# unique ID for each plot-by-species combination
plotsp.info = unique(data.frame(sp = d$sp, plot = d$STANDID, combo = as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID))), plotELEV = ELEV, plotsp = plotsp))	# 'plotsp' key
plotcen = as.numeric(factor(as.character(factor(as.character(d$STANDID)):factor(as.character(d$census)))))		# Unique ID for each plot-by-census combination
plotcen.info = unique(data.frame(yr = d$census, plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID)):factor(as.character(d$census))), plotELEV = ELEV, census = plotcen))	# 'plotcen' key
n.census = length(unique(census))	# number of censuses
n.ID = length(unique(uniID))		# number of unique individuals
n = nrow(d)					# number of observations
spINplot = plotsp.info$sp[order(plotsp.info$plotsp)]
plotELEV = plotsp.info$plotELEV[order(plotsp.info$plotsp)]
plotnum = as.numeric(factor(as.character(factor(as.character(d$STANDID)))))	# numeric ID for each plot
plot.info = unique(data.frame(plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID))), plotELEV = ELEV, plotnum = plotnum))	# 'plotnum' key


adult.off.abs.growth.m7 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp7 + rtheterospp7 + dbh:rtconspp7 + dbh:rtheterospp7 +  
	(rtconspp7 + rtheterospp7 + dbh|sp) + (rtconspp7 + rtheterospp7|plotnum) + (rtconspp7 + rtheterospp7|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m7)









#######################################################################################
### BAYESIAN MODEL OF ADULT GROWTH	

d = fd.focal.grow7[order(fd.focal.grow7$uniqueID, fd.focal.grow7$census),]
d = d[which(d$sizeclass == 2),]	# Trees in the 15-25 cm sizeclass

DenExp = 0.7		# D parameter (nonlinearity parameter selected during LMER analysis above)
d = d[order(d$uniqueID,d$census),]

# Prepare data for analysis (for description of variables, please see annotated LMER data set-up code above)
d$ID = as.character(d$uniqueID)
uniID = as.numeric(factor(d$uniqueID))
consppid = tapply(d$conspp, uniID, mean)
heterosppid = tapply(d$heterospp, uniID, mean)
growth = c(scale(log(d$growth.per.yr+1)))
conhetero = c(consppid^(DenExp), heterosppid^(DenExp))
density1 = std.conhet.density(conspp = d$conspp, heterospp = d$heterospp, id = uniID, DenExp = DenExp)
conspp = density1[[1]]
heterospp = density1[[2]]
elevid = tapply(d$ELEVATION, uniID, mean)
dbhid = tapply(d$DBH_prev, uniID, mean)
yrid = tapply(d$julian_prev/365.25, uniID, mean)
ELEV = (d$ELEVATION - mean(elevid)) / sd(elevid)
dbh = (d$DBH_prev - mean(dbhid)) / sd(dbhid)
yr = ((d$julian_prev/365.25) - mean(yrid)) / sd(yrid)
yr2 = yr^2
census = as.numeric(as.character(factor(as.character(d$census)))) - 1
sp = as.numeric(factor(as.character(d$sp)))
sp.info = unique(data.frame(sp.name = d$sp, sp = sp))
plotsp = as.numeric(factor(as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID)))))
plotsp.info = unique(data.frame(sp = d$sp, plot = d$STANDID, combo = as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID))), plotELEV = ELEV, plotsp = plotsp))
plotsp.n = data.frame(plotsp = names(tapply(plotsp, plotsp, length)), plotsp.n = tapply(plotsp, plotsp, length))
plotcen = as.numeric(factor(as.character(factor(as.character(d$STANDID)):factor(as.character(d$census)))))
plotcen.info = unique(data.frame(yr = d$census, plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID)):factor(as.character(d$census))), plotELEV = ELEV, census = plotcen))
uniID = as.numeric(factor(d$uniqueID))
n.census = length(unique(census))
n.ID = length(unique(uniID))
n.plotcen = length(unique(plotcen))
plotnum = as.numeric(factor(as.character(factor(as.character(d$STANDID)))))
plot.info = unique(data.frame(plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID))), plotELEV = ELEV, plotnum = plotnum))
n = nrow(d)
x = cbind(rep(1,times = n), dbh, yr, yr2, conspp, heterospp, conspp*dbh, heterospp*dbh)
K = ncol(x)
PX = cbind(rep(1,times = n), conspp, heterospp)
PK = ncol(PX)
PJ = length(unique(plotsp))
RX = cbind(rep(1,times = n), conspp, heterospp)
RK = ncol(RX)
RJ = length(unique(plotnum))
SX = cbind(rep(1,times = n), conspp, heterospp, dbh)
SK = ncol(SX)
SJ = length(unique(sp))
spINplot = plotsp.info$sp[order(plotsp.info$plotsp)]
plotELEV = plotsp.info$plotELEV[order(plotsp.info$plotsp)]


# Split data for censored regression (many zeros that are likely negative growth)

U = unique(growth[which(d$growth.per.yr == 0)])		# censor point

nonzero = which(growth != U)
zeros = which(growth == U)
growth.nonzero = growth[nonzero]
x.nonzero = x[nonzero,]
PX.nonzero = PX[nonzero,]
RX.nonzero = RX[nonzero,]
SX.nonzero = SX[nonzero,]
plotsp.nonzero = plotsp[nonzero]
plotnum.nonzero = plotnum[nonzero]
sp.nonzero = sp[nonzero]
uniID.nonzero = uniID[nonzero]
plotcen.nonzero = plotcen[nonzero]
yr.nonzero = yr[nonzero]
n.nonzero = length(growth.nonzero)

growth.zeros = growth[zeros]
x.zeros = x[zeros,]
PX.zeros = PX[zeros,]
RX.zeros = RX[zeros,]
SX.zeros = SX[zeros,]
plotsp.zeros = plotsp[zeros]
plotnum.zeros = plotnum[zeros]
sp.zeros = sp[zeros]
uniID.zeros = uniID[zeros]
plotcen.zeros = plotcen[zeros]
yr.zeros = yr[zeros]
n.zeros = length(growth.zeros)


# Bundle data
dat <- list(y = growth.nonzero, x = x.nonzero, xZ = x.zeros, K = K, plotsp = plotsp.nonzero, plotnum = plotnum.nonzero, sp = sp.nonzero, uniID = uniID.nonzero, census = plotcen.nonzero, yr = yr.nonzero,  
	ncensus = n.plotcen, PJ = PJ, PK = PK, PX = PX.nonzero, RJ = RJ, RK = RK, RX = RX.nonzero, SJ = SJ, SK = SK, SX = SX.nonzero, nID = n.ID, N = n.nonzero, U = U, 
	plotspZ = plotsp.zeros, plotnumZ = plotnum.zeros, spZ = sp.zeros, uniIDZ = uniID.zeros, censusZ = plotcen.zeros, yrZ = yr.zeros, PXZ = PX.zeros, RXZ = RX.zeros, SXZ = SX.zeros, NZ = n.zeros)

# LMER model with ML for ranef variance estimates (once run, comment off with #)
set.seed(314)
m1 = lme4::lmer(growth ~ dbh + yr + yr2 + conspp + heterospp + conspp:dbh + heterospp:dbh + 
	(conspp + heterospp + dbh|sp) + (conspp + heterospp|plotnum) + (conspp + heterospp|plotsp) + (1|uniID) + (1|plotcen), 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(m1)



### Fit stan model 
# HMC Parameters
nchains = 5					# Number of chains to run
postburn = 4000				# Number of post-burn-in posterior samples
burnin = 500				# Number of burn-in samples
its = postburn + burnin			# Total number of samples to be drawn from posterior
thin = 10					# Rate at which to thin the posterior samples		
hmc_seed = 55406				# HMC seed for reproducibility

# Initial values from LMER model
vc <- VarCorr(m1)
sigma_SB_lmer = as.matrix(Matrix::bdiag(vc$sp))
sigma_PB_lmer = as.matrix(Matrix::bdiag(vc$plotsp))
sigma_RB_lmer = as.matrix(Matrix::bdiag(vc$plotnum))
inits <- replicate(nchains, list(
  Pz = t(data.matrix(ranef(m1)$'plotsp')),
  PL_Omega = sigma_PB_lmer,
  Ptau_unif = runif(PK),
  Rz = t(data.matrix(ranef(m1)$'plotnum')),
  RL_Omega = sigma_RB_lmer,
  Rtau_unif = runif(RK),
  Sz = t(data.matrix(ranef(m1)$'sp')),
  SL_Omega = sigma_SB_lmer,
  Stau_unif = runif(SK),
  beta = fixef(m1),
  sigma_ID = attr(summary(m1)$varcor$uniID,"stddev")[[1]], 
  uniqueID = ranef(m1)$'uniID'[[1]], 
  sigma_YEAR = attr(summary(m1)$varcor$plotcen,"stddev")[[1]],
  YEAR = ranef(m1)$'plotcen'[[1]], 
  PB = data.matrix(ranef(m1)$'plotsp'), 
  sigma_PB = sigma_PB_lmer, 
  Ptau = runif(PK), 
  RB = data.matrix(ranef(m1)$'plotnum'), 
  sigma_RB = sigma_RB_lmer, 
  Rtau = runif(RK), 
  SB = data.matrix(ranef(m1)$'sp'), 
  sigma_SB = sigma_SB_lmer, 
  Stau = runif(SK),
  sigma_res = summary(m1)$sigma, 
  yZ = rep(1.1*U, times = n.zeros)
), simplify = F)


# Run model
begin = Sys.time()
fit <- stan(file = "HJA_GLMM_CENSORED_Growth_Model.stan", 			# Stan model
  data = dat,   										# named list of data
  init = inits,										# initial values for parameters
  chains = nchains,             							# number of Markov chains
  warmup = burnin,          								# number of warmup iterations per chain
  iter = its,            								# total number of iterations per chain
  cores = nchains,              							# number of cores (could use one per chain)
  thin = thin,										# Thin rate
  seed = hmc_seed,									# HMC seed for reproducibility
  control = list(adapt_delta = 0.99, max_treedepth = 15)			# HMC sampling parameters
  )
end = Sys.time()
(duration = end - begin)

# save(fit, file = "HJA_15to25cmDBH_Growth_Bayesian_alpha1-1_beta0-2_exp0-7_censored_STAN_20210912_DBHre.RData")

# load("HJA_15to25cmDBH_Growth_Bayesian_alpha1-1_beta0-2_exp0-7_censored_STAN_20210912_DBHre.RData")





# Extract estimates 
draws <- extract(fit, permuted = FALSE)
beta.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta")])),3,c)
SB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB")])),3,c)
SB.m = array(SB.m, dim = c(nrow(SB.m),SJ,SK), dimnames = list(paste("it",c(1:nrow(SB.m)),sep=""),paste("sp",c(1:SJ),sep=""),paste("SB",c(1:SK),sep="")))
PB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB")])),3,c)
PB.m = array(PB.m, dim = c(nrow(PB.m),PJ,PK), dimnames = list(paste("it",c(1:nrow(PB.m)),sep=""),paste("plotsp",c(1:PJ),sep=""),paste("PB",c(1:PK),sep="")))
RB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,2) == "RB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "RB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "RB")])),3,c)
RB.m = array(RB.m, dim = c(nrow(RB.m),RJ,RK), dimnames = list(paste("it",c(1:nrow(RB.m)),sep=""),paste("plotsp",c(1:RJ),sep=""),paste("RB",c(1:RK),sep="")))
census.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")])),3,c)
plotcen.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")])),3,c)
sigmaSB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB")])),3,c)
sigmaPB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB")])),3,c)
sigmaRB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_RB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_RB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_RB")])),3,c)
sigmaYR.m = c(draws[,,"sigma_YEAR"])
sigmaID.m = c(draws[,,"sigma_ID"])
sigmaRES.m = c(draws[,,"sigma_res"])
yZ.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,2) == "yZ")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "yZ"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "yZ")])),3,c)
ID.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,8) == "uniqueID")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "uniqueID"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "uniqueID")])),3,c)

fittedindex = which(substr(attributes(draws)$dimnames$parameters,1,6) == "fitted")
fittedindex = fittedindex[which(fittedindex %in% which(substr(attributes(draws)$dimnames$parameters,1,7) == "fittedZ") == F)]

fittedvalues = apply(array(draws[,,fittedindex], dim = c((dim(draws)[1]), dim(draws)[2], length(fittedindex)),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[fittedindex])),3,c)
fittedvaluesZ = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,7) == "fittedZ")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,7) == "fittedZ"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,7) == "fittedZ")])),3,c)

# Estimates
t(apply(beta.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(beta.m,2,mean)
t(apply(sigmaSB.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(sigmaSB.m,2,mean)
t(apply(sigmaPB.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(sigmaPB.m,2,mean)
t(apply(sigmaRB.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(sigmaRB.m,2,mean)
quantile(sigmaYR.m^2,c(0.025,0.975,0.05,0.95,0.5)); mean(sigmaYR.m^2)
quantile(sigmaID.m^2,c(0.025,0.975,0.05,0.95,0.5)); mean(sigmaID.m^2)
quantile(sigmaRES.m^2,c(0.025,0.975,0.05,0.95,0.5)); mean(sigmaRES.m^2)









# Posterior point-wise log-likelihoods
Z = length(sigmaYR.m)
fitted.m = matrix(NA,nrow=Z,ncol=n)
log_lik = matrix(NA,nrow=Z,ncol=n)
res = matrix(NA,nrow=Z,ncol=n)
for(z in 1:Z) {
  SBbysp = matrix(NA,nrow=n,ncol=SK)
  for(i in 1:n) {SBbysp[i,] = SB.m[z,sp[i],]}
  RBbyplotsp = matrix(NA,nrow=n,ncol=RK)
  for(i in 1:n) {RBbyplotsp[i,] = RB.m[z,plotnum[i],]}
  PBbyplotsp = matrix(NA,nrow=n,ncol=PK)
  for(i in 1:n) {PBbyplotsp[i,] = PB.m[z,plotsp[i],]}
  IDbyind = c()
  for(i in 1:n) {IDbyind[i] = ID.m[z,uniID[i]]}
  YRbycensus = c()
  for(i in 1:n) {YRbycensus[i] = census.m[z,plotcen[i]]}
  fitted.m[z,] = (x %*% beta.m[z,]) + rowSums(SX*SBbysp) + rowSums(RX*RBbyplotsp) + rowSums(PX*PBbyplotsp) + IDbyind + YRbycensus
  for(i in 1:length(growth)) {
    if(growth[i] != U) {log_lik[z,i] = dnorm(growth[i], mean = fitted.m[z,i], sd = sigmaRES.m[z], log = T)}
    if(growth[i] == U) {log_lik[z,i] = pnorm(growth[i], mean = fitted.m[z,i], sd = sigmaRES.m[z], log = T)}
  }
}
loglik.m = rowSums(log_lik)
dev.m = rowSums(log_lik)*-2

# logLik and dev at mean posterior parameters
beta.mean = apply(beta.m, 2, mean)
SB.mean = apply(SB.m,c(2,3),mean)
RB.mean = apply(RB.m,c(2,3),mean)
PB.mean = apply(PB.m,c(2,3),mean)
ID.mean = apply(ID.m, 2, mean)
census.mean = apply(census.m, 2, mean)
  SBbysp = matrix(NA,nrow=n,ncol=SK)
  for(i in 1:n) {SBbysp[i,] = SB.mean[sp[i],]}
  RBbyplotnum = matrix(NA,nrow=n,ncol=RK)
  for(i in 1:n) {RBbyplotnum[i,] = RB.mean[plotnum[i],]}
  PBbyplotsp = matrix(NA,nrow=n,ncol=PK)
  for(i in 1:n) {PBbyplotsp[i,] = PB.mean[plotsp[i],]}
  IDbyind = c()
  for(i in 1:n) {IDbyind[i] = ID.mean[uniID[i]]}
  YRbycensus = c()
  for(i in 1:n) {YRbycensus[i] = census.mean[plotcen[i]]}
fitted.meanpar = (x %*% beta.mean) + rowSums(SX*SBbysp) + rowSums(RX*RBbyplotnum) + rowSums(PX*PBbyplotsp) + IDbyind + YRbycensus
logLik.meanpar = c()
  for(i in 1:length(growth)) {
    if(growth[i] != U) {logLik.meanpar[i] = dnorm(growth[i], mean = fitted.meanpar[i], sd = mean(sigmaRES.m), log = T)}
    if(growth[i] == U) {logLik.meanpar[i] = pnorm(growth[i], mean = fitted.meanpar[i], sd = mean(sigmaRES.m), log = T)}
  }
logLik.meanpar.sum = sum(logLik.meanpar)
dev.meanpar = -2 * logLik.meanpar.sum
pD = mean(dev.m) - dev.meanpar
DIC = dev.meanpar + (2*pD)
dev.meanpar; pD; DIC







# Approximate leave-one-out fit metrics
library(loo)
begin = Sys.time()
r_eff <- relative_eff(exp(log_lik), chain_id = rep(1:5,each=400), cores = 5)
loo_1 <- loo(log_lik, r_eff = r_eff, cores = 5)
end = Sys.time()
(duration = end - begin)
print(loo_1)


# save(loo_1, file = "HJA_Growth_15to25cmDBH_LOO_DBHre.RData")







#########################################################################
## Simulated Residual Plots - using DHARMa package

begin.time = Sys.time()
Z = length(sigmaYR.m)
pred.growth.m = matrix(NA,nrow=Z,ncol=n)
for(z in 1:Z) {
  SBfit = SB.m[z,,]
  PBfit = PB.m[z,,]
  RBfit = RB.m[z,,]
  YRfit = plotcen.m[z,]
  IDfit = ID.m[z,]

  # Predicted values 
  set.seed(314)
  fixef.pred = (x %*% beta.m[z,])
  for(i in 1:n) {
    pred.growth.m[z,i] = fixef.pred[i] + (SX[i,] %*% SBfit[sp[i],]) + (RX[i,] %*% RBfit[plotnum[i],]) + (PX[i,] %*% PBfit[plotsp[i],]) + YRfit[plotcen[i]] + IDfit[uniID[i]]
  }
}
end.time = Sys.time()
(duration = end.time - begin.time)

set.seed(314)
rep2.m = list()
for(i in 1:nrow(pred.growth.m)){
	rep2.m[[i]] = as.numeric(rnorm(n = length(pred.growth.m[i,]), mean = pred.growth.m[i,], sd = sigmaRES.m[i]))
	censored = sample(which(rep2.m[[i]] < U), size = length(zeros), replace = F)
	rep2.m[[i]][censored] = U
}
rep2.m = do.call('rbind', rep2.m)


sim2 = createDHARMa(simulatedResponse = t(rep2.m), observedResponse = growth, fittedPredictedResponse = apply(pred.growth.m, 2, median))
plot(sim2)
plotResiduals(sim2, xlab = "Scaled predicted growth")
plotResiduals(sim2, form = conspp, xlab = "Scaled conspecific density")
plotResiduals(sim2, form = heterospp, xlab = "Scaled heterospecific density")
plotResiduals(sim2, form = dbh, xlab = "Scaled DBH")
plotResiduals(sim2, form = factor(sp), xlab = "Scaled species ID")
plotResiduals(sim2, form = factor(plotnum), xlab = "Scaled species ID")
plotResiduals(sim2, form = factor(plotsp), xlab = "Scaled plot-by-species ID")
plotResiduals(sim2, form = factor(plotcen), xlab = "Scaled plot-by-census ID")



#pdf("HJA_15-25cmDBH_DBHre_Growth_Bayesian_residual_plots_main_20210914.pdf", height = 5, width = 9, useDingbats=FALSE)
plot(sim2, quantreg = F)
#dev.off()

#pdf("HJA_15-25cmDBH_DBHre_Growth_Bayesian_residual_plots_predictors_20210914.pdf", height = 9, width = 8, useDingbats=FALSE)
set.seed(314)
par(mfrow=c(3,2))
par(mar=c(4,4,2,2))
plotResiduals(sim2, form = conspp, xlab = "Scaled conspecific density")
plotResiduals(sim2, form = heterospp, xlab = "Scaled heterospecific density")
plotResiduals(sim2, form = dbh, xlab = "Scaled DBH")
plotResiduals(sim2, form = factor(sp), xlab = "Scaled species ID")
plotResiduals(sim2, form = factor(plotnum), xlab = "Scaled species ID")
plotResiduals(sim2, form = factor(plotcen), xlab = "Scaled plot-by-census ID")
#dev.off()







# Posterior predictive checks - log-likelihood comparison
logliks.sim = matrix(NA,nrow=Z,ncol=n)
for(z in 1:nrow(rep2.m)){
  for(i in 1:ncol(rep2.m)) {
    if(rep2.m[z,i] != U) {logliks.sim[z,i] = dnorm(rep2.m[z,i], mean = pred.growth.m[z,i], sd = sigmaRES.m[z], log = T)}
    if(rep2.m[z,i] == U) {logliks.sim[z,i] = pnorm(rep2.m[z,i], mean = pred.growth.m[z,i], sd = sigmaRES.m[z], log = T)}
  }
}
loglik.sim = rowSums(logliks.sim)

# LogLik comparison
#pdf("HJA_15to25cmDBH_Growth_DBHre_logLik_PPC_BAYES_20210914.pdf", height = 4, width = 5, useDingbats=FALSE)
hist(loglik.sim, breaks=30, xlim=c(range(loglik.sim,median(loglik.m), na.rm=T)), xlab = "Log-likelihood of simulated data", 
	col = "gray85", las = 1, main = "15-25 cm DBH growth log-likelihood PPC")
abline(v = mean(loglik.m), lwd = 2, col = "red")
sum(loglik.sim > mean(loglik.m)) / nrow(rep2.m)
#dev.off()


# What proportion of actual response data falls outside min and max of simulated data
test = apply(rep2.m, 1, function(x) {length(which(growth < min(x) | growth > max(x)))/length(growth)})
summary(test)


# Prediction test
diffp = c()
for(i in 1:nrow(d)) {
diffp[i] = length(which(rep2.m[,i] > growth[i])) / length(rep2.m[,i])
}
diffp2 = diffp
diffp2[which(diffp2 > 0.5)] = 1 - diffp2[which(diffp2 > 0.5)] 
hist(diffp2,breaks=50)
1 - length(which(diffp>0.975|diffp<0.025))/length(diffp)	# Percent of the data that are predicted (within 95% Credible interval of predictions)
1 - length(which(diffp2<0.025))/length(diffp2)	# Percent of the data that are predicted (within 95% Credible interval of predictions)




















###################################################################################
# CNDD average predictive comparisons and visualize model

load("Standclimate2.RData")
names(standclimate2)[1] = "plot"

DenExp = 0.7		# D parameter (nonlinearity parameter) selected based on data
StdAdultDen = 166.0877	# Mean tree density across all tree neighborhoods with parameters Alpha = 1.1 and Beta = 0.2
zerotree = (0 - mean(conhetero)) / sd(conhetero)					# Standardized density index with zero trees (only used to calculate separate conspecific and heterospecific effects, not for CDD-HDD)
onetree = ((StdAdultDen^DenExp) - mean(conhetero)) / sd(conhetero)		# Standardized density index at mean tree density (for comparing conspecific stand to heterospecific stand)
halftree = (((StdAdultDen/2)^DenExp) - mean(conhetero)) / sd(conhetero)		# Standardized density index at half of mean tree density (for determining survival in a stand composed of half conspecifics and half heterospecifics)
meanGrowth = mean(log(d$growth.per.yr + 1)); sdGrowth = sd(log(d$growth.per.yr + 1))
growth.trans = function(x) {exp((x * sdGrowth) + meanGrowth) - 1}
consppid = tapply(d$conspp, uniID, mean)
heterosppid = tapply(d$heterospp, uniID, mean)
plotsp.info2 = plotsp.info[order(plotsp.info$plotsp),]
names(plotsp.info2)[1] = "sp.name"
plotsp.info2 = merge(plotsp.info2, sp.info, by = "sp.name", all = T, sort = FALSE)
plotsp.info2 = merge(plotsp.info2, plot.info[,c("plot", "plotnum")], by = "plot", all.x = T, sort = FALSE)
plotsp.info2 = merge(plotsp.info2, standclimate2, by = "plot", all.x = T, sort = FALSE)
load("HJA_Species_Mean_Abundances_across_Censuses_by_Plot.RData")			# Add in species abundances for CDD-HDD and species abundance relationships
abund$ba.ha = abund$ba / abund$area_ha
abund$abund.ha = abund$abund / abund$area_ha
names(abund)[2] = "sp.name"
plotsp.info2 = merge(plotsp.info2, abund, by = c("sp.name", "plot"), all.x = T, sort = FALSE)
plotsp.info2 = merge(plotsp.info2, plotsp.n, by = "plotsp", all.x = T, sort = FALSE)
plotsp.info2 = plotsp.info2[order(plotsp.info2$plotsp),]
plot.info3 = unique(plotsp.info2[,c("plot", "plotELEV", "plotnum", "ELEVATION", "LATITUDE", "LONGITUDE", "meansummertemppts", "meanspringtemppts", "minspringtemppts", "area_ha")])
plot.info3 = plot.info3[order(plot.info3$plotnum),]
plot = as.numeric(as.factor(d$STANDID))

# Data for avg. perdictive comparisons (Hi = "high" conspecific density; defined as mean density of trees, all conspecifics)
xHi = cbind(rep(1,times = n), dbh, yr, yr2, onetree, zerotree, onetree*dbh, zerotree*dbh)	
PXHi = cbind(rep(1,times = n), onetree, zerotree)		# Plot-by-species predictor matrix
RXHi = cbind(rep(1,times = n), onetree, zerotree)		# Plot predictor matrix
SXHi = cbind(rep(1,times = n), onetree, zerotree, dbh)		# Species predictor matrix

# Data for avg. perdictive comparisons (Lo = "low" conspecific density; defined as mean density of trees, all heterospecifics)
xLo = cbind(rep(1,times = n), dbh, yr, yr2, zerotree, onetree, zerotree*dbh, onetree*dbh)	
PXLo = cbind(rep(1,times = n), zerotree, onetree)		# Plot-by-species predictor matrix
RXLo = cbind(rep(1,times = n), zerotree, onetree)		# Plot predictor matrix
SXLo = cbind(rep(1,times = n), zerotree, onetree, dbh)		# Species predictor matrix

# Data for avg. perdictive comparisons (No = No large trees (>15 cm DBH), i.e. gap)
xNo = cbind(rep(1,times = n), dbh, yr, yr2, zerotree, zerotree, zerotree*dbh, zerotree*dbh)	
PXNo = cbind(rep(1,times = n), zerotree, zerotree)		# Plot-by-species predictor matrix
RXNo = cbind(rep(1,times = n), zerotree, zerotree)		# Plot predictor matrix
SXNo = cbind(rep(1,times = n), zerotree, zerotree, dbh)		# Species predictor matrix

# Data for avg. perdictive comparisons (Mid = "intermediate" conspecific density; defined as mean density of trees, half conspecifics & half heterospecifics)
xMid = cbind(rep(1,times = n), dbh, yr, yr2, halftree, halftree, halftree*dbh, halftree*dbh)	
PXMid = cbind(rep(1,times = n), halftree, halftree)		# Plot-by-species predictor matrix
RXMid = cbind(rep(1,times = n), halftree, halftree)		# Plot predictor matrix
SXMid = cbind(rep(1,times = n), halftree, halftree, dbh)		# Species predictor matrix



# Calculate average predictive comparisons for each plot-by-species (Gelman & Pardoe 2007, Gustafson 2007)

realcndd.plotsp = list()
realcdd.plotsp = list()
realhdd.plotsp = list()
meangrowth.plotsp = list()

begin.time = Sys.time()
for(j in 1:PJ) {
  Z = length(sigmaYR.m)
  realcndd.m = matrix(NA,nrow=Z,ncol=n)
  realcdd.m = matrix(NA,nrow=Z,ncol=n)
  realhdd.m = matrix(NA,nrow=Z,ncol=n)
  meangrowth.m = matrix(NA,nrow=Z,ncol=n)
  for(z in 1:Z) {							# Prepare model matrices for predictions
    SBbysp = matrix(NA,nrow=n,ncol=SK)
    for(i in 1:n) {SBbysp[i,] = SB.m[z,plotsp.info2$sp[j],]}
    RBbyplotnum = matrix(NA,nrow=n,ncol=RK)
    for(i in 1:n) {RBbyplotnum[i,] = RB.m[z,plotsp.info2$plotnum[j],]}
    PBbyplotsp = matrix(NA,nrow=n,ncol=PK)
    for(i in 1:n) {PBbyplotsp[i,] = PB.m[z,plotsp.info2$plotsp[j],]}
    YRbycensus = c()
    for(i in 1:n) {YRbycensus[i] = plotcen.m[z,plotcen[i]]}
    IDbyind = c()
    for(i in 1:n) {IDbyind[i] = ID.m[z,uniID[i]]}
    growthHi = growth.trans((xHi %*% beta.m[z,]) + rowSums(SXHi*SBbysp) + rowSums(RXHi*RBbyplotnum) + rowSums(PXHi*PBbyplotsp) + YRbycensus + IDbyind)	# Predicted annual growth rate in conspecific stand
    growthLo = growth.trans((xLo %*% beta.m[z,]) + rowSums(SXLo*SBbysp) + rowSums(RXLo*RBbyplotnum) + rowSums(PXLo*PBbyplotsp) + YRbycensus + IDbyind)	# Predicted annual growth rate in heterospecific stand
    growthNo = growth.trans((xNo %*% beta.m[z,]) + rowSums(SXNo*SBbysp) + rowSums(RXNo*RBbyplotnum) + rowSums(PXNo*PBbyplotsp) + YRbycensus + IDbyind)	# Predicted annual growth rate in absence of con/heterospecific competitors (gap)
    growthMid = growth.trans((xMid %*% beta.m[z,]) + rowSums(SXMid*SBbysp) + rowSums(RXMid*RBbyplotnum) + rowSums(PXMid*PBbyplotsp) + YRbycensus + IDbyind)	# Predicted annual growth rate in a half-conspecific, half-heterospecific stand (to assess mean growth rates)
    realcndd.m[z,] = growthHi - growthLo			# Calculate CDD-HDD by comparing predicted annual growth in a conspecific stand to predicted annual growth in a heterospecific stand (each at mean tree density)
    realcdd.m[z,] = growthHi - growthNo			# Calculate CDD by comparing predicted annual growth in a conspecific stand to predicted annual growth in the absence of competition
    realhdd.m[z,] = growthLo - growthNo			# Calculate HDD by comparing predicted annual growth in a heterospecific stand to predicted annual growth in the absence of competition
    meangrowth.m[z,] = growthMid				# Calculate mean predicted annual growth as predicted annual growth in a half-conspecific, half-heterospecific stand (at mean total tree density)
  }
realcndd.plotsp[[j]] = apply(realcndd.m, 1, mean)	# Calculate average predictive comparison for CDD-HDD (by averaging over all data for each posterior sample)
realcdd.plotsp[[j]] = apply(realcdd.m, 1, mean)		# Calculate average predictive comparison for CDD (by averaging over all data for each posterior sample)
realhdd.plotsp[[j]] = apply(realhdd.m, 1, mean)		# Calculate average predictive comparison for HDD (by averaging over all data for each posterior sample)
meangrowth.plotsp[[j]] = apply(meangrowth.m, 1, mean)	# Calculate average predictive comparison for mean survival (by averaging over all data for each posterior sample)
}
end.time = Sys.time()
(duration = end.time - begin.time)

realcndd.plotsp = do.call('cbind', realcndd.plotsp)
realcdd.plotsp = do.call('cbind', realcdd.plotsp)
realhdd.plotsp = do.call('cbind', realhdd.plotsp)
meangrowth.plotsp = do.call('cbind', meangrowth.plotsp)

# save(realcndd.plotsp, realcdd.plotsp, realhdd.plotsp, meangrowth.plotsp, file = "HJA_Growth_15-25cmDBH_realcndd_matrices_20211123_wDBHre.RData")
# load("HJA_Growth_15-25cmDBH_realcndd_matrices_20211123_wDBHre.RData")


# Average predictive comparison for each plot-by-species combination
realcndd.plotspAPC = apply(realcndd.plotsp, 2, mean)


# Plot-level average predictive comparisons
plotsp.w = tapply(plotsp, plotsp, length)
plot.index = tapply(plot, plotsp, median)

realcndd.plotnum = list()
for(i in 1:RJ) {
  if(sum(plot.index == i) > 1) {realcndd.plotnum[[i]] = apply(realcndd.plotsp[,which(plot.index == i)], 1, weighted.mean, w = plotsp.w[which(plot.index == i)])}
  if(sum(plot.index == i) == 1) {realcndd.plotnum[[i]] = realcndd.plotsp[,which(plot.index == i)]}
}
realcndd.plotnum = do.call('cbind', realcndd.plotnum)


#####################################################################################
# Optional Bayesian bootstrap reflecting subsampling of species within plots 
# (unnecessary b/c not subsampling species within plot -- these are full plot censuses
# and inculde data on all tree species in these size classes across the entire 6,400 ha HJA watershed)
#
#Zits = 10
#realcndd.plotnuma = matrix(NA, nrow = (Z * Zits), ncol = RJ)
#set.seed(314)
#for(j in 1:RJ) {
#  realcndd.plotnumalist = list()
#  for(z in 1:Z) {
#    realcndd.plotnumalist[[z]] = bayesian.bootstrap(test_sample = realcndd.plotsp[z,which(plot.index == j)], nIts = Zits, sample.weights = c(plotsp.w[which(plot.index == j)]))
#  }
#  realcndd.plotnuma[,j] = do.call('rbind', realcndd.plotnumalist)
#}
#realcndd.plotnum = realcndd.plotnuma
#####################################################################################




# Pairwise plot comparisons
pdmat = matrix(NA, nrow = 23, ncol = 23)
for(i in 1:RJ) {
for(j in 1:RJ) {
pdmat[i,j] = sum((realcndd.plotnum[,i] - realcndd.plotnum[,j]) < 0) / length(realcndd.plotnum[,i])
}}
pdmat2=pdmat
pdmat2[pdmat > 0.05 & pdmat < 0.95] = NA
diag(pdmat2) <- NA
pdmat2
plot.info3
problow = c()
probhi = c()
for(i in 1:23) {
  probhi[i] = sum(pdmat2[,i] >= 0.95, na.rm = T)
  problow[i] = sum(pdmat2[,i] <= 0.05, na.rm = T)
}

# For plot-level predictive comparisons:
# red = >95% probability of being lower than at least 5 other plots, >95% probability of being higher than none
# orange = >95% probability of being lower than at least 1 other plot, >95% probability of being higher than none
# green = >95% probability of being lower than at least 1 other plot, >95% probability of being higher than at least 1 other plot
# blue = >95% probability of being lower than no other plots, >95% probability of being higher than at least 1 other plot
# purple = >95% probability of being lower than no other plots, >95% probability of being higher than at least 5 other plots

probcol = data.frame(plot = plot.info3$plot, plotnum = plot.info3$plotnum, problow, probhi, 
	probcol = c("green", "red", "red", "purple", "purple", "orange", "purple", "green", "blue", "red", "purple", 
	"blue", "purple", "green", "purple", "green", "red", "green", "red", "orange", "green", "red", "green"))



# Display plot-level and plot-by-species level predictive comparisons against elevation

# pdf("HJA_15-25cmDBH_Growth_Hazard_CDD-HDD_BAYES_Elev_byPlot_20220202.pdf", height = 10, width = 5, useDingbats=FALSE)
par(pty="s")
par(mfrow=c(2,1))
set.seed(314)
elevjit = jitter(plot.info3$ELEVATION, amount = 15)
elevjit2 = data.frame(elevjit, plot = plot.info3$plot)
plotsp.info5 = merge(plotsp.info2, elevjit2, by = "plot", all.x = T)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]
plotsp.info5$points = realcndd.plotspAPC
plot(plotsp.info5$elevjit, realcndd.plotspAPC, cex.axis = 1.2, las = 1, ylim=c(min(realcndd.plotspAPC),max(realcndd.plotspAPC)),
	main = "15-25 cm DBH", type = "n", ylab = "", xlab = "Elevation (m)", cex.lab = 1.2)
mtext("Change in growth from CNDD", side = 2, line = 4, cex = 1.2)
abline(h=0,lty=2)

plotmedians = apply(realcndd.plotnum, 2, median)
plotlci = apply(realcndd.plotnum, 2, quantile, 0.025)
plotuci = apply(realcndd.plotnum, 2, quantile, 0.975)
plotliq = apply(realcndd.plotnum, 2, quantile, 0.25)
plotuiq = apply(realcndd.plotnum, 2, quantile, 0.75)

for(i in 1:RJ) {
colwd = 15
medwd = 0.003
transp1 = 0.15
transp2 = 0.3
points(plotsp.info5$elevjit[which(plotsp.info5$plotnum == i)], plotsp.info5$points[which(plotsp.info5$plotnum == i)], 
	cex = (plotsp.info5$plotsp.n[which(plotsp.info5$plotnum == i)]*0.03)^(1/4), col =  adjustcolor(probcol$probcol[i], alpha.f = 0.8))
polygon(x = c(elevjit[i]-(colwd/2), elevjit[i]+(colwd/2),elevjit[i]+(colwd/2), elevjit[i]-(colwd/2)), 
	y = c(plotlci[i], plotlci[i], plotuci[i], plotuci[i]),
        col =  adjustcolor(probcol$probcol[i], alpha.f = transp1), border = NA)
polygon(x = c(elevjit[i]-(colwd/2), elevjit[i]+(colwd/2),elevjit[i]+(colwd/2), elevjit[i]-(colwd/2)), 
	y = c(plotliq[i], plotliq[i], plotuiq[i], plotuiq[i]),
        col =  adjustcolor(probcol$probcol[i], alpha.f = transp2), border = NA)
polygon(x = c(elevjit[i]-(colwd/2), elevjit[i]+(colwd/2),elevjit[i]+(colwd/2), elevjit[i]-(colwd/2)), 
	y = c(plotmedians[i]-(medwd/2), plotmedians[i]-(medwd/2), plotmedians[i]+(medwd/2), plotmedians[i]+(medwd/2)),
        col =  probcol$probcol[i], border = NA)
}

# Panel 2: species-by-plot combos IDed 
sp.info2 = data.frame(sp.info[order(sp.info$sp),])
load("HJA_CNDD_Analyses_Species_Colors_for_figures.RData")
sp.info2 = merge(sp.info2, sp.col[,c("sp.name", "sp.col", "sp.pch")], by = "sp.name", all.x = T)
sp.col2 = data.frame(sp = sp.col$sp.name, sp.col = sp.col$sp.col, sp.pch = sp.col$sp.pch)
plotsp.info5 = merge(plotsp.info5, sp.info2, by = "sp", all.x = T, sort = F)

# Plot CDD-HDD estiamtes across plots and species (posterior means)
plot(plotsp.info5$elevjit, realcndd.plotspAPC, 
	xlab = "Elevation (m)", ylab = "", cex.lab = 1.2,
	pch=19, las=1, main = "15-25 cm DBH", type = "n", cex.axis = 1.2)
mtext("Change in growth from CNDD", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
set.seed(314)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info5[which(plotsp.info5$sp == sp.info2$sp[i]),]
points(plot.subset$elevjit, plot.subset$points, cex = (plot.subset$plotsp.n*0.02)^(1/4), 
	col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)
	}

# dev.off()






# Plot-level predictive comparisons against PC2 of Elevation and mean summer temperatures 
# combined effect of increasing elevation and increasing mean summer temps (Fig. S3): 
# low values of PC2 = Lower-elevation valley bottoms
# intermediate values of PC2 = Lower-elevation midslopes, higher elevation valley bottoms
# high values of PC2 = Lower-elevation ridges, hihger-elevation midslopes/ridges

# PCA of elevation and min. spring temperatures from Frey et al 2016
pc = princomp(plot.info3[,c("ELEVATION", "meansummertemppts")], cor = T)
summary(pc)
loadings(pc)
pc1 = pc$scores[,1]
pc2 = pc$scores[,2]


# Display plot-level and plot-by-species level predictive comparisons against PC2

# pdf("HJA_15-25cmDBH_Growth_Hazard_CDD-HDD_BAYES_PC2_byPlot_20220202.pdf", height = 10, width = 5, useDingbats=FALSE)
par(pty="s")
par(mfrow=c(2,1))
set.seed(314)
pc2jit = jitter(pc2, amount = 0.05)
pc1jit2 = data.frame(pc2jit, plot = plot.info3$plot)
plotsp.info5 = merge(plotsp.info2, pc1jit2, by = "plot", all.x = T)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]
plotsp.info5$points = realcndd.plotspAPC
plot(plotsp.info5$pc2jit, realcndd.plotspAPC, las = 1, cex.axis = 1.2, ylim=c(min(realcndd.plotspAPC),max(realcndd.plotspAPC)),
	ylab = "", main = "15-25 cm DBH", type = "n", xlab = "PC2", cex.lab = 1.2)
mtext("Change in growth from CNDD", side = 2, line = 4, cex = 1.2)
abline(h=0,lty=2)

plotmedians = apply(realcndd.plotnum, 2, median)
plotlci = apply(realcndd.plotnum, 2, quantile, 0.025)
plotuci = apply(realcndd.plotnum, 2, quantile, 0.975)
plotliq = apply(realcndd.plotnum, 2, quantile, 0.25)
plotuiq = apply(realcndd.plotnum, 2, quantile, 0.75)

for(i in 1:RJ) {
colwd = 0.03
medwd = 0.003
transp1 = 0.15
transp2 = 0.3
points(plotsp.info5$pc2jit[which(plotsp.info5$plotnum == i)], plotsp.info5$points[which(plotsp.info5$plotnum == i)], 
	cex = (plotsp.info5$plotsp.n[which(plotsp.info5$plotnum == i)]*0.03)^(1/4), col =  adjustcolor(probcol$probcol[i], alpha.f = 0.8))
polygon(x = c(pc2jit[i]-(colwd/2), pc2jit[i]+(colwd/2),pc2jit[i]+(colwd/2), pc2jit[i]-(colwd/2)), 
	y = c(plotlci[i], plotlci[i], plotuci[i], plotuci[i]),
        col =  adjustcolor(probcol$probcol[i], alpha.f = transp1), border = NA)
polygon(x = c(pc2jit[i]-(colwd/2), pc2jit[i]+(colwd/2),pc2jit[i]+(colwd/2), pc2jit[i]-(colwd/2)), 
	y = c(plotliq[i], plotliq[i], plotuiq[i], plotuiq[i]),
        col =  adjustcolor(probcol$probcol[i], alpha.f = transp2), border = NA)
polygon(x = c(pc2jit[i]-(colwd/2), pc2jit[i]+(colwd/2),pc2jit[i]+(colwd/2), pc2jit[i]-(colwd/2)), 
	y = c(plotmedians[i]-(medwd/2), plotmedians[i]-(medwd/2), plotmedians[i]+(medwd/2), plotmedians[i]+(medwd/2)),
        col =  probcol$probcol[i], border = NA)
}

# Panel 2: species-by-plot combos IDed 
sp.info2 = data.frame(sp.info[order(sp.info$sp),])
load("HJA_CNDD_Analyses_Species_Colors_for_figures.RData")
sp.info2 = merge(sp.info2, sp.col[,c("sp.name", "sp.col", "sp.pch")], by = "sp.name", all.x = T)
sp.col2 = data.frame(sp = sp.col$sp.name, sp.col = sp.col$sp.col, sp.pch = sp.col$sp.pch)
plotsp.info5 = merge(plotsp.info5, sp.info2, by = "sp", all.x = T, sort = F)

# Plot CDD-HDD estiamtes across plots and species (posterior means)
plot(plotsp.info5$pc2jit, realcndd.plotspAPC, 
	xlab = "PC2", ylab = "", cex.lab = 1.2, 
	pch=19, las=1, main = "15-25 cm DBH", type = "n", cex.axis = 1.2)
mtext("Change in growth from CNDD", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
set.seed(314)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info5[which(plotsp.info5$sp == sp.info2$sp[i]),]
points(plot.subset$pc2jit, plot.subset$points, cex = (plot.subset$plotsp.n*0.03)^(1/4), 
	col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)
	}

# dev.off()







# Bayesian bootstrap to obtain average CDD-HDD across all forest plots
plotnum.w = plot.info3$area_ha
Z2 = nrow(realcndd.plotnum)
Zits = 100			# Number of bootstrap iterations at each of the Z posterior samples 
realcndd.all = list()
set.seed(314)
for(z in 1:Z2) {
  realcndd.all[[z]] = bayesian.bootstrap(test_sample = realcndd.plotnum[z,], nIts = Zits, sample.weights = plotnum.w)
}
realcndd.all = do.call('c', realcndd.all)

boxplot(realcndd.all)
quantile(realcndd.all, c(0.025,0.5,0.975)); mean(realcndd.all)
sum(realcndd.all < 0) / length(realcndd.all)







# Average predictive comparisons at particular elevation bands 
# Low = 460-700 m (8 plots), Middle = 700-950 m (8 plots), High = 950-1440 m (7 plots)
plotnum.w = plot.info3$area_ha
elev.index = rep(1, times = RJ)
elev.index[which(plot.info3$ELEVATION >= 700 & plot.info3$ELEVATION < 950)] = 2
elev.index[which(plot.info3$ELEVATION >= 950)] = 3

# Bayesian bootstrap to obtain average CDD-HDD at low, mid, and high elevations
Z2 = nrow(realcndd.plotnum)
Zits = 100			# Number of bootstrap iterations at each of the Z posterior samples 
realcndd.elevs = matrix(NA, nrow = (Z2 * Zits), ncol = max(elev.index))
set.seed(314)
for(j in 1:max(elev.index)) {
  realcndd.elevlist = list()
  for(z in 1:Z2) {
    realcndd.elevlist[[z]] = bayesian.bootstrap(test_sample = realcndd.plotnum[z,which(elev.index == j)], nIts = Zits, sample.weights = plotnum.w[which(elev.index == j)])
  }
  realcndd.elevs[,j] = do.call('c', realcndd.elevlist)
}
boxplot(realcndd.elevs)

quantile(realcndd.elevs[,1], c(0.025,0.5,0.975)); mean(realcndd.elevs[,1])
sum(realcndd.elevs[,1] < 0) / length(realcndd.elevs[,1])
quantile(realcndd.elevs[,2], c(0.025,0.5,0.975)); mean(realcndd.elevs[,2])
sum(realcndd.elevs[,2] < 0) / length(realcndd.elevs[,2])
quantile(realcndd.elevs[,3], c(0.025,0.5,0.975)); mean(realcndd.elevs[,3])
sum(realcndd.elevs[,3] < 0) / length(realcndd.elevs[,3])

quantile(realcndd.elevs[,1] - realcndd.elevs[,3], c(0.025,0.5,0.975)); mean(realcndd.elevs[,1] - realcndd.elevs[,3])
sum((realcndd.elevs[,1] - realcndd.elevs[,3]) < 0) / length(realcndd.elevs[,3])
quantile(realcndd.elevs[,1] - realcndd.elevs[,2], c(0.025,0.5,0.975)); mean(realcndd.elevs[,1] - realcndd.elevs[,2])
sum((realcndd.elevs[,1] - realcndd.elevs[,2]) < 0) / length(realcndd.elevs[,3])
quantile(realcndd.elevs[,2] - realcndd.elevs[,3], c(0.025,0.5,0.975)); mean(realcndd.elevs[,2] - realcndd.elevs[,3])
sum((realcndd.elevs[,2] - realcndd.elevs[,3]) < 0) / length(realcndd.elevs[,3])

plot(plotsp.info2$ELEVATION, realcndd.plotspAPC, cex = (plotsp.info2$plotsp.n*0.03)^(1/4))







# Plot-level predictive comparisons against PC2 of Elevation and mean summer temperatures 
# combined effect of increasing elevation and increasing mean summer temps (Fig. S3): 
# low values of PC2 = Lower-elevation valley bottoms
# intermediate values of PC2 = Lower-elevation midslopes, higher elevation valley bottoms
# high values of PC2 = Lower-elevation ridges, hihger-elevation midslopes/ridges

plotnum.w = plot.info3$area_ha
pc2.index = rep(1, times = RJ)
pc2.index[which(pc2 >= -0.25 & pc2 < 0.25)] = 2
pc2.index[which(pc2 >= 0.25)] = 3
plot.info3$pc2 = pc2

# Bayesian bootstrap to obtain average CDD-HDD at low, mid, and high values of PC2
Z2 = nrow(realcndd.plotnum)
Zits = 100			# Number of bootstrap iterations at each of the Z posterior samples 
realcndd.pc2 = matrix(NA, nrow = (Z2 * Zits), ncol = max(pc2.index))
set.seed(314)
for(j in 1:max(pc2.index)) {
  realcndd.pc2list = list()
  for(z in 1:Z2) {
    realcndd.pc2list[[z]] = bayesian.bootstrap(test_sample = realcndd.plotnum[z,which(pc2.index == j)], nIts = Zits, sample.weights = plotnum.w[which(pc2.index == j)])
  }
  realcndd.pc2[,j] = do.call('c', realcndd.pc2list)
}

boxplot(realcndd.pc2)

quantile(realcndd.pc2[,1], c(0.025,0.5,0.975)); mean(realcndd.pc2[,1])
sum(realcndd.pc2[,1] < 0) / length(realcndd.pc2[,1])
quantile(realcndd.pc2[,2], c(0.025,0.5,0.975)); mean(realcndd.pc2[,2])
sum(realcndd.pc2[,2] < 0) / length(realcndd.pc2[,2])
quantile(realcndd.pc2[,3], c(0.025,0.5,0.975)); mean(realcndd.pc2[,3])
sum(realcndd.pc2[,3] < 0) / length(realcndd.pc2[,3])

quantile(realcndd.pc2[,1] - realcndd.pc2[,3], c(0.025,0.5,0.975)); mean(realcndd.pc2[,1] - realcndd.pc2[,3])
sum((realcndd.pc2[,1] - realcndd.pc2[,3]) < 0) / length(realcndd.pc2[,3])
quantile(realcndd.pc2[,1] - realcndd.pc2[,2], c(0.025,0.5,0.975)); mean(realcndd.pc2[,1] - realcndd.pc2[,2])
sum((realcndd.pc2[,1] - realcndd.pc2[,2]) < 0) / length(realcndd.pc2[,3])
quantile(realcndd.pc2[,2] - realcndd.pc2[,3], c(0.025,0.5,0.975)); mean(realcndd.pc2[,2] - realcndd.pc2[,3])
sum((realcndd.pc2[,2] - realcndd.pc2[,3]) < 0) / length(realcndd.pc2[,3])

# save(realcndd.elevs, realcndd.pc2, file = "HJA_CNDD_15-25cmDHB_Growth_Avg_Predictive_Comparisons.RData")






# Plot elevation predictive comparisons and PC2 predictive comparisons

# pdf("HJA_15-25cmDBH_Growth_Hazard_CDD-HDD_BAYES_ELEV-PC2_20220202.pdf", height = 10, width = 5, useDingbats=FALSE)
par(pty="s")
par(mfrow=c(2,1))
set.seed(314)
set.seed(314)
elevzones = c(580, 825, 1195)
elevcols = c("gray30", "gray30", "gray30")
elevjit = jitter(plot.info3$ELEVATION, amount = 15)
elevjit2 = data.frame(elevjit, plot = plot.info3$plot)
plotsp.info5 = merge(plotsp.info2, elevjit2, by = "plot", all.x = T)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]
plotsp.info5$points = realcndd.plotspAPC
plotsp.info5$elevzone = c(1)
plotsp.info5$elevzone[which(plotsp.info5$ELEVATION >= 700 & plotsp.info5$ELEVATION < 950)] = 2
plotsp.info5$elevzone[which(plotsp.info5$ELEVATION >= 950)] = 3
plotsp.info5$elevcol = c("gray30")
plotsp.info5$elevcol[which(plotsp.info5$ELEVATION >= 700 & plotsp.info5$ELEVATION < 950)] = "gray30"
plotsp.info5$elevcol[which(plotsp.info5$ELEVATION >= 950)] = "gray30"
plot(plotsp.info5$elevjit, realcndd.plotspAPC, las = 1, ylab = "", cex.lab = 1.2, cex.axis = 1.2, 
	main = "15-25 cm DBH", type = "n", xlab = "Elevation (m)")
mtext("Change in growth from CNDD", side = 2, line = 4, cex = 1.2)
abline(h=0,lty=2)

plotmedians = apply(realcndd.elevs, 2, median)
plotlci = apply(realcndd.elevs, 2, quantile, 0.025)
plotuci = apply(realcndd.elevs, 2, quantile, 0.975)
plotliq = apply(realcndd.elevs, 2, quantile, 0.25)
plotuiq = apply(realcndd.elevs, 2, quantile, 0.75)

for(i in 1:3) {
colwd = 190
medwd = 0.003
transp1 = 0.15
transp2 = 0.3
polygon(x = c(elevzones[i]-(colwd/2), elevzones[i]+(colwd/2),elevzones[i]+(colwd/2), elevzones[i]-(colwd/2)), 
	y = c(plotlci[i], plotlci[i], plotuci[i], plotuci[i]),
        col =  adjustcolor(elevcols[i], alpha.f = transp1), border = NA)
polygon(x = c(elevzones[i]-(colwd/2), elevzones[i]+(colwd/2),elevzones[i]+(colwd/2), elevzones[i]-(colwd/2)), 
	y = c(plotliq[i], plotliq[i], plotuiq[i], plotuiq[i]),
        col =  adjustcolor(elevcols[i], alpha.f = transp2), border = NA)
polygon(x = c(elevzones[i]-(colwd/2), elevzones[i]+(colwd/2),elevzones[i]+(colwd/2), elevzones[i]-(colwd/2)), 
	y = c(plotmedians[i]-(medwd/2), plotmedians[i]-(medwd/2), plotmedians[i]+(medwd/2), plotmedians[i]+(medwd/2)),
        col =  elevcols[i], border = NA)
points(plotsp.info5$elevjit[which(plotsp.info5$elevzone == i)], plotsp.info5$points[which(plotsp.info5$elevzone == i)], 
	cex = (plotsp.info5$plotsp.n[which(plotsp.info5$elevzone == i)]*0.03)^(1/4), col =  adjustcolor(plotsp.info5$elevcol[which(plotsp.info5$elevzone == i)], alpha.f = 0.8))
}

# Panel 2: Predictive comparisons specific to PC2
set.seed(314)
pc2zones = c(-0.753, 0, 0.58)
pc2cols = c("red", "red", "blue")
pc2jit = jitter(plot.info3$pc2, amount = 0.01)
pc2jit2 = data.frame(pc2jit, plot = plot.info3$plot)
plotsp.info5 = merge(plotsp.info2, pc2jit2, by = "plot", all.x = T)
plotsp.info5 = merge(plotsp.info5, plot.info3[,c("plot", "pc2")], by = "plot", all.x = T)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]
plotsp.info5$points = realcndd.plotspAPC
plotsp.info5$pc2zone = c(1)
plotsp.info5$pc2zone[which(plotsp.info5$pc2 >= -0.25 & plotsp.info5$pc2 < 0.25)] = 2
plotsp.info5$pc2zone[which(plotsp.info5$pc2 >= 0.25)] = 3
plotsp.info5$pc2col = c("red")
plotsp.info5$pc2col[which(plotsp.info5$pc2 >= -0.25 & plotsp.info5$pc2 < 0.25)] = "red"
plotsp.info5$pc2col[which(plotsp.info5$pc2 >= 0.25)] = "blue"
plot(plotsp.info5$pc2jit, realcndd.plotspAPC, las = 1, ylab = "", cex.lab = 1.2, cex.axis = 1.2, 
	main = "15-25 cm DBH", type = "n", xlab = "PC2")
mtext("Change in growth from CNDD", side = 2, line = 4, cex = 1.2)
abline(h=0,lty=2)

plotmedians = apply(realcndd.pc2, 2, median)
plotlci = apply(realcndd.pc2, 2, quantile, 0.025)
plotuci = apply(realcndd.pc2, 2, quantile, 0.975)
plotliq = apply(realcndd.pc2, 2, quantile, 0.25)
plotuiq = apply(realcndd.pc2, 2, quantile, 0.75)

for(i in 1:3) {
colwd = 0.4
medwd = 0.003
transp1 = 0.15
transp2 = 0.3
polygon(x = c(pc2zones[i]-(colwd/2), pc2zones[i]+(colwd/2),pc2zones[i]+(colwd/2), pc2zones[i]-(colwd/2)), 
	y = c(plotlci[i], plotlci[i], plotuci[i], plotuci[i]),
        col =  adjustcolor(pc2cols[i], alpha.f = transp1), border = NA)
polygon(x = c(pc2zones[i]-(colwd/2), pc2zones[i]+(colwd/2),pc2zones[i]+(colwd/2), pc2zones[i]-(colwd/2)), 
	y = c(plotliq[i], plotliq[i], plotuiq[i], plotuiq[i]),
        col =  adjustcolor(pc2cols[i], alpha.f = transp2), border = NA)
polygon(x = c(pc2zones[i]-(colwd/2), pc2zones[i]+(colwd/2),pc2zones[i]+(colwd/2), pc2zones[i]-(colwd/2)), 
	y = c(plotmedians[i]-(medwd/2), plotmedians[i]-(medwd/2), plotmedians[i]+(medwd/2), plotmedians[i]+(medwd/2)),
        col =  pc2cols[i], border = NA)
points(plotsp.info5$pc2jit[which(plotsp.info5$pc2zone == i)], plotsp.info5$points[which(plotsp.info5$pc2zone == i)], 
	cex = (plotsp.info5$plotsp.n[which(plotsp.info5$pc2zone == i)]*0.03)^(1/4), col =  adjustcolor(plotsp.info5$pc2col[which(plotsp.info5$pc2zone == i)], alpha.f = 0.8))
}

# dev.off()







##########################################################################################
# Plot seperate CDD & HDD predictive comparisons (Seperate conspecific or heterospecific effects)

realcdd.plotspAPC = apply(realcdd.plotsp,2,mean)
realhdd.plotspAPC = apply(realhdd.plotsp,2,mean)

# pdf("HJA_15-25cmDBH_Growth_Hazard_CDD_BAYES_Elev-PC2_byPlot_20220202.pdf", height = 10, width = 5, useDingbats=FALSE)
par(pty="s")
par(mfrow=c(2,1))
set.seed(314)
elevjit = jitter(plot.info3$ELEVATION, amount = 15)
elevjit2 = data.frame(elevjit, plot = plot.info3$plot)
plotsp.info5 = merge(plotsp.info2, elevjit2, by = "plot", all.x = T, sort = F)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]
plotsp.info5$points = realcdd.plotspAPC
sp.info2 = data.frame(sp.info[order(sp.info$sp),])
load("HJA_CNDD_Analyses_Species_Colors_for_figures.RData")
sp.info2 = merge(sp.info2, sp.col[,c("sp.name", "sp.col", "sp.pch")], by = "sp.name", all.x = T)
sp.col2 = data.frame(sp = sp.col$sp.name, sp.col = sp.col$sp.col, sp.pch = sp.col$sp.pch)
plotsp.info5 = merge(plotsp.info5, sp.info2, by = "sp", all.x = T, sort = F)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]

# Plot CDD-HDD estiamtes across plots and species (posterior means)
plot(plotsp.info5$elevjit, realcdd.plotspAPC, 
	xlab = "Elevation (m)", ylab = "", cex.lab = 1.2, 
	pch=19, las=1, main = "15-25 cm DBH", type = "n", cex.axis = 1.2)
mtext("Change in growth from CDD", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
set.seed(314)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info5[which(plotsp.info5$sp == sp.info2$sp[i]),]
points(plot.subset$elevjit, plot.subset$points, cex = (plot.subset$plotsp.n*0.03)^(1/4), 
	col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)
	}

set.seed(314)
elevjit = jitter(plot.info3$ELEVATION, amount = 15)
elevjit2 = data.frame(elevjit, plot = plot.info3$plot)
plotsp.info5 = merge(plotsp.info2, elevjit2, by = "plot", all.x = T, sort = F)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]
plotsp.info5$points = realhdd.plotspAPC
sp.info2 = data.frame(sp.info[order(sp.info$sp),])
load("HJA_CNDD_Analyses_Species_Colors_for_figures.RData")
sp.info2 = merge(sp.info2, sp.col[,c("sp.name", "sp.col", "sp.pch")], by = "sp.name", all.x = T)
sp.col2 = data.frame(sp = sp.col$sp.name, sp.col = sp.col$sp.col, sp.pch = sp.col$sp.pch)
plotsp.info5 = merge(plotsp.info5, sp.info2, by = "sp", all.x = T, sort = F)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]

# Plot CDD-HDD estiamtes across plots and species (posterior means)
plot(plotsp.info5$elevjit, realhdd.plotspAPC, 
	xlab = "Elevation (m)", ylab = "", cex.lab = 1.2, 
	pch=19, las=1, main = "15-25 cm DBH", type = "n", cex.axis = 1.2)
mtext("Change in growth from HDD", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
set.seed(314)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info5[which(plotsp.info5$sp == sp.info2$sp[i]),]
points(plot.subset$elevjit, plot.subset$points, cex = (plot.subset$plotsp.n*0.03)^(1/4), 
	col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)
	}

# dev.off()










#############################################
# Plot mean annual growth predictions 

meangrowth.plotspAPC = apply(meangrowth.plotsp,2,mean)


# pdf("HJA_15-25cmDBH_Growth_Hazard_MeanGrowth_BAYES_Elev_byPlot_20220202.pdf", height = 10, width = 5, useDingbats=FALSE)
par(pty="s")
par(mfrow=c(2,1))
set.seed(314)
elevjit = jitter(plot.info3$ELEVATION, amount = 15)
elevjit2 = data.frame(elevjit, plot = plot.info3$plot)
plotsp.info5 = merge(plotsp.info2, elevjit2, by = "plot", all.x = T, sort = F)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]
plotsp.info5$points = meangrowth.plotspAPC
sp.info2 = data.frame(sp.info[order(sp.info$sp),])
load("HJA_CNDD_Analyses_Species_Colors_for_figures.RData")
sp.info2 = merge(sp.info2, sp.col[,c("sp.name", "sp.col", "sp.pch")], by = "sp.name", all.x = T)
sp.col2 = data.frame(sp = sp.col$sp.name, sp.col = sp.col$sp.col, sp.pch = sp.col$sp.pch)
plotsp.info5 = merge(plotsp.info5, sp.info2, by = "sp", all.x = T, sort = F)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]

plot(plotsp.info5$elevjit, meangrowth.plotspAPC, 
	xlab = "Elevation", ylab = "", cex.lab = 1.2,
	pch=19, las=1, main = "15-25 cm DBH", type = "n", cex.axis = 1.2)
mtext("Annual growth rate (cm / yr)", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
set.seed(314)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info5[which(plotsp.info5$sp == sp.info2$sp[i]),]
points(plot.subset$elevjit, plot.subset$points, cex = (plot.subset$plotsp.n*0.02)^(1/4), 
	col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)
	}

# dev.off()














###################################################################
# Species abundance and CNDD tests


plotsp.info5 = plotsp.info2[order(plotsp.info2$plotsp),]
plotsp.info5$points = realcndd.plotspAPC
sp.info2 = data.frame(sp.info[order(sp.info$sp),])
load("HJA_CNDD_Analyses_Species_Colors_for_figures.RData")
sp.info2 = merge(sp.info2, sp.col[,c("sp.name", "sp.col", "sp.pch")], by = "sp.name", all.x = T)
sp.col2 = data.frame(sp = sp.col$sp.name, sp.col = sp.col$sp.col, sp.pch = sp.col$sp.pch)
plotsp.info5 = merge(plotsp.info5, sp.info2, by = "sp", all.x = T, sort = F)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]


# pdf("HJA_15-25cmDBH_Growth_Hazard_CDD-HDD_wSpAbund_BAYES_20220202.pdf", height = 5, width = 5, useDingbats=FALSE)
par(pty="s")
set.seed(314)

# Plot CDD-HDD estiamtes across plots and species (posterior means)
plot(log(plotsp.info5$ba.ha), realcndd.plotspAPC, 
	xlab = "log(BA per ha)", ylab = "", cex.lab = 1.2,
	pch=19, las=1, main = "15-25 cm DBH", type = "n", cex.axis = 1.2)
mtext("Change in growth from CNDD", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
set.seed(314)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info5[which(plotsp.info5$sp == sp.info2$sp[i]),]
points(log(plot.subset$ba.ha), plot.subset$points, cex = (plot.subset$plotsp.n*0.02)^(1/4), 
	col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)
	}

# dev.off()





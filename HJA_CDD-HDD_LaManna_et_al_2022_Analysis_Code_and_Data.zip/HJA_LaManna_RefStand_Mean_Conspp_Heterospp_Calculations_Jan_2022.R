### Script to perform analyses of HJA reference stand data
### Data prep for survival and growth analyses -- calculate average conspecific & heterospecific densities for assessing CDD-HDD
### By: J. LaManna, reference stand data accessed: 12-23-2017

# Load necessary R packages
library(vegan)
library(doBy)
library(arm)
library(reshape)
library(nlme)
library(spatstat)
library(lme4)
library(vegan)
library(boot)
library(lmtest)
library(abind)
library(optimx)
library(nloptr)
library(parallel)
library(MASS)
library(stats)
library(DescTools)
library(purrr)
library(rstan)
library(rstanarm)
# Code for multi-core
options(mc.cores = parallel::detectCores())
library(DHARMa)


# Load data for diversity analyses
load("HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData")

### IN ADDITION MAKE SURE THESE RData FILES ARE IN R WORKING DIRECTORY:
# "HJA_Species_Mean_Abundances_across_Censuses_by_Plot.RData"
# "HJA_CNDD_Analyses_Species_Colors_for_figures.RData"
# "HJA_GLMM_ExpHazard_Model_STAN.stan"


# Load other analysis functions

# Function to calculate distance-weighted abundance based on methods in Uriarte et al. (2004) and Comita et al. (2010):
dist.weighted.abund.function = function(adultlocs = adultlocs, saplocs = saplocs, fix.rad = TRUE, rad = 10, alpha = 0, beta = 0.2) {
xdist = crossdist(adultlocs[,2], adultlocs[,3], saplocs[,2], saplocs[,3])
same.tree.row = which(adultlocs$id %in% saplocs$id == T)
same.tree.col = match(adultlocs$id, saplocs$id)[which(adultlocs$id %in% saplocs$id == T)]
xdist[as.matrix(data.frame(same.tree.row, same.tree.col))] = NA
weight.mat = matrix((adultlocs$dbh^alpha), nrow = nrow(xdist), ncol = ncol(xdist))
if(fix.rad) {
xdist2 = xdist
xdist2[which(xdist2 > rad)] = NA
xdist.weighted = weight.mat * exp((-beta) * xdist2) 
} else {
xdist.weighted = weight.mat * exp((-beta) * xdist2) 
}
xdist.weighted[is.na(xdist.weighted)] = 0
species.names = unique(adultlocs[,1])
adult.weights = data.frame(matrix(NA,nrow = nrow(saplocs), ncol = length(species.names)))
colnames(adult.weights) = species.names
rownames(adult.weights) = saplocs[,1]
if(nrow(adult.weights) == 0) {
return(adult.weights)
} else {
for(z in 1:ncol(adult.weights)) {
if(ncol(xdist.weighted) > 1) {
if(length(which(adultlocs[,1] == species.names[z])) > 1) {
adult.weights[,z] = colSums(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
} else {
adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
}
} else {
if(length(which(adultlocs[,1] == species.names[z])) > 1) {
adult.weights[,z] = sum(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
} else {
adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
}
}}
return(adult.weights)
}}



# Function to add missing species names when calculating distance-wieghted abundance (add species with zero abundnace in a neighborhood to keep number of columns consistent across trees)
Add.missing.sp.names = function(test) {
names.toAdd = sp.list[which(sp.list %in% colnames(test) == F)]
test2 = data.frame(test, data.frame(matrix(0, nrow = nrow(test), ncol = length(names.toAdd))))
colnames(test2) = c(colnames(test), names.toAdd)
test2 = test2[,order(colnames(test2))]
return(test2)
}








########################################################################################################################
### DATA PREP FUNCTION -- Remember to set values for 'alpha' and 'beta' below, elim.radius set to 10 m

fd.focal.phi = list()
elim.radius = 10		# remove trees within 10 m of plot edge for survival/growth analyses (neighborhood density metrics, which have radii of 10 m, will be biased low for these individuals because we don't know what adults are outside the plot)
alpha = 1.8			# alpha parameter for distance-weighted abundance-based neighborhood metrics, DBH^alpha / exp(beta * distance), higher values weight larger-diameter trees more, 0 weights all trees evenly (i.e. abundance)
beta = 0.3			# Beta value determines the shape of the exponential decay of neighborhood effects across each 10-m radius neighborhood; 0 = no decay, higher values = stronger decay (Comita et al. 2010, Science)

sp.list

# The following code goes through the tree data, removes trees within 10 m of plot boundaries, and calculates distance-weighted abundance-based 
# neighborhood metrics for each tree using all trees >15 cm within 10 m of the focal tree.

for(q in 1:length(hja.survival.growth.data)) {
  test = hja.survival.growth.data[[q]]
  n.census = length(test)
  focal.phi.list = list()

  for(i in 2:n.census) {
    df = test[[i]]
    df$ba = (((df$DBH/100)/2)^2)*pi  		# Calculate basal area for each individual
    df$julian = as.numeric(julian(as.POSIXlt(df$SAMPLEDATE, format = "%Y-%m-%d")))
    adult.sp = tapply(df$DBH[which(df$DBH >= 15)], as.character(df$SPECIES[which(df$DBH >= 15)]), length)
    adult.sp2 = names(adult.sp)
    focal = data.frame(STANDID = df$STANDID, census = df$census, YEAR = df$YEAR, DBH = df$DBH, quad = df$quad, canopy_class = df$CANOPY_CLASS, vigor = df$TREE_VIGOR,
	uniqueID = df$uniqueID, sp = df$SPECIES, gx = df$XCOORD, gy = df$YCOORD, status = df$TREE_STATUS, dbh_code = df$DBH_CODE, julian = df$julian, min_dbh = df$MIN_DBH, notes = df$CHECK_NOTES)
    focal$sp = as.character(focal$sp)

    test.var = 1
    if(df$census[1] == 9 & df$STANDID[1] == "RS34") {test.var = 34}
    if(df$census[1] == 9 & df$STANDID[1] == "RS38") {test.var = 38}
    if(test.var == 34) {focal = focal[which(focal$gx >= 10 & focal$gx <= 190 & focal$gy >= 10 & focal$gy <= 90),]}
    if(test.var == 38) {focal = focal[which(focal$gx >= 10 & focal$gx <= 165 & focal$gy >= 10 & focal$gy <= 90),]}
    if(test.var == 1) {
      maxcol = max(as.numeric(substr(df$quad,1,2)))
      maxrow = max(as.numeric(substr(df$quad,3,4)))
      mincol = min(as.numeric(substr(df$quad,1,2)))
      minrow = min(as.numeric(substr(df$quad,3,4)))
      focal.good = focal[which(focal$quad == 9999),]
      for(k in mincol:maxcol) {
        df2 = df[which(as.numeric(substr(df$quad,1,2)) == k),]
        ymax = max(as.numeric(substr(df2$quad,3,4))) * 25
        ymin = (min(as.numeric(substr(df2$quad,3,4))) - 1) * 25
        focal.good = rbind(focal.good, focal[which(as.numeric(substr(focal$quad,1,2)) == k & focal$gy >= (ymin + elim.radius) & focal$gy <= (ymax - elim.radius)),])
      }
      focal.good2 = focal.good[which(focal.good$quad == 9999),]
      for(k in minrow:maxrow) {
        df2 = df[which(as.numeric(substr(df$quad,3,4)) == k),]
        xmax = max(as.numeric(substr(df2$quad,1,2))) * 25
        xmin = (min(as.numeric(substr(df2$quad,1,2))) - 1) * 25
        focal.good2 = rbind(focal.good2, focal.good[which(as.numeric(substr(focal.good$quad,3,4)) == k & focal.good$gx >= (xmin + elim.radius) & focal.good$gx <= (xmax - elim.radius)),])
      }
    
      focal = focal.good2
      focal$sp = as.character(focal$sp)
      if(nrow(focal) == 0) {print(paste("ERROR: No individuals within plot buffer!", "STAND", q, "census", i)); next}
      if(focal$STANDID[1] == "RS01" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 10 & focal$gx <= 40 & focal$gy >= 10 & focal$gy <= 40),]}
      if(focal$STANDID[1] == "RS02" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 35 & focal$gx <= 65 & focal$gy >= 35 & focal$gy <= 65),]}
      if(focal$STANDID[1] == "RS03" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 60 & focal$gx <= 90 & focal$gy >= 60 & focal$gy <= 90),]}
    }
    focal$sp = as.character(focal$sp)
    
    # plot(df$XCOORD,df$YCOORD,asp=1)
    # points(focal$gx,focal$gy,pch=19,col="red")
    # points(focal.good2$gx,focal.good2$gy,pch=19,col="purple")
    
    df.prev = test[[i-1]]
    missing.and.found = df.prev[which(df.prev$uniqueID %in% c("RS03-12-6791", "RS21-14-45") == T & df.prev$TREE_STATUS %in% c(6,9) == T),]
    df.prev = df.prev[which(df.prev$TREE_STATUS %in% c(6,9) == F),]
    df.prev = rbind(df.prev, missing.and.found)
    df.prev$julian = as.numeric(julian(as.POSIXlt(df.prev$SAMPLEDATE, format = "%Y-%m-%d")))
    focal.prev.time = df.prev
    if(df$census[1] == 9 & df$STANDID[1] %in% c("RS34", "RS38") == T) {
    	focal.prev.time$gx = focal.prev.time$XCOORD
    	focal.prev.time$gy = focal.prev.time$YCOORD
    	focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$uniqueID %in% focal$uniqueID == T),]
    } else {
      maxcol = max(as.numeric(substr(df.prev$quad,1,2)))
      maxrow = max(as.numeric(substr(df.prev$quad,3,4)))
      mincol = min(as.numeric(substr(df.prev$quad,1,2)))
      minrow = min(as.numeric(substr(df.prev$quad,3,4)))
      focal.prev.time$gx = focal.prev.time$XCOORD
      focal.prev.time$gy = focal.prev.time$YCOORD
      focal.prev.time.good = focal.prev.time[which(focal.prev.time$quad == 9999),]
      for(k in mincol:maxcol) {
        df.prev2 = df.prev[which(as.numeric(substr(df.prev$quad,1,2)) == k),]
        ymax = max(as.numeric(substr(df.prev2$quad,3,4))) * 25
        ymin = (min(as.numeric(substr(df.prev2$quad,3,4))) - 1) * 25
        focal.prev.time.good = rbind(focal.prev.time.good, focal.prev.time[which(as.numeric(substr(focal.prev.time$quad,1,2)) == k & focal.prev.time$gy >= (ymin + elim.radius) & focal.prev.time$gy <= (ymax - elim.radius)),])
      }
      focal.prev.time.good2 = focal.prev.time.good[which(focal.prev.time.good$quad == 9999),]
      for(k in minrow:maxrow) {
        df.prev2 = df.prev[which(as.numeric(substr(df.prev$quad,3,4)) == k),]
        xmax = max(as.numeric(substr(df.prev2$quad,1,2))) * 25
        xmin = (min(as.numeric(substr(df.prev2$quad,1,2))) - 1) * 25
        focal.prev.time.good2 = rbind(focal.prev.time.good2, focal.prev.time.good[which(as.numeric(substr(focal.prev.time.good$quad,3,4)) == k & focal.prev.time.good$gx >= (xmin + elim.radius) & focal.prev.time.good$gx <= (xmax - elim.radius)),])
      }
      if(focal.prev.time$STANDID[1] == "RS01" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 10 & focal.prev.time$gx <= 40 & focal.prev.time$gy >= 10 & focal.prev.time$gy <= 40),]}
      if(focal.prev.time$STANDID[1] == "RS02" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 35 & focal.prev.time$gx <= 65 & focal.prev.time$gy >= 35 & focal.prev.time$gy <= 65),]}
      if(focal.prev.time$STANDID[1] == "RS03" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 60 & focal.prev.time$gx <= 90 & focal.prev.time$gy >= 60 & focal.prev.time$gy <= 90),]}
    }
    
    # plot(df.prev$XCOORD,df.prev$YCOORD,asp=1)
    # points(focal.prev.time$gx,focal.prev.time$gy,pch=19,col="red")
    # points(focal.prev.time.good2$gx,focal.prev.time.good2$gy,pch=19,col="purple")
    
    focal.prev.time = focal.prev.time.good2[,c("uniqueID", "DBH", "SPECIES", "YEAR", "gx", "gy", "STANDID", "quad", "TREE_STATUS", "julian", "DBH_CODE", "CANOPY_CLASS", "TREE_VIGOR", "MIN_DBH")]
    names(focal.prev.time) = c("uniqueID", "DBH_prev", "sp", "YEAR_prev", "gx_prev", "gy_prev", "STANDID_prev", "quad_prev", "status_prev", "julian_prev", "dbh_code_prev", "canopy_class_prev", "vigor_prev", "min_dbh_prev")
    focal.prev.time$sp = as.character(focal.prev.time$sp)
    focal2 = merge(focal, focal.prev.time, by = c("uniqueID", "sp"), all = T)
    focal2$growth = focal2$DBH - focal2$DBH_prev
    focal2$numyr = (focal2$julian - focal2$julian_prev) / 365.25
    focal2$growth.per.yr = focal2$growth / focal2$numyr
    focal2$radial.growth.per.yr = (log(focal2$DBH/focal2$DBH_prev)) / focal2$numyr		# Relative Growth Rate per Wright et al. 2018 Ecology
    
    # plot(df$XCOORD,df$YCOORD,asp=1)
    # points(focal2$gx,focal2$gy,pch=19,col="red")
    # points(focal.good2$gx,focal.good2$gy,pch=19,col="purple")
    
    # Remove interior plot corners that are within 10 m of plot boundary (not captured in preceding code)
    if(focal2$STANDID[1] == "RS01") {if(nrow(focal2[which(focal2$gx > 40 & focal2$gx < 50 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 40 & focal2$gx < 50 & focal2$gy > 50 & focal2$gy < 60),]}}
    if(focal2$STANDID[1] == "RS03") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 40 & focal2$gy < 50),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 40 & focal2$gy < 50),]}}
    if(focal2$STANDID[1] == "RS03") {if(nrow(focal2[which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 40 & focal2$gy < 50),]) > 0) {focal2 = focal2[-which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 40 & focal2$gy < 50),]}}
    if(focal2$STANDID[1] == "RS23") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 50 & focal2$gy < 60),]}}
    if(focal2$STANDID[1] == "RS23") {if(nrow(focal2[which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 50 & focal2$gy < 60),]}}
    if(focal2$STANDID[1] == "RS38") {if(nrow(focal2[which(focal2$gx > 25 & focal2$gx < 35 & focal2$gy > 90 & focal2$gy < 100),]) > 0) {focal2 = focal2[-which(focal2$gx > 25 & focal2$gx < 35 & focal2$gy > 90 & focal2$gy < 100),]}}
    if(focal2$STANDID[1] == "RS38") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 115 & focal2$gy < 125),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 115 & focal2$gy < 125),]}}
    
    focal2$phi = c(1)
    focal2$phi[is.na(focal2$DBH)] = 0
    focal2$phi[is.na(focal2$DBH_prev)] = NA
    focal2$gx[is.na(focal2$gx)] = focal2$gx_prev[is.na(focal2$gx)]
    focal2$gy[is.na(focal2$gy)] = focal2$gy_prev[is.na(focal2$gy)]
    focal2$quad = as.character(focal2$quad)
    focal2$quad_prev = as.character(focal2$quad_prev)
    focal2$STANDID = as.character(focal2$STANDID)
    focal2$STANDID_prev = as.character(focal2$STANDID_prev)
    focal2$quad[is.na(focal2$quad)] = focal2$quad_prev[is.na(focal2$quad)]
    focal2$STANDID[is.na(focal2$STANDID)] = focal2$STANDID_prev[is.na(focal2$STANDID)]
    focal2$census[is.na(focal2$census)] = c(unique(focal2$census[!is.na(focal2$YEAR)]))
    focal2$YEAR[is.na(focal2$YEAR)] = c(unique(focal2$YEAR[!is.na(focal2$DBH)]))
    
    # Calculate distance-based abundance metrics for neighborhood density
    adults = df[which(df$DBH >= 15),]
    adults = adults[which(adults$TREE_STATUS %in% c(6,9) == F),]
    adults.prev = df.prev[which(df.prev$DBH >= 15),]
    adults.prev = adults.prev[which(adults.prev$TREE_STATUS %in% c(6,9) == F),]
    adultlocs = data.frame(sp = adults$SPECIES, gx = adults$XCOORD, gy = adults$YCOORD, id = adults$uniqueID, dbh = adults$DBH)
    adultlocs.prev = data.frame(sp = adults.prev$SPECIES, gx = adults.prev$XCOORD, gy = adults.prev$YCOORD, id = adults.prev$uniqueID, dbh = adults.prev$DBH)
    unique.quads = unique(df$quad)
    quad.gx = c()
    quad.gy = c()
    for(z in 1:length(unique.quads)) {
      quad.gx[z] = (25*as.numeric(substr(unique.quads[z],1,2))-12.5)
      quad.gy[z] = (25*as.numeric(substr(unique.quads[z],3,4))-12.5)
    }
    quadlocs = data.frame(id = unique.quads, gx = quad.gx, gy = quad.gy)
    quad.weights.prev = dist.weighted.abund.function(adultlocs = adultlocs.prev, saplocs = quadlocs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
    quad.weights2.prev = Add.missing.sp.names(quad.weights.prev)
    if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
      quad.weights.combined = quad.weights2.prev
    } else {
      quad.weights = dist.weighted.abund.function(adultlocs = adultlocs, saplocs = quadlocs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
      quad.weights2 = Add.missing.sp.names(quad.weights)
      quad.weights.combined = (quad.weights2 + quad.weights2.prev) / 2
    }
    
    focal.phi = focal2[!is.na(focal2$DBH_prev),]
    if(nrow(focal.phi) > 0) {
      focal.phi$order = c(1:nrow(focal.phi))
      focal.phi = focal.phi[order(focal.phi$sp),]
      focal.phi.locs = data.frame(id = focal.phi$uniqueID, gx = focal.phi$gx, gy = focal.phi$gy)
      focal.phi.weights.prev = dist.weighted.abund.function(adultlocs = adultlocs.prev, saplocs = focal.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
      focal.phi.weights2.prev = Add.missing.sp.names(focal.phi.weights.prev)
      if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
        focal.phi.weights.combined = focal.phi.weights2.prev
      } else {
        focal.phi.weights = dist.weighted.abund.function(adultlocs = adultlocs, saplocs = focal.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
        focal.phi.weights2 = Add.missing.sp.names(focal.phi.weights)
        focal.phi.weights.combined = (focal.phi.weights2 + focal.phi.weights2.prev) / 2
      }
      focal.phi = data.frame(focal.phi, focal.phi.weights.combined)
      focal.phi = focal.phi[order(focal.phi$order),]
      focal.phi.list[[i-1]] = focal.phi
    }
  }
  if(length(focal.phi.list) > 0) {
    focal.phi.list = focal.phi.list[which(lapply(focal.phi.list, function(x) {nrow(x) > 0}) == T)]
    focal.phi2 = do.call('rbind', focal.phi.list)
    focal.phi2$yr = focal.phi2$YEAR - 2000
    fd.focal.phi[[q]] = focal.phi2
  }
}




########################################
## Prepare data for analysis
yr.value = 2008
fd.focal.phi2 = do.call('rbind', fd.focal.phi)
fd.focal.phi2 = fd.focal.phi2[order(fd.focal.phi2$STANDID, fd.focal.phi2$sp, fd.focal.phi2$uniqueID, fd.focal.phi2$census),]
fd.focal.phi2$sizeclass = c(NA)
fd.focal.phi3 = split(fd.focal.phi2, as.character(fd.focal.phi2$uniqueID))

# Set sizeclasses for analysis (cutoff points based on data -- trees < 15 cm were only surveyed in subsets of some of the plots, so they are the first sizeclass,
# the other 3 size classes were determined by splitting the data above 15 cm into 3 approximately equal groups (equal number of individual trees)
for(i in 1:length(fd.focal.phi3)) {
  if(min(fd.focal.phi3[[i]]$DBH_prev) < 15 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] < 15) {fd.focal.phi3[[i]]$sizeclass = c(1)}			# Trees that stay in the 5-15 cm sizeclass
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 15 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] < 25.4) {fd.focal.phi3[[i]]$sizeclass = c(2)}		# Trees that stay in the 15-25 cm sizeclass (25.4 = 33rd percentile of DBH for all trees > 15 cm DBH)
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 25.4 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] < 52.06667) {fd.focal.phi3[[i]]$sizeclass = c(3)}	# Trees that stay in the 25-52 cm sizeclass (52.06667 = 67th percentile of DBH for all trees > 15 cm DBH)
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 52.06667) {fd.focal.phi3[[i]]$sizeclass = c(4)}														# Trees that stay in the >52 cm sizeclass
  if(min(fd.focal.phi3[[i]]$DBH_prev) < 15 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] >= 15) {									# Trees that start in the 5-15 cm sizeclass and transition to larger sizeclass
    fd.focal.phi3[[i]]$sizeclass[1:max(which(fd.focal.phi3[[i]]$DBH_prev < 15))] = 1
    fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 15))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 2
    if(max(fd.focal.phi3[[i]]$DBH_prev) >= 25.4) {fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 25.4))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 3}
    if(max(fd.focal.phi3[[i]]$DBH_prev) >= 52.06667) {fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 4}
  }
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 15 & min(fd.focal.phi3[[i]]$DBH_prev) < 25.4 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] >= 25.4) {	# Trees that start in the 15-25 cm sizeclass and transition to larger sizeclass
    fd.focal.phi3[[i]]$sizeclass[1:max(which(fd.focal.phi3[[i]]$DBH_prev < 25.4))] = 2
    fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 25.4))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 3
    if(max(fd.focal.phi3[[i]]$DBH_prev) >= 52.06667) {fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 4}
  }
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 25.4 & min(fd.focal.phi3[[i]]$DBH_prev) < 52.06667 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] >= 52.06667) {	# Trees that start in the 25-52 cm sizeclass and transition to larger sizeclass
    fd.focal.phi3[[i]]$sizeclass[1:max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))] = 3
    fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 4
  }
}
fd.focal.phi4 = do.call('rbind', fd.focal.phi3)
fd.focal.phi5 = merge(fd.focal.phi4, standclimate, by = "STANDID", all.x = T)
fd.focal.phi5$yr2 = fd.focal.phi5$YEAR - yr.value
fd.focal.phi5$conspp = c(NA)
fd.focal.phi5$allspp = c(NA)
fd.focal.phi5$heterospp = c(NA)
adult.cols = which(colnames(fd.focal.phi5) %in% sp.list == T)
# Sum conspecific and heterospecific local densities across species in each neighborhood
for(i in 1:nrow(fd.focal.phi5)) {
  fd.focal.phi5$conspp[i] = fd.focal.phi5[i,which(colnames(fd.focal.phi5) == fd.focal.phi5$sp[i])]
  fd.focal.phi5$allspp[i] = sum(fd.focal.phi5[i,adult.cols])
  fd.focal.phi5$heterospp[i] = sum(fd.focal.phi5[i,adult.cols[which(colnames(fd.focal.phi5[,adult.cols]) != fd.focal.phi5$sp[i])]])
}
fd.focal.phi6 = fd.focal.phi5[which(fd.focal.phi5$census < 9),]	# Remove census 9 (mortality checks only conducted in a small subset of plots)
fd.focal.phi6$plotcen = as.numeric(factor(as.character(factor(as.character(fd.focal.phi6$STANDID)):factor(as.character(fd.focal.phi6$census)))))	# unique ID for each plot-by-census combination
fd.focal.phi7 = split(fd.focal.phi6, fd.focal.phi6$plotcen)
focal.census.intervals = unlist(lapply(fd.focal.phi7,function(x) {(mean(x$julian[which(x$YEAR == max(x$YEAR))]) - mean(x$julian_prev[which(x$YEAR == max(x$YEAR))]))/365.25}))	# Census IDs
focal.census.intervals = data.frame(census.interval = focal.census.intervals, plotcen = names(focal.census.intervals))
focal.census.intervals$cenyr = unlist(lapply(fd.focal.phi7,function(x) {max(x$YEAR)}))
fd.focal.phi6 = merge(fd.focal.phi6, focal.census.intervals, by = "plotcen", all.x = T)



##### Mean conspp and heterospp values by species

d = fd.focal.phi6
du = d[duplicated(d$uniqueID) == F,]
du$plotsp = paste(du$STANDID, du$sp, sep = "-")

hist((du$conspp / du$allspp), breaks=100)
hist(du$heterospp, breaks=100)
hist(du$allspp, breaks=100)

round(mean(du$allspp),4)


# Unscaled mean conspp/heterospp in 10 m radii neighborhoods (results from above code w/ and w/o DenExp)
# 5-15 cm mort:     alpha = 0.0, beta = 0.35 -> overall avg. = 1.1925
# 15-25 cm mort:    alpha = 0.0, beta = 0.10 -> overall avg. = 4.4523
# 25-52 cm mort:    alpha = 0.4, beta = 0.20 -> overall avg. = 10.6427
# 52-220 cm mort:   alpha = 0.8, beta = 0.30 -> overall avg. = 29.3141

# 5-15 cm growth:   alpha = 0.5, beta = 0.20 -> overall avg. = 15.4864
# 15-25 cm growth:  alpha = 1.1, beta = 0.20 -> overall avg. = 166.0877
# 25-52 cm growth:  alpha = 1.3, beta = 0.20 -> overall avg. = 383.5518
# 52-220 cm growth: alpha = 1.8, beta = 0.30 -> overall avg. = 2002.976










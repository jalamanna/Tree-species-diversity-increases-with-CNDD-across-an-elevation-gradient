### Script to perform analyses of HJA reference stand data
### Prepare data for survival analyses and conduct survival analyses for trees 5 to 15 cm DBH
### By: J. LaManna, reference stand data accessed: 12-23-2017

# Load necessary R packages
library(vegan)
library(doBy)
library(arm)
library(reshape)
library(nlme)
library(spatstat)
library(lme4)
library(vegan)
library(boot)
library(lmtest)
library(abind)
library(optimx)
library(nloptr)
library(parallel)
library(MASS)
library(stats)
library(DescTools)
library(purrr)
library(rstan)
library(rstanarm)
# Code for multi-core
options(mc.cores = parallel::detectCores())
library(DHARMa)


# Load data for diversity analyses
load("HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData")

### IN ADDITION MAKE SURE THESE RData FILES ARE IN R WORKING DIRECTORY:
# "HJA_Species_Mean_Abundances_across_Censuses_by_Plot.RData"
# "HJA_CNDD_Analyses_Species_Colors_for_figures.RData"
# "HJA_GLMM_ExpHazard_Model_STAN.stan"


# Load other analysis functions

# Function to calculate distance-weighted abundance based on methods in Uriarte et al. (2004) and Comita et al. (2010):
dist.weighted.abund.function = function(adultlocs = adultlocs, saplocs = saplocs, fix.rad = TRUE, rad = 10, alpha = 0, beta = 0.2) {
  xdist = crossdist(adultlocs[,2], adultlocs[,3], saplocs[,2], saplocs[,3])
  same.tree.row = which(adultlocs$id %in% saplocs$id == T)						# Remove the focal tree if it's in the dataset
  same.tree.col = match(adultlocs$id, saplocs$id)[which(adultlocs$id %in% saplocs$id == T)]
  xdist[as.matrix(data.frame(same.tree.row, same.tree.col))] = NA
  weight.mat = matrix((adultlocs$dbh^alpha), nrow = nrow(xdist), ncol = ncol(xdist))	# Neighborhood function for size-dependence (alpha)
  if(fix.rad) {								# Using fixed radii
    xdist2 = xdist
    xdist2[which(xdist2 > rad)] = NA
    xdist.weighted = weight.mat * exp((-beta) * xdist2) 	# Neighborhood function for distance-dependence (beta)
  } else {									# Using non-fixed radii
    xdist2 = xdist
    xdist.weighted = weight.mat * exp((-beta) * xdist2) 	# Neighborhood function for distance-dependence (beta)
  }
  xdist.weighted[is.na(xdist.weighted)] = 0
  species.names = unique(adultlocs[,1])
  adult.weights = data.frame(matrix(NA,nrow = nrow(saplocs), ncol = length(species.names)))
  colnames(adult.weights) = species.names
  rownames(adult.weights) = saplocs[,1]
  if(nrow(adult.weights) == 0) {
    return(adult.weights)						# Check that there are values to return
  } else {
    for(z in 1:ncol(adult.weights)) {				# Sum up neighborhood density values for each species
      if(ncol(xdist.weighted) > 1) {
        if(length(which(adultlocs[,1] == species.names[z])) > 1) {
          adult.weights[,z] = colSums(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
        } else {
          adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
        }
      } else {
        if(length(which(adultlocs[,1] == species.names[z])) > 1) {
          adult.weights[,z] = sum(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
        } else {
          adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
        }
      }
    }
    return(adult.weights)
  }
}



# Function to add missing species names when calculating distance-wieghted abundance 
# (add species with zero abundnace in a neighborhood to keep number of columns consistent across trees)
Add.missing.sp.names = function(test) {
  names.toAdd = sp.list[which(sp.list %in% colnames(test) == F)]
  test2 = data.frame(test, data.frame(matrix(0, nrow = nrow(test), ncol = length(names.toAdd))))
  colnames(test2) = c(colnames(test), names.toAdd)
  test2 = test2[,order(colnames(test2))]
  return(test2)
}


# Function to standardize conspecific and heterospecific densities on the same scale
std.conhet.density = function(conspp, heterospp, id, DenExp) {
  consppid = tapply(conspp, id, mean)							# Mean conspecific density across individuals
  heterosppid = tapply(heterospp, id, mean)						# Mean heterospecific density across individuals
  conhetero = c(consppid^(DenExp), heterosppid^(DenExp))				# Collective mean across all con- and heterospecific densities trasnformed with D = DenExp
  conspp.std = ((conspp^(DenExp)) - mean(conhetero)) / sd(conhetero)		# Scaled conspecific densities
  heterospp.std = ((heterospp^(DenExp)) - mean(conhetero)) / sd(conhetero)	# Scaled heterospecific densities
  return(list(conspp = conspp.std, heterospp = heterospp.std))
}


# Function to perform Bayesian bootstrap (Rubin 1981, Gustafson 2007)
# see https://en.wikipedia.org/wiki/Dirichlet_distribution#Gamma_distribution for proof of gamma distribution equivalency to Dirichlet distribution
# sample.weights is an optional agrument used to weight Bayesian bootstrap average predictive comparisons by plot area
bayesian.bootstrap = function(test_sample, nIts, sample.weights = NA) {
  weights <- matrix(rexp(length(test_sample) * nIts, 1), ncol = length(test_sample), byrow = TRUE)	# Matrix to hold weights sampled from Dirichlet distribution with equal weights
  if(is.numeric(sample.weights)) {weights <- t(t(weights) * sample.weights)}	# Weight by sample.weights (e.g. forest-plot area in ha)
  weights <- weights / rowSums(weights)							# Make sure weights sum to 1 (Dirichlet distribution)
  result = rowSums(t(t(weights) * test_sample))						# Multiply and add test_sample to weights for each iteration
  return(result)
}






########################################################################################################################
### DATA PREP FUNCTION -- Remember to set values for 'alpha' and 'beta' below, elim.radius set to 10 m

fd.focal.phi = list()
elim.radius = 10		# remove trees within 10 m of plot edge for survival/growth analyses (neighborhood density metrics, which have radii of 10 m, will be biased low for these individuals because we don't know what adults are outside the plot)
alpha = 0.0			# alpha parameter for distance-weighted abundance-based neighborhood metrics, DBH^alpha / exp(beta * distance), higher values weight larger-diameter trees more, 0 weights all trees evenly (i.e. abundance)
beta = 0.35			# Beta value determines the shape of the exponential decay of neighborhood effects across each 10-m radius neighborhood; 0 = no decay, higher values = stronger decay (Comita et al. 2010, Science)

sp.list

# The following code goes through the tree data, removes trees within 10 m of plot boundaries, and calculates distance-weighted abundance-based 
# neighborhood metrics for each tree using all trees >15 cm within 10 m of the focal tree.

for(q in 1:length(hja.survival.growth.data)) {
  test = hja.survival.growth.data[[q]]
  n.census = length(test)
  focal.phi.list = list()

  for(i in 2:n.census) {
    df = test[[i]]
    df$ba = (((df$DBH/100)/2)^2)*pi  													# Calculate basal area for each individual
    df$julian = as.numeric(julian(as.POSIXlt(df$SAMPLEDATE, format = "%Y-%m-%d")))						# Julian date for each sample occasion
    adult.sp = tapply(df$DBH[which(df$DBH >= 15)], as.character(df$SPECIES[which(df$DBH >= 15)]), length)		# Adult species in census
    adult.sp2 = names(adult.sp)
    focal = data.frame(STANDID = df$STANDID, census = df$census, YEAR = df$YEAR, DBH = df$DBH, quad = df$quad, canopy_class = df$CANOPY_CLASS, vigor = df$TREE_VIGOR,
	uniqueID = df$uniqueID, sp = df$SPECIES, gx = df$XCOORD, gy = df$YCOORD, status = df$TREE_STATUS, dbh_code = df$DBH_CODE, julian = df$julian, min_dbh = df$MIN_DBH, notes = df$CHECK_NOTES)
    focal$sp = as.character(focal$sp)													# 'focal' contains information on the trees for analysis in a given census/plot combo

    # Remove trees within 10 m of plot boundaries for current census (plots are sometimes not perfect squares, so the code is more complex).
    test.var = 1
    if(df$census[1] == 9 & df$STANDID[1] == "RS34") {test.var = 34}	# Census 9 only recorded dead trees (incomplete census), these data are removed later in the code
    if(df$census[1] == 9 & df$STANDID[1] == "RS38") {test.var = 38}
    if(test.var == 34) {focal = focal[which(focal$gx >= 10 & focal$gx <= 190 & focal$gy >= 10 & focal$gy <= 90),]}
    if(test.var == 38) {focal = focal[which(focal$gx >= 10 & focal$gx <= 165 & focal$gy >= 10 & focal$gy <= 90),]}
    if(test.var == 1) {
      maxcol = max(as.numeric(substr(df$quad,1,2)))
      maxrow = max(as.numeric(substr(df$quad,3,4)))
      mincol = min(as.numeric(substr(df$quad,1,2)))
      minrow = min(as.numeric(substr(df$quad,3,4)))
      focal.good = focal[which(focal$quad == 9999),]
      for(k in mincol:maxcol) {
        df2 = df[which(as.numeric(substr(df$quad,1,2)) == k),]
        ymax = max(as.numeric(substr(df2$quad,3,4))) * 25
        ymin = (min(as.numeric(substr(df2$quad,3,4))) - 1) * 25
        focal.good = rbind(focal.good, focal[which(as.numeric(substr(focal$quad,1,2)) == k & focal$gy >= (ymin + elim.radius) & focal$gy <= (ymax - elim.radius)),])
      }
      focal.good2 = focal.good[which(focal.good$quad == 9999),]
      for(k in minrow:maxrow) {
        df2 = df[which(as.numeric(substr(df$quad,3,4)) == k),]
        xmax = max(as.numeric(substr(df2$quad,1,2))) * 25
        xmin = (min(as.numeric(substr(df2$quad,1,2))) - 1) * 25
        focal.good2 = rbind(focal.good2, focal.good[which(as.numeric(substr(focal.good$quad,3,4)) == k & focal.good$gx >= (xmin + elim.radius) & focal.good$gx <= (xmax - elim.radius)),])
      }
    
      focal = focal.good2
      focal$sp = as.character(focal$sp)
      if(nrow(focal) == 0) {print(paste("ERROR: No individuals within plot buffer!", "STAND", q, "census", i)); next}
      if(focal$STANDID[1] == "RS01" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 10 & focal$gx <= 40 & focal$gy >= 10 & focal$gy <= 40),]}
      if(focal$STANDID[1] == "RS02" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 35 & focal$gx <= 65 & focal$gy >= 35 & focal$gy <= 65),]}
      if(focal$STANDID[1] == "RS03" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 60 & focal$gx <= 90 & focal$gy >= 60 & focal$gy <= 90),]}
    }
    focal$sp = as.character(focal$sp)
    
    # Code to plot focal trees in current census
    # plot(df$XCOORD,df$YCOORD,asp=1)
    # points(focal$gx,focal$gy,pch=19,col="red")
    # points(focal.good2$gx,focal.good2$gy,pch=19,col="purple")
    
    # Remove trees within 10 m of plot boundaries for previous census (plots are sometimes not perfect squares, so the code is more complex).
    df.prev = test[[i-1]]
    missing.and.found = df.prev[which(df.prev$uniqueID %in% c("RS03-12-6791", "RS21-14-45") == T & df.prev$TREE_STATUS %in% c(6,9) == T),]	# These trees were missing in one census, but found in next (not dead)
    df.prev = df.prev[which(df.prev$TREE_STATUS %in% c(6,9) == F),]	# Remove dead trees from previous census
    df.prev = rbind(df.prev, missing.and.found)
    df.prev$julian = as.numeric(julian(as.POSIXlt(df.prev$SAMPLEDATE, format = "%Y-%m-%d")))	# Julian date for previous sampling occasion
    focal.prev.time = df.prev
    if(df$census[1] == 9 & df$STANDID[1] %in% c("RS34", "RS38") == T) {
    	focal.prev.time$gx = focal.prev.time$XCOORD
    	focal.prev.time$gy = focal.prev.time$YCOORD
    	focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$uniqueID %in% focal$uniqueID == T),]
    } else {
      maxcol = max(as.numeric(substr(df.prev$quad,1,2)))
      maxrow = max(as.numeric(substr(df.prev$quad,3,4)))
      mincol = min(as.numeric(substr(df.prev$quad,1,2)))
      minrow = min(as.numeric(substr(df.prev$quad,3,4)))
      focal.prev.time$gx = focal.prev.time$XCOORD
      focal.prev.time$gy = focal.prev.time$YCOORD
      focal.prev.time.good = focal.prev.time[which(focal.prev.time$quad == 9999),]
      for(k in mincol:maxcol) {
        df.prev2 = df.prev[which(as.numeric(substr(df.prev$quad,1,2)) == k),]
        ymax = max(as.numeric(substr(df.prev2$quad,3,4))) * 25
        ymin = (min(as.numeric(substr(df.prev2$quad,3,4))) - 1) * 25
        focal.prev.time.good = rbind(focal.prev.time.good, focal.prev.time[which(as.numeric(substr(focal.prev.time$quad,1,2)) == k & focal.prev.time$gy >= (ymin + elim.radius) & focal.prev.time$gy <= (ymax - elim.radius)),])
      }
      focal.prev.time.good2 = focal.prev.time.good[which(focal.prev.time.good$quad == 9999),]
      for(k in minrow:maxrow) {
        df.prev2 = df.prev[which(as.numeric(substr(df.prev$quad,3,4)) == k),]
        xmax = max(as.numeric(substr(df.prev2$quad,1,2))) * 25
        xmin = (min(as.numeric(substr(df.prev2$quad,1,2))) - 1) * 25
        focal.prev.time.good2 = rbind(focal.prev.time.good2, focal.prev.time.good[which(as.numeric(substr(focal.prev.time.good$quad,3,4)) == k & focal.prev.time.good$gx >= (xmin + elim.radius) & focal.prev.time.good$gx <= (xmax - elim.radius)),])
      }
      # The first census in stands RS01 thru RS03 surveyed smaller areas than all other cenuses
      if(focal.prev.time$STANDID[1] == "RS01" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 10 & focal.prev.time$gx <= 40 & focal.prev.time$gy >= 10 & focal.prev.time$gy <= 40),]}
      if(focal.prev.time$STANDID[1] == "RS02" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 35 & focal.prev.time$gx <= 65 & focal.prev.time$gy >= 35 & focal.prev.time$gy <= 65),]}
      if(focal.prev.time$STANDID[1] == "RS03" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 60 & focal.prev.time$gx <= 90 & focal.prev.time$gy >= 60 & focal.prev.time$gy <= 90),]}
    }
    
    # plot(df.prev$XCOORD,df.prev$YCOORD,asp=1)
    # points(focal.prev.time$gx,focal.prev.time$gy,pch=19,col="red")
    # points(focal.prev.time.good2$gx,focal.prev.time.good2$gy,pch=19,col="purple")
    
    focal.prev.time = focal.prev.time.good2[,c("uniqueID", "DBH", "SPECIES", "YEAR", "gx", "gy", "STANDID", "quad", "TREE_STATUS", "julian", "DBH_CODE", "CANOPY_CLASS", "TREE_VIGOR", "MIN_DBH")]
    names(focal.prev.time) = c("uniqueID", "DBH_prev", "sp", "YEAR_prev", "gx_prev", "gy_prev", "STANDID_prev", "quad_prev", "status_prev", "julian_prev", "dbh_code_prev", "canopy_class_prev", "vigor_prev", "min_dbh_prev")
    focal.prev.time$sp = as.character(focal.prev.time$sp)
    focal2 = merge(focal, focal.prev.time, by = c("uniqueID", "sp"), all = T)
    focal2$growth = focal2$DBH - focal2$DBH_prev
    focal2$numyr = (focal2$julian - focal2$julian_prev) / 365.25
    focal2$growth.per.yr = focal2$growth / focal2$numyr						# Absolute growth per year (used in analysis b/c DBH also included to account for previous diameter)
    focal2$radial.growth.per.yr = (log(focal2$DBH/focal2$DBH_prev)) / focal2$numyr		# Relative Growth Rate per Wright et al. 2018 Ecology
    
    # plot(df$XCOORD,df$YCOORD,asp=1)
    # points(focal2$gx,focal2$gy,pch=19,col="red")
    # points(focal.good2$gx,focal.good2$gy,pch=19,col="purple")
    
    # Remove interior plot corners that are within 10 m of plot boundary (not captured in preceding code)
    if(focal2$STANDID[1] == "RS01") {if(nrow(focal2[which(focal2$gx > 40 & focal2$gx < 50 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 40 & focal2$gx < 50 & focal2$gy > 50 & focal2$gy < 60),]}}
    if(focal2$STANDID[1] == "RS03") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 40 & focal2$gy < 50),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 40 & focal2$gy < 50),]}}
    if(focal2$STANDID[1] == "RS03") {if(nrow(focal2[which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 40 & focal2$gy < 50),]) > 0) {focal2 = focal2[-which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 40 & focal2$gy < 50),]}}
    if(focal2$STANDID[1] == "RS23") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 50 & focal2$gy < 60),]}}
    if(focal2$STANDID[1] == "RS23") {if(nrow(focal2[which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 50 & focal2$gy < 60),]}}
    if(focal2$STANDID[1] == "RS38") {if(nrow(focal2[which(focal2$gx > 25 & focal2$gx < 35 & focal2$gy > 90 & focal2$gy < 100),]) > 0) {focal2 = focal2[-which(focal2$gx > 25 & focal2$gx < 35 & focal2$gy > 90 & focal2$gy < 100),]}}
    if(focal2$STANDID[1] == "RS38") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 115 & focal2$gy < 125),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 115 & focal2$gy < 125),]}}
    
    # Determine 'phi' which is survival from previous census to current census based on continued presence in census and live status
    focal2$phi = c(1)
    focal2$phi[is.na(focal2$DBH)] = 0
    focal2$phi[is.na(focal2$DBH_prev)] = NA
    focal2$gx[is.na(focal2$gx)] = focal2$gx_prev[is.na(focal2$gx)]
    focal2$gy[is.na(focal2$gy)] = focal2$gy_prev[is.na(focal2$gy)]
    focal2$quad = as.character(focal2$quad)
    focal2$quad_prev = as.character(focal2$quad_prev)
    focal2$STANDID = as.character(focal2$STANDID)
    focal2$STANDID_prev = as.character(focal2$STANDID_prev)
    focal2$quad[is.na(focal2$quad)] = focal2$quad_prev[is.na(focal2$quad)]
    focal2$STANDID[is.na(focal2$STANDID)] = focal2$STANDID_prev[is.na(focal2$STANDID)]
    focal2$census[is.na(focal2$census)] = c(unique(focal2$census[!is.na(focal2$YEAR)]))
    focal2$YEAR[is.na(focal2$YEAR)] = c(unique(focal2$YEAR[!is.na(focal2$DBH)]))
    
    # Calculate distance-based abundance metrics for neighborhood density
    adults = df[which(df$DBH >= 15),]
    adults = adults[which(adults$TREE_STATUS %in% c(6,9) == F),]
    adults.prev = df.prev[which(df.prev$DBH >= 15),]
    adults.prev = adults.prev[which(adults.prev$TREE_STATUS %in% c(6,9) == F),]
    adultlocs = data.frame(sp = adults$SPECIES, gx = adults$XCOORD, gy = adults$YCOORD, id = adults$uniqueID, dbh = adults$DBH)
    adultlocs.prev = data.frame(sp = adults.prev$SPECIES, gx = adults.prev$XCOORD, gy = adults.prev$YCOORD, id = adults.prev$uniqueID, dbh = adults.prev$DBH)
    unique.quads = unique(df$quad)
    quad.gx = c()
    quad.gy = c()
    for(z in 1:length(unique.quads)) {
      quad.gx[z] = (25*as.numeric(substr(unique.quads[z],1,2))-12.5)
      quad.gy[z] = (25*as.numeric(substr(unique.quads[z],3,4))-12.5)
    }
    quadlocs = data.frame(id = unique.quads, gx = quad.gx, gy = quad.gy)
    quad.weights.prev = dist.weighted.abund.function(adultlocs = adultlocs.prev, saplocs = quadlocs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
    quad.weights2.prev = Add.missing.sp.names(quad.weights.prev)
    if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
      quad.weights.combined = quad.weights2.prev
    } else {
      quad.weights = dist.weighted.abund.function(adultlocs = adultlocs, saplocs = quadlocs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
      quad.weights2 = Add.missing.sp.names(quad.weights)
      quad.weights.combined = (quad.weights2 + quad.weights2.prev) / 2
    }
    
    focal.phi = focal2[!is.na(focal2$DBH_prev),]
    if(nrow(focal.phi) > 0) {
      focal.phi$order = c(1:nrow(focal.phi))
      focal.phi = focal.phi[order(focal.phi$sp),]
      focal.phi.locs = data.frame(id = focal.phi$uniqueID, gx = focal.phi$gx, gy = focal.phi$gy)
      focal.phi.weights.prev = dist.weighted.abund.function(adultlocs = adultlocs.prev, saplocs = focal.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
      focal.phi.weights2.prev = Add.missing.sp.names(focal.phi.weights.prev)
      if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
        focal.phi.weights.combined = focal.phi.weights2.prev
      } else {
        focal.phi.weights = dist.weighted.abund.function(adultlocs = adultlocs, saplocs = focal.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
        focal.phi.weights2 = Add.missing.sp.names(focal.phi.weights)
        focal.phi.weights.combined = (focal.phi.weights2 + focal.phi.weights2.prev) / 2
      }
      focal.phi = data.frame(focal.phi, focal.phi.weights.combined)
      focal.phi = focal.phi[order(focal.phi$order),]
      focal.phi.list[[i-1]] = focal.phi
    }
  }
  # Combine censuses within a plot for output
  if(length(focal.phi.list) > 0) {
    focal.phi.list = focal.phi.list[which(lapply(focal.phi.list, function(x) {nrow(x) > 0}) == T)]
    focal.phi2 = do.call('rbind', focal.phi.list)
    focal.phi2$yr = focal.phi2$YEAR - 2000
    fd.focal.phi[[q]] = focal.phi2
  }
}




########################################
## Prepare data for analysis
yr.value = 2008
fd.focal.phi2 = do.call('rbind', fd.focal.phi)
fd.focal.phi2 = fd.focal.phi2[order(fd.focal.phi2$STANDID, fd.focal.phi2$sp, fd.focal.phi2$uniqueID, fd.focal.phi2$census),]
fd.focal.phi2$sizeclass = c(NA)
fd.focal.phi3 = split(fd.focal.phi2, as.character(fd.focal.phi2$uniqueID))

# Set sizeclasses for analysis (cutoff points based on data -- trees < 15 cm were only surveyed in subsets of some of the plots, so they are the first sizeclass,
# the other 3 size classes were determined by splitting the data above 15 cm into 3 approximately equal groups (equal number of individual trees)
for(i in 1:length(fd.focal.phi3)) {
  if(min(fd.focal.phi3[[i]]$DBH_prev) < 15 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] < 15) {fd.focal.phi3[[i]]$sizeclass = c(1)}			# Trees that stay in the 5-15 cm sizeclass
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 15 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] < 25.4) {fd.focal.phi3[[i]]$sizeclass = c(2)}		# Trees that stay in the 15-25 cm sizeclass (25.4 = 33rd percentile of DBH for all trees > 15 cm DBH)
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 25.4 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] < 52.06667) {fd.focal.phi3[[i]]$sizeclass = c(3)}	# Trees that stay in the 25-52 cm sizeclass (52.06667 = 67th percentile of DBH for all trees > 15 cm DBH)
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 52.06667) {fd.focal.phi3[[i]]$sizeclass = c(4)}														# Trees that stay in the >52 cm sizeclass
  if(min(fd.focal.phi3[[i]]$DBH_prev) < 15 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] >= 15) {									# Trees that start in the 5-15 cm sizeclass and transition to larger sizeclass
    fd.focal.phi3[[i]]$sizeclass[1:max(which(fd.focal.phi3[[i]]$DBH_prev < 15))] = 1
    fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 15))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 2
    if(max(fd.focal.phi3[[i]]$DBH_prev) >= 25.4) {fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 25.4))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 3}
    if(max(fd.focal.phi3[[i]]$DBH_prev) >= 52.06667) {fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 4}
  }
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 15 & min(fd.focal.phi3[[i]]$DBH_prev) < 25.4 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] >= 25.4) {	# Trees that start in the 15-25 cm sizeclass and transition to larger sizeclass
    fd.focal.phi3[[i]]$sizeclass[1:max(which(fd.focal.phi3[[i]]$DBH_prev < 25.4))] = 2
    fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 25.4))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 3
    if(max(fd.focal.phi3[[i]]$DBH_prev) >= 52.06667) {fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 4}
  }
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 25.4 & min(fd.focal.phi3[[i]]$DBH_prev) < 52.06667 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] >= 52.06667) {	# Trees that start in the 25-52 cm sizeclass and transition to larger sizeclass
    fd.focal.phi3[[i]]$sizeclass[1:max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))] = 3
    fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 4
  }
}
fd.focal.phi4 = do.call('rbind', fd.focal.phi3)
fd.focal.phi5 = merge(fd.focal.phi4, standclimate, by = "STANDID", all.x = T)
fd.focal.phi5$yr2 = fd.focal.phi5$YEAR - yr.value
fd.focal.phi5$conspp = c(NA)
fd.focal.phi5$allspp = c(NA)
fd.focal.phi5$heterospp = c(NA)
adult.cols = which(colnames(fd.focal.phi5) %in% sp.list == T)
# Sum conspecific and heterospecific local densities across species in each neighborhood
for(i in 1:nrow(fd.focal.phi5)) {
  fd.focal.phi5$conspp[i] = fd.focal.phi5[i,which(colnames(fd.focal.phi5) == fd.focal.phi5$sp[i])]
  fd.focal.phi5$allspp[i] = sum(fd.focal.phi5[i,adult.cols])
  fd.focal.phi5$heterospp[i] = sum(fd.focal.phi5[i,adult.cols[which(colnames(fd.focal.phi5[,adult.cols]) != fd.focal.phi5$sp[i])]])
}
fd.focal.phi6 = fd.focal.phi5[which(fd.focal.phi5$census < 9),]	# Remove census 9 (mortality checks only conducted in a small subset of plots)
fd.focal.phi6$plotcen = as.numeric(factor(as.character(factor(as.character(fd.focal.phi6$STANDID)):factor(as.character(fd.focal.phi6$census)))))	# unique ID for each plot-by-census combination
fd.focal.phi7 = split(fd.focal.phi6, fd.focal.phi6$plotcen)
focal.census.intervals = unlist(lapply(fd.focal.phi7,function(x) {(mean(x$julian[which(x$YEAR == max(x$YEAR))]) - mean(x$julian_prev[which(x$YEAR == max(x$YEAR))]))/365.25}))	# Census IDs
focal.census.intervals = data.frame(census.interval = focal.census.intervals, plotcen = names(focal.census.intervals))
focal.census.intervals$cenyr = unlist(lapply(fd.focal.phi7,function(x) {max(x$YEAR)}))
fd.focal.phi6 = merge(fd.focal.phi6, focal.census.intervals, by = "plotcen", all.x = T)







##########################################################################################################
### LMER Analysis for small-tree survival 
### (use data to estimate values of 'alpha' (abundance-weighting parameter), 'beta' (distance-dependence parameter), and 'D' (the nonlinearity parameter)

d = fd.focal.phi6[order(fd.focal.phi6$uniqueID, fd.focal.phi6$census),]
d = d[which(d$sizeclass == 1),]	# Trees in the 5-15 cm sizeclass

 load("WindFloodDamage1.RData")	# Remove trees damaged or killed by density-independent forces: trees affected by floods, wind, snow/ice, mechanical failure, or another tree falling on them, but NOT INCLUDING those trees whose death was also associated with density-dependent effects of neighbor suppression, fungi, pathogens, or insects
 d = d[which(d$uniqueID %in% windflooddamage1 == FALSE),]

# load("WindFloodDamage2.RData")	# Remove trees damaged or killed by density-independent forces: trees affected by floods, wind, snow/ice, mechanical failure, or another tree falling on them, INCLUDING those trees whose death was also associated with density-dependent effects of neighbor suppression, fungi, pathogens, or insects
# d = d[which(d$uniqueID %in% windflooddamage2 == FALSE),]

dlist = split(d, as.character(d$uniqueID))
for(i in 1:length(dlist)) {dlist[[i]]$tinterval = c(1:nrow(dlist[[i]]))}	# Interval indicator for each tree (i.e. 1st interval = 1st interval that a tree was in the census)
d = do.call('rbind', dlist)
hazard = 1 - d$phi		# Mortality indicator (0 = survival, 1 = death)
lgexposure = log(d$numyr)	# log-transformed exposure time (in number of years)
surv = d$phi
d$ID = as.character(d$uniqueID)
tinterval = d$tinterval		

uniID = as.numeric(factor(d$uniqueID))		# Unique ID for each individual
consppid = tapply(d$conspp, uniID, mean)		# Mean conspecific density across individuals
heterosppid = tapply(d$heterospp, uniID, mean)	# Mean heterospecific density across individuals

# Prepare other variables for the model
elevid = tapply(d$ELEVATION, uniID, mean)			# Mean Elevation across individuals (Elevation not used in first modeling step below)
dbhid = tapply(d$DBH_prev, uniID, mean)			# Mean DBH across individuals
yrid = tapply(d$julian_prev/365.25, uniID, mean)	# Scaled census year
ELEV = (d$ELEVATION - mean(elevid)) / sd(elevid)	# Scaled Elevation (not used in first modeling step below)
dbh = (d$DBH_prev - mean(dbhid)) / sd(dbhid)		# Scaled DBH
yr = ((d$julian_prev/365.25) - mean(yrid)) / sd(yrid)	# Scaled census year
yr2 = yr^2								# census year squared
census = as.numeric(as.character(factor(as.character(d$census)))) - 1	# Census number (different from 'tinterval', all trees surveyed at the same timeframe (within a few years) receive the same value for census, but 'tinterval' depends on each individual tree and when they were first surveyed
sp = as.numeric(factor(as.character(d$sp)))		# unique numeric value for each species
sp.info = unique(data.frame(sp.name = d$sp, sp = sp))	# information table with each species' code
plotsp = as.numeric(factor(as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID)))))		# unique ID for each plot-by-species combination
plotsp.info = unique(data.frame(sp = d$sp, plot = d$STANDID, combo = as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID))), plotELEV = ELEV, plotsp = plotsp))	# 'plotsp' key
plotsp.n = data.frame(plotsp = names(tapply(plotsp, plotsp, length)), plotsp.n = tapply(plotsp, plotsp, length))	# sample size of each plot-by-species combination
plotcen = as.numeric(factor(as.character(factor(as.character(d$STANDID)):factor(as.character(d$census)))))	# Unique ID for each plot-by-census combination
plotcen.info = unique(data.frame(yr = d$census, plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID)):factor(as.character(d$census))), plotELEV = ELEV, plotcen = plotcen))	# 'plotcen' key
n.census = length(unique(census))	# number of censuses
n.ID = length(unique(uniID))		# number of unique individuals
n = nrow(d)					# number of observations
spINplot = plotsp.info$sp[order(plotsp.info$plotsp)]	
plotELEV = plotsp.info$plotELEV[order(plotsp.info$plotsp)]
plot = as.numeric(as.factor(d$STANDID))	# Plot ID
prevyr = d$julian_prev/365.25			# Previous census date
firstyr = tapply(d$julian_prev/365.25, uniID, min)[uniID]	# First census date for each tree
texp = tapply(exp(lgexposure), uniID, sum)[uniID]		# Total exposure time for each individual tree (total exposure over life of tree in this size class)
totalexp = (prevyr - firstyr) + exp(lgexposure)			# Cumulative exposure time for each individual tree (cumulative exposure up to current observation)
plotnum = as.numeric(factor(as.character(factor(as.character(d$STANDID)))))	# numeric ID for each plot
plot.info = unique(data.frame(plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID))), plotELEV = ELEV, plotnum = plotnum))	# 'plotnum' key

# Test different values of D (nonlinearity parameter), make sure con- and heterospecific densities are scaled together, so a 1-unit change in one is equivalent to a 1-unit change in the other
density1 = std.conhet.density(conspp = d$conspp, heterospp = d$heterospp, id = uniID, DenExp = 0.1)
sap.off.abs.phi.m1 = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + density1[[1]] + density1[[2]] + dbh:density1[[1]] + dbh:density1[[2]] + 
	(density1[[1]] + density1[[2]]|sp) + (density1[[1]] + density1[[2]]|plotnum) + (density1[[1]] + density1[[2]]|plotsp) + (1|plotcen), 
	family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(sap.off.abs.phi.m1)

density1 = std.conhet.density(conspp = d$conspp, heterospp = d$heterospp, id = uniID, DenExp = 0.2)
sap.off.abs.phi.m2 = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + density1[[1]] + density1[[2]] + dbh:density1[[1]] + dbh:density1[[2]] + 
	(density1[[1]] + density1[[2]]|sp) + (density1[[1]] + density1[[2]]|plotnum) + (density1[[1]] + density1[[2]]|plotsp) + (1|plotcen), 
	family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(sap.off.abs.phi.m2)

density1 = std.conhet.density(conspp = d$conspp, heterospp = d$heterospp, id = uniID, DenExp = 0.3)
sap.off.abs.phi.m3 = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + density1[[1]] + density1[[2]] + dbh:density1[[1]] + dbh:density1[[2]] + 
	(density1[[1]] + density1[[2]]|sp) + (density1[[1]] + density1[[2]]|plotnum) + (density1[[1]] + density1[[2]]|plotsp) + (1|plotcen), 
	family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(sap.off.abs.phi.m3)

density1 = std.conhet.density(conspp = d$conspp, heterospp = d$heterospp, id = uniID, DenExp = 0.4)
sap.off.abs.phi.m4 = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + density1[[1]] + density1[[2]] + dbh:density1[[1]] + dbh:density1[[2]] + 
	(density1[[1]] + density1[[2]]|sp) + (density1[[1]] + density1[[2]]|plotnum) + (density1[[1]] + density1[[2]]|plotsp) + (1|plotcen), 
	family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(sap.off.abs.phi.m4)

density1 = std.conhet.density(conspp = d$conspp, heterospp = d$heterospp, id = uniID, DenExp = 0.5)
sap.off.abs.phi.m5 = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + density1[[1]] + density1[[2]] + dbh:density1[[1]] + dbh:density1[[2]] + 
	(density1[[1]] + density1[[2]]|sp) + (density1[[1]] + density1[[2]]|plotnum) + (density1[[1]] + density1[[2]]|plotsp) + (1|plotcen), 
	family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(sap.off.abs.phi.m5)

density1 = std.conhet.density(conspp = d$conspp, heterospp = d$heterospp, id = uniID, DenExp = 0.6)
sap.off.abs.phi.m6 = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + density1[[1]] + density1[[2]] + dbh:density1[[1]] + dbh:density1[[2]] + 
	(density1[[1]] + density1[[2]]|sp) + (density1[[1]] + density1[[2]]|plotnum) + (density1[[1]] + density1[[2]]|plotsp) + (1|plotcen), 
	family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(sap.off.abs.phi.m6)

density1 = std.conhet.density(conspp = d$conspp, heterospp = d$heterospp, id = uniID, DenExp = 0.7)
sap.off.abs.phi.m7 = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + density1[[1]] + density1[[2]] + dbh:density1[[1]] + dbh:density1[[2]] + 
	(density1[[1]] + density1[[2]]|sp) + (density1[[1]] + density1[[2]]|plotnum) + (density1[[1]] + density1[[2]]|plotsp) + (1|plotcen), 
	family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(sap.off.abs.phi.m7)

density1 = std.conhet.density(conspp = d$conspp, heterospp = d$heterospp, id = uniID, DenExp = 0.8)
sap.off.abs.phi.m8 = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + density1[[1]] + density1[[2]] + dbh:density1[[1]] + dbh:density1[[2]] + 
	(density1[[1]] + density1[[2]]|sp) + (density1[[1]] + density1[[2]]|plotnum) + (density1[[1]] + density1[[2]]|plotsp) + (1|plotcen), 
	family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(sap.off.abs.phi.m8)

density1 = std.conhet.density(conspp = d$conspp, heterospp = d$heterospp, id = uniID, DenExp = 1.0)
sap.off.abs.phi.m10 = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + density1[[1]] + density1[[2]] + dbh:density1[[1]] + dbh:density1[[2]] + 
	(density1[[1]] + density1[[2]]|sp) + (density1[[1]] + density1[[2]]|plotnum) + (density1[[1]] + density1[[2]]|plotsp) + (1|plotcen), 
	family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(sap.off.abs.phi.m10)

density1 = std.conhet.density(conspp = d$conspp, heterospp = d$heterospp, id = uniID, DenExp = 2.0)
sap.off.abs.phi.m20 = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + density1[[1]] + density1[[2]] + dbh:density1[[1]] + dbh:density1[[2]] + 
	(density1[[1]] + density1[[2]]|sp) + (density1[[1]] + density1[[2]]|plotnum) + (density1[[1]] + density1[[2]]|plotsp) + (1|plotcen), 
	family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(sap.off.abs.phi.m20)

density1 = std.conhet.density(conspp = d$conspp, heterospp = d$heterospp, id = uniID, DenExp = 3.0)
sap.off.abs.phi.m30 = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + density1[[1]] + density1[[2]] + dbh:density1[[1]] + dbh:density1[[2]] + 
	(density1[[1]] + density1[[2]]|sp) + (density1[[1]] + density1[[2]]|plotnum) + (density1[[1]] + density1[[2]]|plotsp) + (1|plotcen), 
	family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(sap.off.abs.phi.m30)

# Compare log-likelihoods (subtract constant, which is sum(lgexposure*hazard), to calculate LL of the piecemeal exponential hazard model):
data.frame(loglik = c(logLik(sap.off.abs.phi.m1) - sum(lgexposure*hazard), 
logLik(sap.off.abs.phi.m2) - sum(lgexposure*hazard),
logLik(sap.off.abs.phi.m3) - sum(lgexposure*hazard),
logLik(sap.off.abs.phi.m4) - sum(lgexposure*hazard),
logLik(sap.off.abs.phi.m5) - sum(lgexposure*hazard),
logLik(sap.off.abs.phi.m6) - sum(lgexposure*hazard),
logLik(sap.off.abs.phi.m7) - sum(lgexposure*hazard),
logLik(sap.off.abs.phi.m8) - sum(lgexposure*hazard),
logLik(sap.off.abs.phi.m10) - sum(lgexposure*hazard),
logLik(sap.off.abs.phi.m20) - sum(lgexposure*hazard),
logLik(sap.off.abs.phi.m30) - sum(lgexposure*hazard)))
alpha
beta



# Model with conspecific and heterospecific densities combined (to test if conspecific and heterspecific effects are different):
rtallspp5 = c(scale(d$allspp^(0.5)))
sap.off.abs.phi.m5a = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + rtallspp5 + dbh:rtallspp5 +  
	(rtallspp5|sp) + (rtallspp5|plotnum) + (rtallspp5|plotsp) + (1|plotcen),  
	family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(sap.off.abs.phi.m5a)
(llr = logLik(sap.off.abs.phi.m5a) - sum(lgexposure*hazard))	# logLik for reduced model (with conspecific and heterospecific densities combined)
(llf = logLik(sap.off.abs.phi.m5) - sum(lgexposure*hazard))		# logLik for model with cdd-hdd (separate conspecific and heterospecific densities)








#######################################################################################
### BAYESIAN MODEL OF SAPLING SURVIVAL	

DenExp = 0.5			# Density exponent (non-linearity parameter in neighborhood function; selected from LMER analyses above)
d = fd.focal.phi6[order(fd.focal.phi6$uniqueID, fd.focal.phi6$census),]
d = d[which(d$sizeclass == 1),]	# Trees in the 5-15 cm sizeclass

 load("WindFloodDamage1.RData")	# Remove trees damaged or killed by density-independent forces: trees affected by floods, wind, snow/ice, mechanical failure, or another tree falling on them, but NOT INCLUDING those trees whose death was also associated with density-dependent effects of neighbor suppression, fungi, pathogens, or insects
 d = d[which(d$uniqueID %in% windflooddamage1 == FALSE),]

# load("WindFloodDamage2.RData")	# Remove trees damaged or killed by density-independent forces: trees affected by floods, wind, snow/ice, mechanical failure, or another tree falling on them, INCLUDING those trees whose death was also associated with density-dependent effects of neighbor suppression, fungi, pathogens, or insects
# d = d[which(d$uniqueID %in% windflooddamage2 == FALSE),]

# Prepare data for analysis (for description of variables, please see annotated LMER data set-up code above)
dlist = split(d, as.character(d$uniqueID))
for(i in 1:length(dlist)) {dlist[[i]]$tinterval = c(1:nrow(dlist[[i]]))}
d = do.call('rbind', dlist)
hazard = 1 - d$phi
lgexposure = log(d$numyr)
surv = d$phi
d$ID = as.character(d$uniqueID)
tinterval = d$tinterval
uniID = as.numeric(factor(d$uniqueID))
consppid = tapply(d$conspp, uniID, mean)
heterosppid = tapply(d$heterospp, uniID, mean)
conhetero = c(consppid^(DenExp), heterosppid^(DenExp))
density1 = std.conhet.density(conspp = d$conspp, heterospp = d$heterospp, id = uniID, DenExp = DenExp)
conspp = density1[[1]]
heterospp = density1[[2]]
allspp = c(scale(d$allspp^(DenExp)))
elevid = tapply(d$ELEVATION, uniID, mean)
dbhid = tapply(d$DBH_prev, uniID, mean)
yrid = tapply(d$julian_prev/365.25, uniID, mean)
ELEV = (d$ELEVATION - mean(elevid)) / sd(elevid)
dbh = (d$DBH_prev - mean(dbhid)) / sd(dbhid)
yr = ((d$julian_prev/365.25) - mean(yrid)) / sd(yrid)
yr2 = yr^2
census = as.numeric(as.character(factor(as.character(d$census)))) - 1
sp = as.numeric(factor(as.character(d$sp)))
sp.info = unique(data.frame(sp.name = d$sp, sp = sp))
plotsp = as.numeric(factor(as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID)))))
plotsp.info = unique(data.frame(sp = d$sp, plot = d$STANDID, combo = as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID))), plotELEV = ELEV, plotsp = plotsp))
plotsp.n = data.frame(plotsp = names(tapply(plotsp, plotsp, length)), plotsp.n = tapply(plotsp, plotsp, length))
plotcen = as.numeric(factor(as.character(factor(as.character(d$STANDID)):factor(as.character(d$census)))))
plotcen.info = unique(data.frame(yr = d$census, plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID)):factor(as.character(d$census))), plotELEV = ELEV, plotcen = plotcen))
n.census = length(unique(census))
n.ID = length(unique(uniID))
n = nrow(d)
spINplot = plotsp.info$sp[order(plotsp.info$plotsp)]
plotELEV = plotsp.info$plotELEV[order(plotsp.info$plotsp)]
plot = as.numeric(as.factor(d$STANDID))
n.plotcen = length(unique(plotcen))
plotnum = as.numeric(factor(as.character(factor(as.character(d$STANDID)))))
plot.info = unique(data.frame(plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID))), plotELEV = ELEV, plotnum = plotnum))
tinterval2 = rep(0, times = length(tinterval)); tinterval2[which(tinterval == 2)] = 1	# Categorical indicators for census interval
tinterval3 = rep(0, times = length(tinterval)); tinterval3[which(tinterval == 3)] = 1
tinterval4 = rep(0, times = length(tinterval)); tinterval4[which(tinterval == 4)] = 1
tinterval5 = rep(0, times = length(tinterval)); tinterval5[which(tinterval == 5)] = 1
tinterval6 = rep(0, times = length(tinterval)); tinterval6[which(tinterval == 6)] = 1
tinterval7 = rep(0, times = length(tinterval)); tinterval7[which(tinterval == 7)] = 1
x = cbind(rep(1,times = n), dbh, tinterval2, tinterval3, tinterval4, tinterval5, tinterval6, tinterval7, yr, yr2, conspp, heterospp, conspp*dbh, heterospp*dbh)	
K = ncol(x)
PX = cbind(rep(1,times = n), conspp, heterospp)		# Plot-by-species predictor matrix
PK = ncol(PX)							# Num of plot-by-speciespredictors
PJ = length(unique(plotsp))					# Number of unique plot-by-sp combos
RX = cbind(rep(1,times = n), conspp, heterospp)		# Plot predictor matrix
RK = ncol(RX)							# Num of plot predictors
RJ = length(unique(plotnum))					# Num of plots
SX = cbind(rep(1,times = n), conspp, heterospp)		# Species predictor matrix
SK = ncol(SX)							# Num of species predictors
SJ = length(unique(sp))						# Num of species
spINplot = plotsp.info$sp[order(plotsp.info$plotsp)]
plotELEV = plotsp.info$plotELEV[order(plotsp.info$plotsp)]


# Bundle data for STAN
dat <- list(y = hazard, lgexposure = lgexposure, x = x, K = K, plotsp = plotsp, plotnum = plotnum, sp = sp, census = plotcen, nID = n.ID, uniID = uniID,
	ncensus = n.plotcen, PJ = PJ, PK = PK, PX = PX, RJ = RJ, RK = RK, RX = RX, SJ = SJ, SK = SK, SX = SX, N = n)

# LMER model with ML for ranef variance estimates (to obtain initial values for STAN HMC model below)
set.seed(314)
m1 = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + conspp + heterospp + conspp:dbh + heterospp:dbh + 
	(conspp + heterospp|sp) + (conspp + heterospp|plotnum) + (conspp + heterospp|plotsp) + (1|plotcen), family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(m1)
logLik(m1) - sum(lgexposure*hazard)



### Fit STAN model 
# HMC Parameters
nchains = 5					# Number of chains to run
postburn = 4000				# Number of post-burn-in posterior samples
burnin = 500				# Number of burn-in samples
its = postburn + burnin			# Total number of samples to be drawn from posterior
thin = 10					# Rate at which to thin the posterior samples		
hmc_seed = 55406				# HMC seed for reproducibility

# Initial values from LMER model
vc <- VarCorr(m1)
sigma_SB_lmer = as.matrix(Matrix::bdiag(vc$sp))
sigma_PB_lmer = as.matrix(Matrix::bdiag(vc$plotsp))
sigma_RB_lmer = as.matrix(Matrix::bdiag(vc$plotnum))
inits <- replicate(nchains, list(
  Pz = t(data.matrix(ranef(m1)$'plotsp')),
  PL_Omega = sigma_PB_lmer,
  Ptau_unif = runif(PK),
  Rz = t(data.matrix(ranef(m1)$'plotnum')),
  RL_Omega = sigma_RB_lmer,
  Rtau_unif = runif(RK),
  Sz = t(data.matrix(ranef(m1)$'sp')),
  SL_Omega = sigma_SB_lmer,
  Stau_unif = runif(SK),
  beta = fixef(m1),
  sigma_YEAR = attr(summary(m1)$varcor$plotcen,"stddev")[[1]],
  YEAR = ranef(m1)$'plotcen'[[1]], 
  PB = data.matrix(ranef(m1)$'plotsp'), 
  sigma_PB = sigma_PB_lmer, 
  Ptau = runif(PK), 
  RB = data.matrix(ranef(m1)$'plotnum'), 
  sigma_RB = sigma_RB_lmer, 
  Rtau = runif(RK), 
  SB = data.matrix(ranef(m1)$'sp'), 
  sigma_SB = sigma_SB_lmer, 
  Stau = runif(SK)
), simplify = F)


# Run model
begin = Sys.time()
fit <- stan(file = "HJA_GLMM_ExpHazard_Model_STAN.stan", 			# Stan model
  data = dat,   										# named list of data
  init = inits,										# initial values for parameters
  chains = nchains,             							# number of Markov chains
  warmup = burnin,          								# number of warmup iterations per chain
  iter = its,            								# total number of iterations per chain
  cores = nchains,              							# number of cores (could use one per chain)
  thin = thin,										# Thin rate
  seed = hmc_seed,									# HMC seed for reproducibility
  control = list(adapt_delta = 0.99)						# HMC sampling parameter
  )
end = Sys.time()
(duration = end - begin)

# save(fit, file = "HJA_5to15cmDBH_ExpHazard_Bayesian_alpha0-0_beta0-35_exp0-5_STAN_20210917_windflood1.RData")

# load("HJA_5to15cmDBH_ExpHazard_Bayesian_alpha0-0_beta0-35_exp0-5_STAN_20210917_windflood1.RData")





# HMC traceplots
traceplot(fit, pars = c("beta"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("sigma_YEAR"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("sigma_PB"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("sigma_SB"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("sigma_ID"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("PL_Omega"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("SL_Omega"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("Sz"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("Stau"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("Ptau"), inc_warmup = TRUE, nrow = 3)



# test for auto-correlation in chains
draws <- extract(fit, permuted = FALSE)
acf(c(draws[,,"beta[1]"]), lag.max = 100)
acf(c(draws[,,"beta[2]"]), lag.max = 100)
acf(c(draws[,,"beta[3]"]), lag.max = 100)
acf(c(draws[,,"beta[4]"]), lag.max = 100)
acf(c(draws[,,"beta[5]"]), lag.max = 100)
acf(c(draws[,,"beta[6]"]), lag.max = 100)
acf(c(draws[,,"beta[7]"]), lag.max = 100)
acf(c(draws[,,"sigma_YEAR"]), lag.max = 100)
acf(c(draws[,,"sigma_PB[1,1]"]), lag.max = 100)
acf(c(draws[,,"sigma_PB[2,2]"]), lag.max = 100)
acf(c(draws[,,"sigma_RB[1,2]"]), lag.max = 100)
acf(c(draws[,,"sigma_RB[1,1]"]), lag.max = 100)
acf(c(draws[,,"sigma_RB[2,2]"]), lag.max = 100)
acf(c(draws[,,"sigma_PB[1,2]"]), lag.max = 100)
acf(c(draws[,,"sigma_SB[1,1]"]), lag.max = 100)
acf(c(draws[,,"sigma_SB[2,2]"]), lag.max = 100)
acf(c(draws[,,"sigma_SB[1,2]"]), lag.max = 100)






# Extract estimates
draws <- extract(fit, permuted = FALSE)
beta.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta")])),3,c)
SB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB")])),3,c)
SB.m = array(SB.m, dim = c(nrow(SB.m),SJ,SK), dimnames = list(paste("it",c(1:nrow(SB.m)),sep=""),paste("sp",c(1:SJ),sep=""),paste("SB",c(1:SK),sep="")))
PB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB")])),3,c)
PB.m = array(PB.m, dim = c(nrow(PB.m),PJ,PK), dimnames = list(paste("it",c(1:nrow(PB.m)),sep=""),paste("plotsp",c(1:PJ),sep=""),paste("PB",c(1:PK),sep="")))
RB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,2) == "RB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "RB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "RB")])),3,c)
RB.m = array(RB.m, dim = c(nrow(RB.m),RJ,RK), dimnames = list(paste("it",c(1:nrow(RB.m)),sep=""),paste("plotsp",c(1:RJ),sep=""),paste("RB",c(1:RK),sep="")))
census.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")])),3,c)
plotcen.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")])),3,c)
sigmaSB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB")])),3,c)
sigmaPB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB")])),3,c)
sigmaRB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_RB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_RB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_RB")])),3,c)
sigmaYR.m = c(draws[,,"sigma_YEAR"])

ll.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,7) == "log_lik")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,7) == "log_lik"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,7) == "log_lik")])),3,c)
fittedvalues = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,6) == "fitted")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,6) == "fitted"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,6) == "fitted")])),3,c)
lgexposuremat = matrix(lgexposure, nrow = nrow(fittedvalues), ncol = length(lgexposure), byrow = T)

Sz.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,2) == "Sz")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "Sz"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "Sz")])),3,c)
Pz.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,2) == "Pz")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "Pz"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "Pz")])),3,c)
Rz.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,2) == "Rz")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "Rz"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "Rz")])),3,c)
Stau.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,4) == "Stau")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "Stau"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "Stau")])),3,c)
SL_Omega.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,8) == "SL_Omega")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "SL_Omega"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "SL_Omega")])),3,c)
(SL_Cholesky = diag(apply(Stau.m,2,mean)[4:6])%*%matrix(apply(SL_Omega.m,2,mean),nrow=3,ncol=3))
matrix(apply(sigmaSB.m,2,mean),nrow=3,ncol=3)
cov2cor(matrix(apply(sigmaSB.m,2,mean),nrow=3,ncol=3))
Ptau.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,4) == "Ptau")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "Ptau"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "Ptau")])),3,c)
PL_Omega.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,8) == "PL_Omega")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "PL_Omega"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "PL_Omega")])),3,c)
(PL_Cholesky = diag(apply(Ptau.m,2,mean)[4:6])%*%matrix(apply(PL_Omega.m,2,mean),nrow=3,ncol=3))
matrix(apply(sigmaPB.m,2,mean),nrow=3,ncol=3)
cov2cor(matrix(apply(sigmaPB.m,2,mean),nrow=3,ncol=3))
Rtau.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,4) == "Rtau")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "Rtau"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "Rtau")])),3,c)
RL_Omega.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,8) == "RL_Omega")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "RL_Omega"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "RL_Omega")])),3,c)
(RL_Cholesky = diag(apply(Rtau.m,2,mean)[4:6])%*%matrix(apply(RL_Omega.m,2,mean),nrow=3,ncol=3))
matrix(apply(sigmaRB.m,2,mean),nrow=3,ncol=3)
cov2cor(matrix(apply(sigmaRB.m,2,mean),nrow=3,ncol=3))

getME(m1,"theta")	# Cholesky factors from the lmer model

# Estimates
t(apply(beta.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(beta.m,2,mean)
t(apply(sigmaSB.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(sigmaSB.m,2,mean)
t(apply(sigmaPB.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(sigmaPB.m,2,mean)
t(apply(sigmaRB.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(sigmaRB.m,2,mean)
quantile(sigmaYR.m^2,c(0.025,0.975,0.05,0.95,0.5)); mean(sigmaYR.m^2)









# Hazard and survival through time
interval.exposure = tapply(exp(lgexposure[hazard==0]), tinterval[hazard==0], mean)
baseline.hazard = mean(beta.m[,1]) + c(0, apply(beta.m[,3:8], 2, mean))
hazardx = c()
timex = seq(0,sum(interval.exposure), length=100)
for(i in 1:(length(timex)-1)) {hazardx[i] = baseline.hazard[which(timex[i] < cumsum(interval.exposure) & timex[i] >= (cumsum(interval.exposure) - interval.exposure))]}
hazardx[length(timex)] = baseline.hazard[length(baseline.hazard)]

plot(timex, exp(hazardx), xlab = "Time (years since entering census)", ylab = "Instantaneous hazard", main = "5-15 cm DBH Size Class")

cumhazx = c()
for(i in 1:(length(hazardx)-1)) {cumhazx[i] = exp(hazardx[i+1])*(timex[2:length(timex)] - timex[1:(length(timex)-1)])[i]}

plot(timex, c(1,exp(-cumsum(cumhazx))), ylim=c(0,1), xlab = "Time (years since entering census)", ylab = "Cumulative survival of average tree", main = "5-15 cm DBH Size Class")












######################################
### GOODNESS OF FIT TESTS

# Residual plots using 'DHARMa' R package

# Simulated predicted values and scaled residuals (for use with R DHARMa package)
# Piece-wise exponential survival models (where the replicate is the individual) use the same likelihood, estimates, and SE as poisson regression with psuedo-observations 
# 	for each interval(the likelihood differs by a constant = sum(lgexposure*hazard)). 
# Therefore, pre-packaged predicted values & residuals from LMER & STAN need to be transformed properly before predicting new values or using residuals from packages like DHARMa.
# Piece-wise exponential survival models estimate the instantaneous hazard rate for each individual at each census interval (these are the fitted values from 
# 	the poisson regression). However, to predict survival for an individual, these need to be combined into a cumulative hazard for each individual integrated 
# 	across time (i.e. all census intervals in which that individual was observed, i.e. not including if they were censored becuase they moved to a larger sizeclass).
# For more information on these models, please see Germ�n Rodr�guez's website: https://data.princeton.edu/wws509/notes/c7s1
# Survival is hazard rate integrated over time, so we need to calculate the hazard rate for each interval in which a tree was under observation and integrate over time. 
# The following code organizes hazard rates for each census interval for each tree individual
# 	'hazmat' is a matrix with 1 row per individual and 1 column for each census. 
# Note: some individuals entered in later censuses (ingrowth) and some individuals leave the census when they 
# 	recruit to a larger sizeclass (i.e. their DBH in the first census of a given interval goes permanently above the sizeclass threshold of 15 cm, 25.4 cm, or 52 cm).  This kind of 
# 	censoring is allowed in piecewise exponential survival models -- the death indicator tells whether "leaving the census" should be 
# 	informative to hazard (i.e. death) or not (i.e. recruitment to larger sizeclass or last census conducted).
# The code below simulates predicted survival probabilities for hypothetical trees occupying the same conditions as the data. 
# The DHARMa functions then take those simulated survival probabilities and compare them to the observed data to create residual plots. 

# Prepare data and model
log_lik = ll.m - t(t(lgexposuremat) * hazard)
fitted.m = exp(fittedvalues - lgexposuremat)
dev.m = rowSums(log_lik)*-2
Z = length(sigmaYR.m)
cumhaz.m = matrix(NA,nrow=Z,ncol=n)
hazmat.m = list()
predS.phi.m = matrix(NA,nrow=Z,ncol=n.ID)
survsim.phi.m = matrix(NA,nrow=Z,ncol=n.ID)
cumhaz = cumhaz.m = exp(fittedvalues)
for(z in 1:Z) {
  hazmat.m[[z]] = matrix(NA, nrow = n.ID, ncol = max(census))
  hazmat.m[[z]][cbind(uniID, census)] = cumhaz.m[z,]
}
insthaz = fitted.m
chid = matrix(NA,nrow=Z,ncol=n.ID)		# Cumulative hazard for each individual up to time of death or censoring
llid = matrix(NA,nrow=Z,ncol=n.ID)
lasthazid = matrix(NA,nrow=Z,ncol=n.ID)
hazid = c()		# death indicator for each tree individual
consppid = c()	# scaled conspecific density for each tree individual
heterosppid = c()	# scaled heterospecific density for each tree individual
mindbhid = c()	# Minimum scaled dbh for each tree individual
cenid = c()		# first census
plotnumid = c()	# plot for each individual
plotspid = c()	# plotsp for each individual
plotcenid = c()	# plotcen for each individual
spid = c()		# sp for each individual
cenid = c()		# first census
firstyrid = c()	# first year in census
lastcenid = c()	# last year in census

for(i in 1:n.ID) {						# Calculate values at the individual level
  if(sum(uniID == i) > 1) {
    chid[,i] = rowSums(cumhaz[,uniID == i])
    llid[,i] = rowSums(log_lik[,uniID == i])
    lasthazid[,i] = insthaz[,uniID == i][,which(census[uniID == i] == max(census[uniID == i]))]
  }
  if(sum(uniID == i) == 1) {
    chid[,i] = cumhaz[,uniID == i]
    llid[,i] = log_lik[,uniID == i]
    lasthazid[,i] = insthaz[,uniID == i]
  }
  hazid[i] = max(hazard[uniID == i])
  consppid[i] = mean(conspp[uniID == i])
  heterosppid[i] = mean(heterospp[uniID == i])
  mindbhid[i] = min(dbh[uniID == i])
  firstyrid[i] = (yr[uniID == i])[1]
  plotspid[i] = (plotsp[uniID == i])[1]
  plotnumid[i] = (plotnum[uniID == i])[1]
  plotcenid[i] = (plotcen[uniID == i])[1]
  firstyrid[i] = (yr[uniID == i])[1]
  spid[i] = (sp[uniID == i])[1]
  cenid[i] = min(census[uniID == i])
  lastcenid[i] = max(census[uniID == i])
}
yrcensus = tapply(yr, plotcen, mean)
expcensus = log(tapply(exp(lgexposure[hazard==0]), plotcen[hazard==0], mean))
testmat = matrix(NA, nrow = n.ID, ncol = max(census))
testmat[cbind(uniID, census)] = 1
maxcenexp = 1
expm1 = lm(apply(testmat[hazid==0 & cenid <= maxcenexp,],1,function(x) {sum(!is.na(x))})~exp(mindbhid[hazid==0 & cenid <= maxcenexp]))
plot(mindbhid[hazid==0 & cenid <= maxcenexp], jitter(apply(testmat[hazid==0 & cenid <= maxcenexp,],1,function(x) {sum(!is.na(x))})))	# Expected number of intervals it takes a living tree to successfully recruit to the next sizeclass as a function of DBH when entering census
x1 = seq(min(mindbhid), max(mindbhid), length=500); lines(x1, coef(expm1)[1] + (coef(expm1)[2]*exp(x1)))

begin.time = Sys.time()
for(z in 1:Z) {
  # Arrange predictors in a matrix with rows = individuals and columns = census intervals
  Xsim = x
  SXsim = SX
  RXsim = RX
  PXsim = PX
  plotcenSim = plotcen
  lgexpSim = lgexposure
  IDSim = uniID
  censusSim = census
  spSim = sp
  plotspSim = plotsp
  plotnumSim = plotnum
  SBfit = SB.m[z,,]
  PBfit = PB.m[z,,]
  RBfit = RB.m[z,,]
  YRfit = plotcen.m[z,]
  for(i in 1:n) {		
    if(hazard[i] == 1 & max(census[uniID == uniID[i]]) < 7) {
      expectedsurveys = round(coef(expm1)[1] + (coef(expm1)[2]*exp(mindbhid[uniID[i]])))	# Expected number of intervals a living tree should stay in this sizeclass given initial DBH (used to calculate time to integrate hazard over for predicting survival for a hypothetical new tree with those same conditions)
      ntimes = expectedsurveys - max(tinterval[uniID == uniID[i]])
      if((ntimes + max(census[uniID == uniID[i]])) > 7) {ntimes = 7 - max(census[uniID == uniID[i]])}
      if(ntimes > 0) {
        Xn = matrix(rep(x[i,],each=ntimes),nrow=ntimes)						# For those individuals that died, extend their observation period to that expected for a tree entering the census at the same DBH (so that a total cumulative hazard can be calculated for that tree across the entire observation period)
        Xn[,3:8] = c(0) 
        tintervali = seq(max(tinterval[uniID == uniID[i]]) + 1, max(tinterval[uniID == uniID[i]]) + ntimes, by = 1)
        for(j in 1:ntimes) {Xn[j, (tintervali[j] + 1)] = 1}
        censusi = seq(max(census[uniID == uniID[i]]) + 1, max(census[uniID == uniID[i]]) + ntimes, by = 1)
        plotname = d$STANDID[i]
        plotceni = plotcen.info$plotcen[which(plotcen.info$plot == plotname & plotcen.info$yr %in% (censusi + 1) == T)]
        lgexpi = c()
        for(j in 1:ntimes) {
          Xn[j,9] = yrcensus[plotceni[j]]
          lgexpi[j] = expcensus[plotceni[j]]
        }
        Xn[,10] = Xn[,9]^2
        Xsim = rbind(Xsim, Xn)
        spSim = c(spSim, rep(sp[i], times = ntimes))
        plotspSim = c(plotspSim, rep(plotsp[i], times = ntimes))
        plotnumSim = c(plotnumSim, rep(plotnum[i], times = ntimes))
        SXsim = rbind(SXsim, matrix(rep(SX[i,],each=ntimes),nrow=ntimes))
        RXsim = rbind(RXsim, matrix(rep(RX[i,],each=ntimes),nrow=ntimes))
        PXsim = rbind(PXsim, matrix(rep(PX[i,],each=ntimes),nrow=ntimes))
        plotcenSim = c(plotcenSim, plotceni)
        lgexpSim = c(lgexpSim, lgexpi)
        censusSim = c(censusSim, censusi)
        IDSim = c(IDSim, rep(uniID[i], times = ntimes))
      }
    }
  }
  # Predicted values
  intHaz = c()
  set.seed(314)
  fixef.pred = (Xsim %*% beta.m[z,]) + lgexpSim			# Hazard based on fixed effects only for each individual and survival interval
  for(i in 1:nrow(Xsim)) {
    intHaz[i] = exp(fixef.pred[i] + (SXsim[i,] %*% SBfit[spSim[i],]) + (RXsim[i,] %*% RBfit[plotnumSim[i],]) + (PXsim[i,] %*% PBfit[plotspSim[i],]) + YRfit[plotcenSim[i]])	# Add random effects for each individual and census interval to get hazard based on fixed & random effects for each individual and survival interval
  }
  predtab = data.frame(id = names(tapply(intHaz, IDSim, sum)), cumhaz = tapply(intHaz, IDSim, sum))	# Sum hazards for each individual across all census intervals to get cumulative hazards
  predtab$predsurv = exp(-1*predtab$cumhaz)										# Convert cumulative hazard to survival probability
  predS.phi.m[z,] = predtab$predsurv											# Save predicted survival probabilities for each individual and each posterior sample as 'predS.phi.m'
}
end.time = Sys.time()
(duration = end.time - begin.time)

set.seed(314)
rep2.m = list()
for(i in 1:nrow(predS.phi.m)){rep2.m[[i]] = as.numeric(rbinom(n = length(predS.phi.m[i,]), size = 1, prob = predS.phi.m[i,]))}	# simulate survival or death for each individual at each posterio sample for 'DHARMa' package
rep2.m = do.call('rbind', rep2.m)


# DHARMa scaled residuals
sim2 = createDHARMa(simulatedResponse = t(1-rep2.m), observedResponse = as.vector(hazid), fittedPredictedResponse = apply(1-predS.phi.m, 2, median), integerResponse = T)
plot(sim2)
# testOutliers(sim2, type = "bootstrap")
plotResiduals(sim2, xlab = "Scaled predicted survival probability for each ind.")
plotResiduals(sim2, form = consppid, xlab = "Scaled mean conspecific density for each ind.")
plotResiduals(sim2, form = heterosppid, xlab = "Scaled mean heterospecific density for each ind.")
plotResiduals(sim2, form = dbhid, xlab = "Scaled minimum DBH for each ind.")
plotResiduals(sim2, form = factor(spid), xlab = "Scaled species ID for each ind.")
plotResiduals(sim2, form = factor(plotnumid), xlab = "Scaled species ID for each ind.")
plotResiduals(sim2, form = factor(plotspid), xlab = "Scaled plot-by-species ID for each ind.")
plotResiduals(sim2, form = factor(plotcenid), xlab = "Scaled plot-by-census ID for each ind.")
plotResiduals(sim2, form = factor(firstyrid), xlab = "Scaled first year in census for each ind.")



#pdf("HJA_5-15cmDBH_Survival_Bayesian_residual_plots_main_20210914.pdf", height = 5, width = 9, useDingbats=FALSE)
plot(sim2)
#dev.off()

#pdf("HJA_5-15cmDBH_Survival_Bayesian_residual_plots_predictors_20210914.pdf", height = 9, width = 8, useDingbats=FALSE)
set.seed(314)
par(mfrow=c(3,2))
par(mar=c(4,4,2,2))
plotResiduals(sim2, form = consppid, xlab = "Scaled mean conspecific density for each ind.")
plotResiduals(sim2, form = heterosppid, xlab = "Scaled mean heterospecific density for each ind.")
plotResiduals(sim2, form = dbhid, xlab = "Scaled minimum DBH for each ind.")
plotResiduals(sim2, form = factor(spid), xlab = "Scaled species ID for each ind.")
plotResiduals(sim2, form = factor(plotnumid), xlab = "Scaled species ID for each ind.")
testDispersion(sim2)
#dev.off()











# Leave-one-out fit metrics (LOO)
# *Run Goodness-of-fit R code above first, the LOO code below depends on object 'llid' which is the log-likelihood matrix for each individual & each posterior sample

# Leave-one-out fit metrics
library(loo)
begin = Sys.time()
r_eff <- relative_eff(exp(llid), chain_id = rep(1:5,each=400), cores = 5)
loo_1 <- loo(llid, r_eff = r_eff, cores = 5)
end = Sys.time()
(duration = end - begin)
print(loo_1)

# save(loo_1, file = "LOO_ExpSurvival_5to15cmDBH_CDD.RData")
load("LOO_ExpSurvival_5to15cmDBH_CDD.RData")
loo_base = loo_1

# Comparison to model with DBH random slopes at the species level
load("LOO_ExpSurvival_5to15cmDBH_DBHre.RData")
# ELPD
sum(loo_base$pointwise[,1] - loo_1$pointwise[,1])			# Difference in ELPD between models (ELPD diff = -7.47618, DBHre model slightly better fit)
sqrt(n.ID*var(loo_base$pointwise[,1] - loo_1$pointwise[,1]))	# SE of difference in ELPD		(SE of diff = 4.467967, but models within 2 SE of each other)

# Comparision to model with separate heterospecific effects (heterospecific effects split into confamilial and heterofamilial effects)
# ELPD
load("LOO_ExpSurvival_5to15cmDBH_confam.RData")
sum(loo_base$pointwise[,1] - loo_1$pointwise[,1])			# Difference in ELPD between models	(ELPD diff = -2.875458, sep hetero effects model slightly better fit)
sqrt(n.ID*var(loo_base$pointwise[,1] - loo_1$pointwise[,1]))	# SE of difference in ELPD		(SE of diff = 3.656612, but models are within 1 SE of each other)









# logLik and dev at mean posterior parameters (for DIC calculation)
beta.mean = apply(beta.m, 2, mean)
SB.mean = apply(SB.m,c(2,3),mean)
PB.mean = apply(PB.m,c(2,3),mean)
RB.mean = apply(RB.m,c(2,3),mean)
plotcen.mean = apply(plotcen.m, 2, mean)
  SBbysp = matrix(NA,nrow=n,ncol=SK)					# Prepare model matrices for predictions
  for(i in 1:n) {SBbysp[i,] = SB.mean[sp[i],]}
  PBbyplotsp = matrix(NA,nrow=n,ncol=PK)
  for(i in 1:n) {PBbyplotsp[i,] = PB.mean[plotsp[i],]}
  RBbyplotnum = matrix(NA,nrow=n,ncol=RK)
  for(i in 1:n) {RBbyplotnum[i,] = RB.mean[plotnum[i],]}
  YRbycensus = c()
  for(i in 1:n) {YRbycensus[i] = plotcen.mean[plotcen[i]]}
fitted.meanpar = exp((x %*% beta.mean) + rowSums(SX*SBbysp) + rowSums(RX*RBbyplotnum) + rowSums(PX*PBbyplotsp) + YRbycensus)	# Fitted instantaneous hazard from model at mean posterior values
logLik.meanpar = (log(fitted.meanpar) * hazard) - (fitted.meanpar * exp(lgexposure))							# Log-likelihood for each individual at each interval at mean posterior values
logLik.meanpar.sum = sum(logLik.meanpar)															# Summed log-likelihood at mean posterior values
dev.meanpar = -2 * logLik.meanpar.sum															# Model deviance at mean posterior values
pD = mean(dev.m) - dev.meanpar																# pD for model
DIC = dev.meanpar + (2*pD)																	# DIC for model
dev.meanpar; pD; DIC

# DIC of this model = 5364.789
# DIC of model with random species slopes for DBH = 5347.463 (diff = 17.326)
# DIC of model with separate heterospp effects (confam & heterofam) = 5355.385 (diff = 9.404)









## For Posterior Predictive Check (based on all samples from the posterior parameter distributions)
## Requires object 'predS.phi.m' from residual plot code above
rep.m = list()
sim_log_lik = list()
prop.predict = c()
prop.predict.death = c()
prop.predict.live = c()
cumhaz.id = matrix(NA,nrow=Z,ncol=n.ID)
lasthaz.id = matrix(NA,nrow=Z,ncol=n.ID)
exposure.id = c()
sp.id = c()
plotsp.id = c()
hazard.id = c()
for(i in 1:n.ID) {
  if(sum(uniID == i) == 1) {cumhaz.id[,i] = fitted.m[,which(uniID == i)] * exp(lgexposure[which(uniID == i)])}	# Calculate cumulative hazard for each individual
  if(sum(uniID == i) > 1) {cumhaz.id[,i] = fitted.m[,which(uniID == i)] %*% exp(lgexposure[which(uniID == i)])}
  lasthaz.id[,i] = fitted.m[,which(uniID == i)[which.max(census[which(uniID == i)])]]					# Calculate instantaneous hazard at last interval for each individual
  exposure.id[i] = sum(exp(lgexposure[which(uniID == i)]))										# Calculate total exposure time for each individual
  hazard.id[i] = max(hazard[which(uniID == i)])												# Death indicator for each individual (1 = death, 0 = life)
  sp.id[i] = mean(sp[which(uniID == i)])													# Species ID for each individual
  plotsp.id[i] = mean(plotsp[which(uniID == i)])											# Plot-by-species ID for each individual
}
set.seed(314)
for(i in 1:nrow(fitted.m)){
  rep.m[[i]] = as.numeric(rbernoulli(n = length(1 - predS.phi.m[i,]), p = (1 - predS.phi.m[i,])))	# Simulated survival for each individual based on predicted cuculative hazard probabilities at each posterior sample
  sim_log_lik[[i]] = (log(lasthaz.id[i,]) * rep.m[[i]]) - (cumhaz.id[i,])					# Simulated log-likelihood for each individual based on simulated survival at each posterior sample
}
rep.m = do.call('rbind', rep.m)
sim_log_lik = do.call('rbind', sim_log_lik)
for(i in 1:nrow(rep.m)) {
  prop.predict[i] = mean(hazard.id==rep.m[i,])				# Proportion of individuals where survival/mortlaity is correctly simulated based on model at each posterior sample
}
for(i in 1:nrow(rep.m)) {
  prop.predict.death[i] = mean(rep.m[i,][which(hazard.id==1)])	# Proportion of dead individuals where mortlaity is correctly simulated based on model at each posterior sample
}
for(i in 1:nrow(rep.m)) {
  prop.predict.live[i] = 1-mean(rep.m[i,][which(hazard.id==0)])	# Proportion of surviving individuals where survival is correctly simulated based on model at each posterior sample
}

summary(prop.predict)						# posterior classification accuracy
summary(prop.predict.live)					# posterior classification accuracy of survival
summary(prop.predict.death)					# posterior classification accuracy of death
summary((prop.predict.death + prop.predict.live)/2)	# posterior balanced classification accuracy


# LogLik posterior predictive test
loglik.obs = rowSums(log_lik)
loglik.sim = rowSums(sim_log_lik)
summary(loglik.obs)
summary(loglik.sim)
#pdf("HJA_5to15cmDBH_ExpSurvival_logLik_PPC_BAYES_20220129.pdf", height = 4, width = 5, useDingbats=FALSE)
hist(loglik.sim, breaks=30, xlab = "Log-likelihood of simulated data", las = 1, main = "5-15 cm DBH survival log-likelihood PPC")
abline(v = mean(loglik.obs), lwd = 2, col = "red")
sum(loglik.sim > mean(loglik.obs)) / nrow(rep.m)
#dev.off()


# Mortality posterior predictive test
mean(hazard.id)
mean.hazard.sim = apply(rep.m,1,mean)
summary(mean.hazard.sim)
#pdf("HJA_5to15cmDBH_ExpSurvival_Mortality_PPC_BAYES_20220129.pdf", height = 4, width = 5, useDingbats=FALSE)
hist(mean.hazard.sim, breaks=20, xlab = "Proportion of individuals dead in simulated data", las = 1, main = "5-15 cm DBH survival mortality PPC")
abline(v = mean(hazard.id), lwd = 2, col = "red")
sum(mean.hazard.sim > mean(hazard.id)) / nrow(rep.m)
#dev.off()


# Posterior predictive tests for mortality levels in each species, each plot, and each species-by-plot combo
sp.test = list()
for(i in 1:nrow(rep.m)) {
  sp.test[[i]] = tapply(rep.m[i,], sp.id, mean)
}
sp.test = do.call('rbind', sp.test)
obs.sp.test = tapply(hazard.id, sp.id, mean)
sp.test.p = c()
for(j in 1:ncol(sp.test)) {
  sp.test.p[j] = min(sum(sp.test[,j] >= obs.sp.test[j]), sum(sp.test[,j] <= obs.sp.test[j])) / length(sp.test[,j])
  if(obs.sp.test[j] == 0 | obs.sp.test[j] == 1) {sp.test.p[j] = (sum(sp.test[,j] == obs.sp.test[j]) / length(sp.test[,j]))/2}
}
summary(sp.test.p); sum(sp.test.p < 0.025 | sp.test.p > 0.975)
tapply(hazard.id, sp.id, mean)
apply(sp.test,2,mean)
tapply(hazard.id, sp.id, mean) - apply(sp.test,2,mean)


plot.test = list()
for(i in 1:nrow(rep.m)) {
  plot.test[[i]] = tapply(rep.m[i,], plotnumid, mean)
}
plot.test = do.call('rbind', plot.test)
obs.plot.test = tapply(hazard.id, plotnumid, mean)
plot.test.p = c()
for(j in 1:ncol(plot.test)) {
  plot.test.p[j] = min(sum(plot.test[,j] >= obs.plot.test[j]), sum(plot.test[,j] <= obs.plot.test[j])) / length(plot.test[,j])
  if(obs.plot.test[j] == 0 | obs.plot.test[j] == 1) {plot.test.p[j] = (sum(plot.test[,j] == obs.plot.test[j]) / length(plot.test[,j]))/2}
}
summary(plot.test.p); sum(plot.test.p < 0.025 | plot.test.p > 0.975)
tapply(hazard.id, plotnumid, mean)
apply(plot.test,2,mean)
tapply(hazard.id, plotnumid, mean) - apply(plot.test,2,mean)



plotsp.test = list()
for(i in 1:nrow(rep.m)) {
  plotsp.test[[i]] = tapply(rep.m[i,], plotsp.id, mean)
}
plotsp.test = do.call('rbind', plotsp.test)
obs.plotsp.test = tapply(hazard.id, plotsp.id, mean)
plotsp.test.p = c()
for(j in 1:ncol(plotsp.test)) {
  plotsp.test.p[j] = min(sum(plotsp.test[,j] >= obs.plotsp.test[j]), sum(plotsp.test[,j] <= obs.plotsp.test[j])) / length(plotsp.test[,j])
  if(obs.plotsp.test[j] == 0 | obs.plotsp.test[j] == 1) {plotsp.test.p[j] = (sum(plotsp.test[,j] == obs.plotsp.test[j]) / length(plotsp.test[,j]))/2}
}
summary(plotsp.test.p); sum(plotsp.test.p < 0.025 | plotsp.test.p > 0.975) / length(plotsp.test.p)
tapply(hazard.id, plotsp.id, mean)
apply(plotsp.test,2,mean)
tapply(hazard.id, plotsp.id, mean) - apply(plotsp.test,2,mean)





















###################################################################################
# CDD-HDD average predictive comparisons and visualize model

load("Standclimate2.RData")
names(standclimate2)[1] = "plot"

DenExp = 0.5		# D parameter (nonlinearity parameter) selected based on data
StdAdultDen = 1.1925	# Mean tree density across all tree neighborhoods with parameters Alpha = 0.0 and Beta = 0.35
zerotree = (0 - mean(conhetero)) / sd(conhetero)					# Standardized density index with zero trees (only used to calculate separate conspecific and heterospecific effects, not for CDD-HDD)
onetree = ((StdAdultDen^DenExp) - mean(conhetero)) / sd(conhetero)		# Standardized density index at mean tree density (for comparing conspecific stand to heterospecific stand)
halftree = (((StdAdultDen/2)^DenExp) - mean(conhetero)) / sd(conhetero)		# Standardized density index at half of mean tree density (for determining survival in a stand composed of half conspecifics and half heterospecifics)
consppid = tapply(d$conspp, uniID, mean)
heterosppid = tapply(d$heterospp, uniID, mean)
plotsp.info2 = plotsp.info[order(plotsp.info$plotsp),]
names(plotsp.info2)[1] = "sp.name"
plotsp.info2 = merge(plotsp.info2, sp.info, by = "sp.name", all = T, sort = FALSE)
plotsp.info2 = merge(plotsp.info2, plot.info[,c("plot", "plotnum")], by = "plot", all.x = T, sort = FALSE)
plotsp.info2 = merge(plotsp.info2, standclimate2, by = "plot", all.x = T, sort = FALSE)
load("HJA_Species_Mean_Abundances_across_Censuses_by_Plot.RData")			# Add in species abundances for CDD-HDD and species abundance relationships
abund$ba.ha = abund$ba / abund$area_ha
abund$abund.ha = abund$abund / abund$area_ha
names(abund)[2] = "sp.name"
plotsp.info2 = merge(plotsp.info2, abund, by = c("sp.name", "plot"), all.x = T, sort = FALSE)
plotsp.info2 = merge(plotsp.info2, plotsp.n, by = "plotsp", all.x = T, sort = FALSE)
plotsp.info2 = plotsp.info2[order(plotsp.info2$plotsp),]
plot.info3 = unique(plotsp.info2[,c("plot", "plotELEV", "plotnum", "ELEVATION", "LATITUDE", "LONGITUDE", "meansummertemppts", "meanspringtemppts", "minspringtemppts", "area_ha")])
plot.info3 = plot.info3[order(plot.info3$plotnum),]

# Data for avg. perdictive comparisons (Hi = "high" conspecific density; defined as mean density of trees, all conspecifics)
xHi = cbind(rep(1,times = n), dbh, tinterval2, tinterval3, tinterval4, tinterval5, tinterval6, tinterval7, yr, yr2, onetree, zerotree, onetree*dbh, zerotree*dbh)	
PXHi = cbind(rep(1,times = n), onetree, zerotree)		# Plot-by-species predictor matrix
RXHi = cbind(rep(1,times = n), onetree, zerotree)		# Plot predictor matrix
SXHi = cbind(rep(1,times = n), onetree, zerotree)		# Species predictor matrix

# Data for avg. perdictive comparisons (Lo = "low" conspecific density; defined as mean density of trees, all heterospecifics)
xLo = cbind(rep(1,times = n), dbh, tinterval2, tinterval3, tinterval4, tinterval5, tinterval6, tinterval7, yr, yr2, zerotree, onetree, zerotree*dbh, onetree*dbh)	
PXLo = cbind(rep(1,times = n), zerotree, onetree)		# Plot-by-species predictor matrix
RXLo = cbind(rep(1,times = n), zerotree, onetree)		# Plot predictor matrix
SXLo = cbind(rep(1,times = n), zerotree, onetree)		# Species predictor matrix

# Data for avg. perdictive comparisons (No = No large trees (>15 cm DBH), i.e. gap)
xNo = cbind(rep(1,times = n), dbh, tinterval2, tinterval3, tinterval4, tinterval5, tinterval6, tinterval7, yr, yr2, zerotree, zerotree, zerotree*dbh, zerotree*dbh)	
PXNo = cbind(rep(1,times = n), zerotree, zerotree)		# Plot-by-species predictor matrix
RXNo = cbind(rep(1,times = n), zerotree, zerotree)		# Plot predictor matrix
SXNo = cbind(rep(1,times = n), zerotree, zerotree)		# Species predictor matrix

# Data for avg. perdictive comparisons (Mid = "intermediate" conspecific density; defined as mean density of trees, half conspecifics & half heterospecifics)
xMid = cbind(rep(1,times = n), dbh, tinterval2, tinterval3, tinterval4, tinterval5, tinterval6, tinterval7, yr, yr2, halftree, halftree, halftree*dbh, halftree*dbh)	
PXMid = cbind(rep(1,times = n), halftree, halftree)		# Plot-by-species predictor matrix
RXMid = cbind(rep(1,times = n), halftree, halftree)		# Plot predictor matrix
SXMid = cbind(rep(1,times = n), halftree, halftree)		# Species predictor matrix



# Calculate average predictive comparisons for each plot-by-species (Gelman & Pardoe 2007, Gustafson 2007)

realcndd.plotsp = list()
realcdd.plotsp = list()
realhdd.plotsp = list()
meanphi.plotsp = list()

begin.time = Sys.time()
for(j in 1:PJ) {
  Z = length(sigmaYR.m)
  realcndd.m = matrix(NA,nrow=Z,ncol=n.ID)
  realcdd.m = matrix(NA,nrow=Z,ncol=n.ID)
  realhdd.m = matrix(NA,nrow=Z,ncol=n.ID)
  meanphi.m = matrix(NA,nrow=Z,ncol=n.ID)
  for(z in 1:Z) {							# Prepare model matrices for predictions
    SBbysp = matrix(NA,nrow=n,ncol=SK)
    for(i in 1:n) {SBbysp[i,] = SB.m[z,plotsp.info2$sp[j],]}
    RBbyplotnum = matrix(NA,nrow=n,ncol=RK)
    for(i in 1:n) {RBbyplotnum[i,] = RB.m[z,plotsp.info2$plotnum[j],]}
    PBbyplotsp = matrix(NA,nrow=n,ncol=PK)
    for(i in 1:n) {PBbyplotsp[i,] = PB.m[z,plotsp.info2$plotsp[j],]}
    YRbycensus = c()
    for(i in 1:n) {YRbycensus[i] = plotcen.m[z,plotcen[i]]}
    intHazHi = exp(lgexposure + (xHi %*% beta.m[z,]) + rowSums(SXHi*SBbysp) + rowSums(RXHi*RBbyplotnum) + rowSums(PXHi*PBbyplotsp) + YRbycensus)	# Instantaneous hazard x exposure time in conspecific stand for each census interval
    intHazLo = exp(lgexposure + (xLo %*% beta.m[z,]) + rowSums(SXLo*SBbysp) + rowSums(RXLo*RBbyplotnum) + rowSums(PXLo*PBbyplotsp) + YRbycensus)	# Instantaneous hazard x exposure time in heterospecific stand for each census interval
    intHazNo = exp(lgexposure + (xNo %*% beta.m[z,]) + rowSums(SXNo*SBbysp) + rowSums(RXNo*RBbyplotnum) + rowSums(PXNo*PBbyplotsp) + YRbycensus)	# Instantaneous hazard x exposure time in absence of con/heterospecific competitors (gap) for each census interval
    intHazMid = exp(lgexposure + (xMid %*% beta.m[z,]) + rowSums(SXMid*SBbysp) + rowSums(RXMid*RBbyplotnum) + rowSums(PXMid*PBbyplotsp) + YRbycensus)	# Instantaneous hazard x exposure time in a half-conspecific, half-heterospecific stand for each census interval (to assess mean survival)
    cumHazHi = tapply(intHazHi, uniID, sum)		# Cumulative hazard in conspecific stand for each individual
    cumHazLo = tapply(intHazLo, uniID, sum)		# Cumulative hazard in heterospecific stand for each individual
    cumHazNo = tapply(intHazNo, uniID, sum)		# Cumulative hazard in absence of con/heterospecific competitors (gap) for each individual
    cumHazMid = tapply(intHazMid, uniID, sum)		# Cumulative hazard in a half-conspecific, half-heterospecific stand for each individual (to assess mean survival)
    expID = tapply(exp(lgexposure), uniID, sum)		# Total exposure time for each individual (used to standardize cumulative survival probabilities to annual survival)
    phiHi = exp(-cumHazHi)^(1/expID)			# Standardize cumulative survival probability in conspecific stand to annual survival for all individuals
    phiLo = exp(-cumHazLo)^(1/expID)			# Standardize cumulative survival probability in heterospecific stand to annual survival for all individuals
    phiNo = exp(-cumHazNo)^(1/expID)			# Standardize cumulative survival probability in gap stand to annual survival for all individuals
    phiMid = exp(-cumHazMid)^(1/expID)			# Standardize cumulative survival probability in a half-conspecific, half-heterospecific stand to annual survival for all individuals
    realcndd.m[z,] = phiHi - phiLo				# Calculate CDD-HDD by comparing predicted survival for each individual in a conspecific stand to predicted survival in a heterospecific stand (each at mean tree density)
    realcdd.m[z,] = phiHi - phiNo				# Calculate CDD by comparing predicted survival for each individual in a conspecific stand to predicted survival in the absence of competition
    realhdd.m[z,] = phiLo - phiNo				# Calculate HDD by comparing predicted survival for each individual in a heterospecific stand to predicted survival in the absence of competition
    meanphi.m[z,] = phiMid					# Calculate mean predicted survival as predicted survival for each individual in a half-conspecific, half-heterospecific stand (at mean total tree density)
  }
realcndd.plotsp[[j]] = apply(realcndd.m, 1, mean)	# Calculate average predictive comparison for CDD-HDD (by averaging over all individuals for each posterior sample)
realcdd.plotsp[[j]] = apply(realcdd.m, 1, mean)		# Calculate average predictive comparison for CDD (by averaging over all individuals for each posterior sample)
realhdd.plotsp[[j]] = apply(realhdd.m, 1, mean)		# Calculate average predictive comparison for HDD (by averaging over all individuals for each posterior sample)
meanphi.plotsp[[j]] = apply(meanphi.m, 1, mean)		# Calculate average predictive comparison for mean survival (by averaging over all individuals for each posterior sample)
}
end.time = Sys.time()
(duration = end.time - begin.time)

realcndd.plotsp = do.call('cbind', realcndd.plotsp)
realcdd.plotsp = do.call('cbind', realcdd.plotsp)
realhdd.plotsp = do.call('cbind', realhdd.plotsp)
meanphi.plotsp = do.call('cbind', meanphi.plotsp)

# save(realcndd.plotsp, realcdd.plotsp, realhdd.plotsp, meanphi.plotsp, file = "HJA_Survival_5-15cmDBH_realcndd_matrices_20211123.RData")
# load("HJA_Survival_5-15cmDBH_realcndd_matrices_20211123.RData")



# Average predictive comparison for each plot-by-species combination
realcndd.plotspAPC = apply(realcndd.plotsp, 2, mean)


# Plot-level average predictive comparisons
plotsp.w = tapply(plotsp, plotsp, length)
plot.index = tapply(plot, plotsp, median)

realcndd.plotnum = list()
for(i in 1:RJ) {
  if(sum(plot.index == i) > 1) {realcndd.plotnum[[i]] = apply(realcndd.plotsp[,which(plot.index == i)], 1, weighted.mean, w = plotsp.w[which(plot.index == i)])}
  if(sum(plot.index == i) == 1) {realcndd.plotnum[[i]] = realcndd.plotsp[,which(plot.index == i)]}
}
realcndd.plotnum = do.call('cbind', realcndd.plotnum)


#####################################################################################
# Optional Bayesian bootstrap reflecting subsampling of species within plots 
# (unnecessary b/c not subsampling species within plot -- these are full plot censuses
# and inculde data on all tree species in these size classes across the entire 6,400 ha HJA watershed)
#
#Zits = 10
#realcndd.plotnuma = matrix(NA, nrow = (Z * Zits), ncol = RJ)
#set.seed(314)
#for(j in 1:RJ) {
#  realcndd.plotnumalist = list()
#  for(z in 1:Z) {
#    realcndd.plotnumalist[[z]] = bayesian.bootstrap(test_sample = realcndd.plotsp[z,which(plot.index == j)], nIts = Zits, sample.weights = c(plotsp.w[which(plot.index == j)]))
#  }
#  realcndd.plotnuma[,j] = do.call('rbind', realcndd.plotnumalist)
#}
#realcndd.plotnum = realcndd.plotnuma
#####################################################################################




# Pairwise plot comparisons
pdmat = matrix(NA, nrow = 23, ncol = 23)
for(i in 1:RJ) {
for(j in 1:RJ) {
pdmat[i,j] = sum((realcndd.plotnum[,i] - realcndd.plotnum[,j]) < 0) / length(realcndd.plotnum[,i])
}}
pdmat2=pdmat
pdmat2[pdmat > 0.05 & pdmat < 0.95] = NA
diag(pdmat2) <- NA
pdmat2
plot.info3
problow = c()
probhi = c()
for(i in 1:23) {
  probhi[i] = sum(pdmat2[,i] >= 0.95, na.rm = T)
  problow[i] = sum(pdmat2[,i] <= 0.05, na.rm = T)
}

# For plot-level predictive comparisons:
# red = >95% probability of being lower than at least 5 other plots, >95% probability of being higher than none
# orange = >95% probability of being lower than at least 1 other plot, >95% probability of being higher than none
# green = >95% probability of being lower than at least 1 other plot, >95% probability of being higher than at least 1 other plot
# blue = >95% probability of being lower than no other plots, >95% probability of being higher than at least 1 other plot
# purple = >95% probability of being lower than no other plots, >95% probability of being higher than at least 5 other plots

probcol = data.frame(plot = plot.info3$plot, plotnum = plot.info3$plotnum, problow, probhi, 
	probcol = c("blue", "blue", "blue", "blue", "blue", "blue", "purple", "orange", "blue", "blue", "blue", 
	"orange", "blue", "blue", "purple", "blue", "blue", "green", "red", "blue", "blue", "green", "red"))



# Display plot-level and plot-by-species level predictive comparisons against elevation

# pdf("HJA_5-15cmDBH_Survival_Hazard_CDD-HDD_BAYES_Elev_byPlot_20220129.pdf", height = 10, width = 5, useDingbats=FALSE)
par(pty="s")
par(mfrow=c(2,1))
set.seed(314)
elevjit = jitter(plot.info3$ELEVATION, amount = 15)
elevjit2 = data.frame(elevjit, plot = plot.info3$plot)
plotsp.info5 = merge(plotsp.info2, elevjit2, by = "plot", all.x = T)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]
plotsp.info5$points = realcndd.plotspAPC
plot(plotsp.info5$elevjit, realcndd.plotspAPC, cex.axis = 1.2, las = 1, ylim=c(min(realcndd.plotspAPC),max(realcndd.plotspAPC)),
	main = "5-15 cm DBH", type = "n", ylab = "", xlab = "Elevation (m)", cex.lab = 1.2)
mtext("Change in survival from CNDD", side = 2, line = 4, cex = 1.2)
abline(h=0,lty=2)

plotmedians = apply(realcndd.plotnum, 2, median)
plotlci = apply(realcndd.plotnum, 2, quantile, 0.025)
plotuci = apply(realcndd.plotnum, 2, quantile, 0.975)
plotliq = apply(realcndd.plotnum, 2, quantile, 0.25)
plotuiq = apply(realcndd.plotnum, 2, quantile, 0.75)

for(i in 1:RJ) {
colwd = 15
medwd = 0.002
transp1 = 0.15
transp2 = 0.3
points(plotsp.info5$elevjit[which(plotsp.info5$plotnum == i)], plotsp.info5$points[which(plotsp.info5$plotnum == i)], 
	cex = (plotsp.info5$plotsp.n[which(plotsp.info5$plotnum == i)]*0.03)^(1/4), col =  adjustcolor(probcol$probcol[i], alpha.f = 0.8))
polygon(x = c(elevjit[i]-(colwd/2), elevjit[i]+(colwd/2),elevjit[i]+(colwd/2), elevjit[i]-(colwd/2)), 
	y = c(plotlci[i], plotlci[i], plotuci[i], plotuci[i]),
        col =  adjustcolor(probcol$probcol[i], alpha.f = transp1), border = NA)
polygon(x = c(elevjit[i]-(colwd/2), elevjit[i]+(colwd/2),elevjit[i]+(colwd/2), elevjit[i]-(colwd/2)), 
	y = c(plotliq[i], plotliq[i], plotuiq[i], plotuiq[i]),
        col =  adjustcolor(probcol$probcol[i], alpha.f = transp2), border = NA)
polygon(x = c(elevjit[i]-(colwd/2), elevjit[i]+(colwd/2),elevjit[i]+(colwd/2), elevjit[i]-(colwd/2)), 
	y = c(plotmedians[i]-(medwd/2), plotmedians[i]-(medwd/2), plotmedians[i]+(medwd/2), plotmedians[i]+(medwd/2)),
        col =  probcol$probcol[i], border = NA)
}

# Panel 2: species-by-plot combos IDed 
sp.info2 = data.frame(sp.info[order(sp.info$sp),])
load("HJA_CNDD_Analyses_Species_Colors_for_figures.RData")
sp.info2 = merge(sp.info2, sp.col[,c("sp.name", "sp.col", "sp.pch")], by = "sp.name", all.x = T)
sp.col2 = data.frame(sp = sp.col$sp.name, sp.col = sp.col$sp.col, sp.pch = sp.col$sp.pch)
plotsp.info5 = merge(plotsp.info5, sp.info2, by = "sp", all.x = T, sort = F)

# Plot CDD-HDD estiamtes across plots and species (posterior means)
plot(plotsp.info5$elevjit, realcndd.plotspAPC, 
	xlab = "Elevation (m)", ylab = "", cex.lab = 1.2,
	pch=19, las=1, main = "5-15 cm DBH", type = "n", cex.axis = 1.2)
mtext("Change in survival from CNDD", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
set.seed(314)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info5[which(plotsp.info5$sp == sp.info2$sp[i]),]
points(plot.subset$elevjit, plot.subset$points, cex = (plot.subset$plotsp.n*0.02)^(1/4), 
	col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)
	}

# dev.off()






# Plot-level predictive comparisons against PC2 of Elevation and minimum spring temperatures 
# combined effect of increasing elevation and increasing min spring temps (Fig. S3): 
# low values of PC2 = Lower-elevation valley bottoms
# intermediate values of PC2 = Lower-elevation midslopes, higher elevation valley bottoms
# high values of PC2 = Lower-elevation ridges, hihger-elevation midslopes/ridges

# PCA of elevation and min. spring temperatures from Frey et al 2016
pc = princomp(plot.info3[,c("ELEVATION", "minspringtemppts")], cor = T)
summary(pc)
loadings(pc)
pc1 = pc$scores[,1]
pc2 = pc$scores[,2]

rbPal <- colorRampPalette(c('brown','orange','green'))
Col1 <- rbPal(10)[as.numeric(cut(pc2,breaks = 10))]
plot(plot.info3[,c("ELEVATION", "minspringtemppts")], col = Col1, pch = 19)


# Display plot-level and plot-by-species level predictive comparisons against PC2

# pdf("HJA_5-15cmDBH_Survival_Hazard_CDD-HDD_BAYES_PC2_byPlot_20220129.pdf", height = 10, width = 5, useDingbats=FALSE)
par(pty="s")
par(mfrow=c(2,1))
set.seed(314)
pc2jit = jitter(pc2, amount = 0.05)
pc1jit2 = data.frame(pc2jit, plot = plot.info3$plot)
plotsp.info5 = merge(plotsp.info2, pc1jit2, by = "plot", all.x = T)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]
plotsp.info5$points = realcndd.plotspAPC
plot(plotsp.info5$pc2jit, realcndd.plotspAPC, las = 1, cex.axis = 1.2, ylim=c(min(realcndd.plotspAPC),max(realcndd.plotspAPC)),
	ylab = "", main = "5-15 cm DBH", type = "n", xlab = "PC2", cex.lab = 1.2)
mtext("Change in survival from CNDD", side = 2, line = 4, cex = 1.2)
abline(h=0,lty=2)

plotmedians = apply(realcndd.plotnum, 2, median)
plotlci = apply(realcndd.plotnum, 2, quantile, 0.025)
plotuci = apply(realcndd.plotnum, 2, quantile, 0.975)
plotliq = apply(realcndd.plotnum, 2, quantile, 0.25)
plotuiq = apply(realcndd.plotnum, 2, quantile, 0.75)

for(i in 1:RJ) {
colwd = 0.03
medwd = 0.002
transp1 = 0.15
transp2 = 0.3
points(plotsp.info5$pc2jit[which(plotsp.info5$plotnum == i)], plotsp.info5$points[which(plotsp.info5$plotnum == i)], 
	cex = (plotsp.info5$plotsp.n[which(plotsp.info5$plotnum == i)]*0.03)^(1/4), col =  adjustcolor(probcol$probcol[i], alpha.f = 0.8))
polygon(x = c(pc2jit[i]-(colwd/2), pc2jit[i]+(colwd/2),pc2jit[i]+(colwd/2), pc2jit[i]-(colwd/2)), 
	y = c(plotlci[i], plotlci[i], plotuci[i], plotuci[i]),
        col =  adjustcolor(probcol$probcol[i], alpha.f = transp1), border = NA)
polygon(x = c(pc2jit[i]-(colwd/2), pc2jit[i]+(colwd/2),pc2jit[i]+(colwd/2), pc2jit[i]-(colwd/2)), 
	y = c(plotliq[i], plotliq[i], plotuiq[i], plotuiq[i]),
        col =  adjustcolor(probcol$probcol[i], alpha.f = transp2), border = NA)
polygon(x = c(pc2jit[i]-(colwd/2), pc2jit[i]+(colwd/2),pc2jit[i]+(colwd/2), pc2jit[i]-(colwd/2)), 
	y = c(plotmedians[i]-(medwd/2), plotmedians[i]-(medwd/2), plotmedians[i]+(medwd/2), plotmedians[i]+(medwd/2)),
        col =  probcol$probcol[i], border = NA)
}

# Panel 2: species-by-plot combos IDed 
sp.info2 = data.frame(sp.info[order(sp.info$sp),])
load("HJA_CNDD_Analyses_Species_Colors_for_figures.RData")
sp.info2 = merge(sp.info2, sp.col[,c("sp.name", "sp.col", "sp.pch")], by = "sp.name", all.x = T)
sp.col2 = data.frame(sp = sp.col$sp.name, sp.col = sp.col$sp.col, sp.pch = sp.col$sp.pch)
plotsp.info5 = merge(plotsp.info5, sp.info2, by = "sp", all.x = T, sort = F)

# Plot CDD-HDD estiamtes across plots and species (posterior means)
plot(plotsp.info5$pc2jit, realcndd.plotspAPC, 
	xlab = "PC2", ylab = "", cex.lab = 1.2, 
	pch=19, las=1, main = "5-15 cm DBH", type = "n", cex.axis = 1.2)
mtext("Change in survival from CNDD", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
set.seed(314)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info5[which(plotsp.info5$sp == sp.info2$sp[i]),]
points(plot.subset$pc2jit, plot.subset$points, cex = (plot.subset$plotsp.n*0.03)^(1/4), 
	col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)
	}

# dev.off()









# Bayesian bootstrap to obtain average CDD-HDD across all forest plots
plotnum.w = plot.info3$area_ha
Z2 = nrow(realcndd.plotnum)
Zits = 100			# Number of bootstrap iterations at each of the Z posterior samples 
realcndd.all = list()
set.seed(314)
for(z in 1:Z2) {
  realcndd.all[[z]] = bayesian.bootstrap(test_sample = realcndd.plotnum[z,], nIts = Zits, sample.weights = plotnum.w)
}
realcndd.all = do.call('c', realcndd.all)

boxplot(realcndd.all)
quantile(realcndd.all, c(0.025,0.5,0.975)); mean(realcndd.all)
sum(realcndd.all < 0) / length(realcndd.all)








# Average predictive comparisons at particular elevation bands 
# Low = 460-700 m (8 plots), Middle = 700-950 m (8 plots), High = 950-1440 m (7 plots)
plotnum.w = plot.info3$area_ha
elev.index = rep(1, times = RJ)
elev.index[which(plot.info3$ELEVATION >= 700 & plot.info3$ELEVATION < 950)] = 2
elev.index[which(plot.info3$ELEVATION >= 950)] = 3

# Bayesian bootstrap to obtain average CDD-HDD at low, mid, and high elevations
Z2 = nrow(realcndd.plotnum)
Zits = 100			# Number of bootstrap iterations at each of the Z posterior samples 
realcndd.elevs = matrix(NA, nrow = (Z2 * Zits), ncol = max(elev.index))
set.seed(314)
for(j in 1:max(elev.index)) {
  realcndd.elevlist = list()
  for(z in 1:Z2) {
    realcndd.elevlist[[z]] = bayesian.bootstrap(test_sample = realcndd.plotnum[z,which(elev.index == j)], nIts = Zits, sample.weights = plotnum.w[which(elev.index == j)])
  }
  realcndd.elevs[,j] = do.call('c', realcndd.elevlist)
}
boxplot(realcndd.elevs)

quantile(realcndd.elevs[,1], c(0.025,0.5,0.975)); mean(realcndd.elevs[,1])
sum(realcndd.elevs[,1] < 0) / length(realcndd.elevs[,1])
quantile(realcndd.elevs[,2], c(0.025,0.5,0.975)); mean(realcndd.elevs[,2])
sum(realcndd.elevs[,2] < 0) / length(realcndd.elevs[,2])
quantile(realcndd.elevs[,3], c(0.025,0.5,0.975)); mean(realcndd.elevs[,3])
sum(realcndd.elevs[,3] < 0) / length(realcndd.elevs[,3])

quantile(realcndd.elevs[,1] - realcndd.elevs[,3], c(0.025,0.5,0.975)); mean(realcndd.elevs[,1] - realcndd.elevs[,3])
sum((realcndd.elevs[,1] - realcndd.elevs[,3]) < 0) / length(realcndd.elevs[,3])
quantile(realcndd.elevs[,1] - realcndd.elevs[,2], c(0.025,0.5,0.975)); mean(realcndd.elevs[,1] - realcndd.elevs[,2])
sum((realcndd.elevs[,1] - realcndd.elevs[,2]) < 0) / length(realcndd.elevs[,3])
quantile(realcndd.elevs[,2] - realcndd.elevs[,3], c(0.025,0.5,0.975)); mean(realcndd.elevs[,2] - realcndd.elevs[,3])
sum((realcndd.elevs[,2] - realcndd.elevs[,3]) < 0) / length(realcndd.elevs[,3])

plot(plotsp.info2$ELEVATION, realcndd.plotspAPC, cex = (plotsp.info2$plotsp.n*0.03)^(1/4))







# Plot-level predictive comparisons against PC2 of Elevation and minimum spring temperatures 
# combined effect of increasing elevation and increasing min spring temps (Fig. S3): 
# low values of PC2 = Lower-elevation valley bottoms
# intermediate values of PC2 = Lower-elevation midslopes, higher elevation valley bottoms
# high values of PC2 = Lower-elevation ridges, hihger-elevation midslopes/ridges

plotnum.w = plot.info3$area_ha
pc2.index = rep(1, times = RJ)
pc2.index[which(pc2 >= -0.25 & pc2 < 0.25)] = 2
pc2.index[which(pc2 >= 0.25)] = 3
plot.info3$pc2 = pc2

# Bayesian bootstrap to obtain average CDD-HDD at low, mid, and high values of PC2
Z2 = nrow(realcndd.plotnum)
Zits = 100			# Number of bootstrap iterations at each of the Z posterior samples 
realcndd.pc2 = matrix(NA, nrow = (Z2 * Zits), ncol = max(pc2.index))
set.seed(314)
for(j in 1:max(pc2.index)) {
  realcndd.pc2list = list()
  for(z in 1:Z2) {
    realcndd.pc2list[[z]] = bayesian.bootstrap(test_sample = realcndd.plotnum[z,which(pc2.index == j)], nIts = Zits, sample.weights = plotnum.w[which(pc2.index == j)])
  }
  realcndd.pc2[,j] = do.call('c', realcndd.pc2list)
}

boxplot(realcndd.pc2)

quantile(realcndd.pc2[,1], c(0.025,0.5,0.975)); mean(realcndd.pc2[,1])
sum(realcndd.pc2[,1] < 0) / length(realcndd.pc2[,1])
quantile(realcndd.pc2[,2], c(0.025,0.5,0.975)); mean(realcndd.pc2[,2])
sum(realcndd.pc2[,2] < 0) / length(realcndd.pc2[,2])
quantile(realcndd.pc2[,3], c(0.025,0.5,0.975)); mean(realcndd.pc2[,3])
sum(realcndd.pc2[,3] < 0) / length(realcndd.pc2[,3])

quantile(realcndd.pc2[,1] - realcndd.pc2[,3], c(0.025,0.5,0.975)); mean(realcndd.pc2[,1] - realcndd.pc2[,3])
sum((realcndd.pc2[,1] - realcndd.pc2[,3]) < 0) / length(realcndd.pc2[,3])
quantile(realcndd.pc2[,1] - realcndd.pc2[,2], c(0.025,0.5,0.975)); mean(realcndd.pc2[,1] - realcndd.pc2[,2])
sum((realcndd.pc2[,1] - realcndd.pc2[,2]) < 0) / length(realcndd.pc2[,3])
quantile(realcndd.pc2[,2] - realcndd.pc2[,3], c(0.025,0.5,0.975)); mean(realcndd.pc2[,2] - realcndd.pc2[,3])
sum((realcndd.pc2[,2] - realcndd.pc2[,3]) < 0) / length(realcndd.pc2[,3])

# save(realcndd.elevs, realcndd.pc2, file = "HJA_CNDD_5-15cmDHB_Survival_Avg_Predictive_Comparisons.RData")










# Plot elevation predictive comparisons and PC2 predictive comparisons

# pdf("HJA_5-15cmDBH_Survival_Hazard_CDD-HDD_BAYES_ELEV-PC2_20220129.pdf", height = 10, width = 5, useDingbats=FALSE)
par(pty="s")
par(mfrow=c(2,1))
set.seed(314)
set.seed(314)
elevzones = c(580, 825, 1195)
elevcols = c("red", "orange", "blue")
elevjit = jitter(plot.info3$ELEVATION, amount = 15)
elevjit2 = data.frame(elevjit, plot = plot.info3$plot)
plotsp.info5 = merge(plotsp.info2, elevjit2, by = "plot", all.x = T)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]
plotsp.info5$points = realcndd.plotspAPC
plotsp.info5$elevzone = c(1)
plotsp.info5$elevzone[which(plotsp.info5$ELEVATION >= 700 & plotsp.info5$ELEVATION < 950)] = 2
plotsp.info5$elevzone[which(plotsp.info5$ELEVATION >= 950)] = 3
plotsp.info5$elevcol = c("red")
plotsp.info5$elevcol[which(plotsp.info5$ELEVATION >= 700 & plotsp.info5$ELEVATION < 950)] = "orange"
plotsp.info5$elevcol[which(plotsp.info5$ELEVATION >= 950)] = "blue"
plot(plotsp.info5$elevjit, realcndd.plotspAPC, las = 1, ylab = "", cex.lab = 1.2, cex.axis = 1.2, 
	main = "5-15 cm DBH", type = "n", xlab = "Elevation (m)")
mtext("Change in survival from CNDD", side = 2, line = 4, cex = 1.2)
abline(h=0,lty=2)

plotmedians = apply(realcndd.elevs, 2, median)
plotlci = apply(realcndd.elevs, 2, quantile, 0.025)
plotuci = apply(realcndd.elevs, 2, quantile, 0.975)
plotliq = apply(realcndd.elevs, 2, quantile, 0.25)
plotuiq = apply(realcndd.elevs, 2, quantile, 0.75)

for(i in 1:3) {
colwd = 190
medwd = 0.0015
transp1 = 0.15
transp2 = 0.3
polygon(x = c(elevzones[i]-(colwd/2), elevzones[i]+(colwd/2),elevzones[i]+(colwd/2), elevzones[i]-(colwd/2)), 
	y = c(plotlci[i], plotlci[i], plotuci[i], plotuci[i]),
        col =  adjustcolor(elevcols[i], alpha.f = transp1), border = NA)
polygon(x = c(elevzones[i]-(colwd/2), elevzones[i]+(colwd/2),elevzones[i]+(colwd/2), elevzones[i]-(colwd/2)), 
	y = c(plotliq[i], plotliq[i], plotuiq[i], plotuiq[i]),
        col =  adjustcolor(elevcols[i], alpha.f = transp2), border = NA)
polygon(x = c(elevzones[i]-(colwd/2), elevzones[i]+(colwd/2),elevzones[i]+(colwd/2), elevzones[i]-(colwd/2)), 
	y = c(plotmedians[i]-(medwd/2), plotmedians[i]-(medwd/2), plotmedians[i]+(medwd/2), plotmedians[i]+(medwd/2)),
        col =  elevcols[i], border = NA)
points(plotsp.info5$elevjit[which(plotsp.info5$elevzone == i)], plotsp.info5$points[which(plotsp.info5$elevzone == i)], 
	cex = (plotsp.info5$plotsp.n[which(plotsp.info5$elevzone == i)]*0.03)^(1/4), col =  adjustcolor(plotsp.info5$elevcol[which(plotsp.info5$elevzone == i)], alpha.f = 0.8))
}

# Panel 2: Predictive comparisons specific to PC2
set.seed(314)
pc2zones = c(-0.753, 0, 0.58)
pc2cols = c("red", "blue", "blue")
pc2jit = jitter(plot.info3$pc2, amount = 0.01)
pc2jit2 = data.frame(pc2jit, plot = plot.info3$plot)
plotsp.info5 = merge(plotsp.info2, pc2jit2, by = "plot", all.x = T)
plotsp.info5 = merge(plotsp.info5, plot.info3[,c("plot", "pc2")], by = "plot", all.x = T)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]
plotsp.info5$points = realcndd.plotspAPC
plotsp.info5$pc2zone = c(1)
plotsp.info5$pc2zone[which(plotsp.info5$pc2 >= -0.25 & plotsp.info5$pc2 < 0.25)] = 2
plotsp.info5$pc2zone[which(plotsp.info5$pc2 >= 0.25)] = 3
plotsp.info5$pc2col = c("red")
plotsp.info5$pc2col[which(plotsp.info5$pc2 >= -0.25 & plotsp.info5$pc2 < 0.25)] = "blue"
plotsp.info5$pc2col[which(plotsp.info5$pc2 >= 0.25)] = "blue"
plot(plotsp.info5$pc2jit, realcndd.plotspAPC, las = 1, ylab = "", cex.lab = 1.2, cex.axis = 1.2, 
	main = "5-15 cm DBH", type = "n", xlab = "PC2")
mtext("Change in survival from CNDD", side = 2, line = 4, cex = 1.2)
abline(h=0,lty=2)

plotmedians = apply(realcndd.pc2, 2, median)
plotlci = apply(realcndd.pc2, 2, quantile, 0.025)
plotuci = apply(realcndd.pc2, 2, quantile, 0.975)
plotliq = apply(realcndd.pc2, 2, quantile, 0.25)
plotuiq = apply(realcndd.pc2, 2, quantile, 0.75)

for(i in 1:3) {
colwd = 0.4
medwd = 0.0015
transp1 = 0.15
transp2 = 0.3
polygon(x = c(pc2zones[i]-(colwd/2), pc2zones[i]+(colwd/2),pc2zones[i]+(colwd/2), pc2zones[i]-(colwd/2)), 
	y = c(plotlci[i], plotlci[i], plotuci[i], plotuci[i]),
        col =  adjustcolor(pc2cols[i], alpha.f = transp1), border = NA)
polygon(x = c(pc2zones[i]-(colwd/2), pc2zones[i]+(colwd/2),pc2zones[i]+(colwd/2), pc2zones[i]-(colwd/2)), 
	y = c(plotliq[i], plotliq[i], plotuiq[i], plotuiq[i]),
        col =  adjustcolor(pc2cols[i], alpha.f = transp2), border = NA)
polygon(x = c(pc2zones[i]-(colwd/2), pc2zones[i]+(colwd/2),pc2zones[i]+(colwd/2), pc2zones[i]-(colwd/2)), 
	y = c(plotmedians[i]-(medwd/2), plotmedians[i]-(medwd/2), plotmedians[i]+(medwd/2), plotmedians[i]+(medwd/2)),
        col =  pc2cols[i], border = NA)
points(plotsp.info5$pc2jit[which(plotsp.info5$pc2zone == i)], plotsp.info5$points[which(plotsp.info5$pc2zone == i)], 
	cex = (plotsp.info5$plotsp.n[which(plotsp.info5$pc2zone == i)]*0.03)^(1/4), col =  adjustcolor(plotsp.info5$pc2col[which(plotsp.info5$pc2zone == i)], alpha.f = 0.8))
}

# dev.off()








##########################################################################################
# Plot seperate CDD & HDD predictive comparisons (Seperate conspecific or heterospecific effects)

realcdd.plotspAPC = apply(realcdd.plotsp,2,mean)
realhdd.plotspAPC = apply(realhdd.plotsp,2,mean)

# pdf("HJA_5-15cmDBH_Survival_Hazard_CDD_BAYES_Elev-PC2_byPlot_20220129.pdf", height = 10, width = 5, useDingbats=FALSE)
par(pty="s")
par(mfrow=c(2,1))
set.seed(314)
elevjit = jitter(plot.info3$ELEVATION, amount = 15)
elevjit2 = data.frame(elevjit, plot = plot.info3$plot)
plotsp.info5 = merge(plotsp.info2, elevjit2, by = "plot", all.x = T, sort = F)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]
plotsp.info5$points = realcdd.plotspAPC
sp.info2 = data.frame(sp.info[order(sp.info$sp),])
load("HJA_CNDD_Analyses_Species_Colors_for_figures.RData")
sp.info2 = merge(sp.info2, sp.col[,c("sp.name", "sp.col", "sp.pch")], by = "sp.name", all.x = T)
sp.col2 = data.frame(sp = sp.col$sp.name, sp.col = sp.col$sp.col, sp.pch = sp.col$sp.pch)
plotsp.info5 = merge(plotsp.info5, sp.info2, by = "sp", all.x = T, sort = F)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]

# Plot CDD-HDD estiamtes across plots and species (posterior means)
plot(plotsp.info5$elevjit, realcdd.plotspAPC, 
	xlab = "Elevation (m)", ylab = "", cex.lab = 1.2, 
	pch=19, las=1, main = "5-15 cm DBH", type = "n", cex.axis = 1.2)
mtext("Change in survival from CDD", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
set.seed(314)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info5[which(plotsp.info5$sp == sp.info2$sp[i]),]
points(plot.subset$elevjit, plot.subset$points, cex = (plot.subset$plotsp.n*0.03)^(1/4), 
	col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)
	}

set.seed(314)
elevjit = jitter(plot.info3$ELEVATION, amount = 15)
elevjit2 = data.frame(elevjit, plot = plot.info3$plot)
plotsp.info5 = merge(plotsp.info2, elevjit2, by = "plot", all.x = T, sort = F)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]
plotsp.info5$points = realhdd.plotspAPC
sp.info2 = data.frame(sp.info[order(sp.info$sp),])
load("HJA_CNDD_Analyses_Species_Colors_for_figures.RData")
sp.info2 = merge(sp.info2, sp.col[,c("sp.name", "sp.col", "sp.pch")], by = "sp.name", all.x = T)
sp.col2 = data.frame(sp = sp.col$sp.name, sp.col = sp.col$sp.col, sp.pch = sp.col$sp.pch)
plotsp.info5 = merge(plotsp.info5, sp.info2, by = "sp", all.x = T, sort = F)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]

# Plot CDD-HDD estiamtes across plots and species (posterior means)
plot(plotsp.info5$elevjit, realhdd.plotspAPC, 
	xlab = "Elevation (m)", ylab = "", cex.lab = 1.2, 
	pch=19, las=1, main = "5-15 cm DBH", type = "n", cex.axis = 1.2)
mtext("Change in survival from HDD", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
set.seed(314)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info5[which(plotsp.info5$sp == sp.info2$sp[i]),]
points(plot.subset$elevjit, plot.subset$points, cex = (plot.subset$plotsp.n*0.03)^(1/4), 
	col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)
	}

# dev.off()










#############################################
# Plot mean annual survival predictions 

meanphi.plotspAPC = apply(meanphi.plotsp,2,mean)


# pdf("HJA_5-15cmDBH_Survival_Hazard_MeanPhi_BAYES_Elev_byPlot_20220129.pdf", height = 10, width = 5, useDingbats=FALSE)
par(pty="s")
par(mfrow=c(2,1))
set.seed(314)
elevjit = jitter(plot.info3$ELEVATION, amount = 15)
elevjit2 = data.frame(elevjit, plot = plot.info3$plot)
plotsp.info5 = merge(plotsp.info2, elevjit2, by = "plot", all.x = T, sort = F)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]
plotsp.info5$points = meanphi.plotspAPC
sp.info2 = data.frame(sp.info[order(sp.info$sp),])
load("HJA_CNDD_Analyses_Species_Colors_for_figures.RData")
sp.info2 = merge(sp.info2, sp.col[,c("sp.name", "sp.col", "sp.pch")], by = "sp.name", all.x = T)
sp.col2 = data.frame(sp = sp.col$sp.name, sp.col = sp.col$sp.col, sp.pch = sp.col$sp.pch)
plotsp.info5 = merge(plotsp.info5, sp.info2, by = "sp", all.x = T, sort = F)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]

plot(plotsp.info5$elevjit, meanphi.plotspAPC, 
	xlab = "Elevation", ylab = "", cex.lab = 1.2,
	pch=19, las=1, main = "5-15 cm DBH", type = "n", cex.axis = 1.2)
mtext("Annual survival probability", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
set.seed(314)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info5[which(plotsp.info5$sp == sp.info2$sp[i]),]
points(plot.subset$elevjit, plot.subset$points, cex = (plot.subset$plotsp.n*0.02)^(1/4), 
	col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)
	}

# dev.off()












###################################################################
# Species abundance and CNDD tests


plotsp.info5 = plotsp.info2[order(plotsp.info2$plotsp),]
plotsp.info5$points = realcndd.plotspAPC
sp.info2 = data.frame(sp.info[order(sp.info$sp),])
load("HJA_CNDD_Analyses_Species_Colors_for_figures.RData")
sp.info2 = merge(sp.info2, sp.col[,c("sp.name", "sp.col", "sp.pch")], by = "sp.name", all.x = T)
sp.col2 = data.frame(sp = sp.col$sp.name, sp.col = sp.col$sp.col, sp.pch = sp.col$sp.pch)
plotsp.info5 = merge(plotsp.info5, sp.info2, by = "sp", all.x = T, sort = F)
plotsp.info5 = plotsp.info5[order(plotsp.info5$plotsp),]


# pdf("HJA_5-15cmDBH_Survival_Hazard_CDD-HDD_wSpAbund_BAYES_20220129.pdf", height = 5, width = 5, useDingbats=FALSE)
par(pty="s")
set.seed(314)

# Plot CDD-HDD estiamtes across plots and species (posterior means)
plot(log(plotsp.info5$ba.ha), realcndd.plotspAPC, 
	xlab = "log(BA per ha)", ylab = "", cex.lab = 1.2,
	pch=19, las=1, main = "5-15 cm DBH", type = "n", cex.axis = 1.2)
mtext("Change in growth from CNDD", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
set.seed(314)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info5[which(plotsp.info5$sp == sp.info2$sp[i]),]
points(log(plot.subset$ba.ha), plot.subset$points, cex = (plot.subset$plotsp.n*0.02)^(1/4), 
	col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)
	}

# dev.off()







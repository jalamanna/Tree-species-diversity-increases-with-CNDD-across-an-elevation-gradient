### Program to read HJA Reference Stand data and make ready for analysis for LaManna et al. 2022 Ecology Letters
### Data accessed: 12-23-2017

library(vegan)
library(doBy)
library(reshape)
library(spatstat)
library(lme4)
library(reshape)
library(doBy)
library(boot)
library(abind)
library(nloptr)
library(parallel)
library(MASS)
library(stats)


############################################################################################
### Read in data files (accessed as CSVs with TV010 in file name)
### Original CSV data files not included in this ZIP package b/c while they are publicly available, they need to be individually requested from the HJA website and contain additional reference stands outside the HJA that were not part of this analysis.
### All relevant data for this anlaysis is included in 'HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData' and other .RData files included in this ZIP package.
### The code below shows how the original data files were merged, checked, and prepared for analyses for reference. 

stands = read.csv("TV01006_v3_Stand_characteristics_sampling_units_20171223.csv", header = T)			# Data file from HJA (file not included b/c needs to be requested from HJA website and contain additional reference stands outside the HJA that were not part of this analysis, all relevant data for this anlaysis included in 'HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData' and other .RData files included in this ZIP package)
plots = read.csv("TV01005_v1_Plot_description_establishment_year_20171223.csv", header = T)			# Data file from HJA (file not included b/c needs to be requested from HJA website and contain additional reference stands outside the HJA that were not part of this analysis, all relevant data for this anlaysis included in 'HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData' and other .RData files included in this ZIP package)
data = read.csv("TV01001_v2_tree_initial_conditions_20171223.csv", header = T)					# Data file from HJA (file not included b/c needs to be requested from HJA website and contain additional reference stands outside the HJA that were not part of this analysis, all relevant data for this anlaysis included in 'HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData' and other .RData files included in this ZIP package)
locs = read.csv("HJA_tree_x-y_for_Joe_Oct2018_JAL_Species_Codes_Number_Update_20181005.csv", header = T)	# Data file from HJA (file not included b/c needs to be requested from HJA website and contain additional reference stands outside the HJA that were not part of this analysis, all relevant data for this anlaysis included in 'HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData' and other .RData files included in this ZIP package)
names(locs)[c(2:5,7,12:13)] = c("STANDID", "PLOTNUMBER", "TAG", "SPECIES", "DBH", "XCOORD", "YCOORD")
measurements = read.csv("TV01002_v5_Individual_tree_remeasurement_20171223.csv", header = T)			# Data file from HJA (file not included b/c needs to be requested from HJA website and contain additional reference stands outside the HJA that were not part of this analysis, all relevant data for this anlaysis included in 'HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData' and other .RData files included in this ZIP package)
mort = read.csv("TV01003_v5_Individual_tree_mortality_20171223.csv", header = T)					# Data file from HJA (file not included b/c needs to be requested from HJA website and contain additional reference stands outside the HJA that were not part of this analysis, all relevant data for this anlaysis included in 'HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData' and other .RData files included in this ZIP package)

# Use only reference stands in HJA that are classified as old-growth
refplots = stands$STANDID[which(stands$LOC_NAME == "H.J. ANDRWS EF" & stands$SERAL == "Old-growth")]

plotsize = data.frame(STANDID = c("RS10","RS01","RS08","RS15","RS16","RS21","RS22","RS04","RS23","RS12",
	"RS07","RS14","RS30","RS29","RS03","RS31","RS27","RS26","RS34","RS20","RS28","RS06",
	"RS05","RS09","RS02","RS11","RS13","RS38","RS32","RS18"), 
	size = c(0.25, 1, 0.25, 0.25, 0.25, 1, 1, 0.25, 1, 0.25, 0.25, 0.25, 1, 1, 1, 1, 0.96, 1, 2, 1, 1, 0.25, 0.25, 0.08, 1, 0.25, 4.69, 2.4375, 0.25, 0.25))

# Use only focal reference stands (see above)
stands2 = stands[which(stands$STANDID %in% refplots == T),]
size = data.frame(STANDID = stands2$STANDID, area_ha = stands2$AREA_HA)
size = size[which(size$STANDID %in% refplots == T),]

data2 = data[which(data$STANDID %in% refplots == T),]
locs2 = locs[which(locs$STANDID %in% refplots == T),]
plots2 = plots[which(plots$STAND %in% refplots == T),]
measure2 = measurements[which(measurements$STANDID %in% refplots == T),]
mort2 = mort[which(mort$STANDID %in% refplots == T),]
data2$TAG <- as.factor(as.character(data2$TAG))
locs2$TAG <- as.factor(as.character(locs2$TAG))
measure2$TAG <- as.factor(as.character(measure2$TAG))
mort2$TAG <- as.factor(as.character(mort2$TAG))
data2$STANDID <- as.factor(as.character(data2$STANDID))
locs2$STANDID <- as.factor(as.character(locs2$STANDID))
measure2$STANDID <- as.factor(as.character(measure2$STANDID))
mort2$STANDID <- as.factor(as.character(mort2$STANDID))
measure2 = merge(measure2, size, by = "STANDID", all = T)
plots3 = plots2[,c("STAND", "PLOT", "AREA", "MIN_DBH")]
names(plots3)[c(1:2)] = c("STANDID", "PLOTNUMBER")
measure3 = merge(measure2, plots3, by = c("STANDID", "PLOTNUMBER"), all.x = T)
measure2 = measure3

data2$TREEID = as.character(data2$TREEID)
measure2$TREEID = as.character(measure2$TREEID)
treeID = rbind(data.frame(data2[,c("TREEID", "STANDID", "PLOTNUMBER", "TAG", "SPECIES")], source = c("d")), data.frame(measure2[,c("TREEID", "STANDID", "PLOTNUMBER", "TAG", "SPECIES")], source = c("m")))
treeID$uniqueID = paste(treeID$STANDID, treeID$PLOTNUMBER, treeID$TAG, sep = "-")
treeID = treeID[which(duplicated(treeID[,c("TREEID", "STANDID", "PLOTNUMBER", "TAG", "SPECIES")]) == F),]
treeID = treeID[order(treeID$TREEID),]
dups = c(which(duplicated(treeID$TREEID) == T), which(duplicated(treeID$TREEID) == T) - 1)
dups = dups[order(dups)]
locs2$uniqueID = paste(locs2$STANDID, locs2$PLOTNUMBER, locs2$TAG, sep = "-")
measure2$uniqueID = paste(measure2$STANDID, measure2$PLOTNUMBER, measure2$TAG, sep = "-")
mort2$uniqueID = paste(mort2$STANDID, mort2$PLOTNUMBER, mort2$TAG, sep = "-")

locs2$TAG = as.character(locs2$TAG)
locs2$TAG[which(locs2$uniqueID == "RS28-4-9051")] = "9501"		# Corrected tag number to match other entries from this tree
locs2$TAG = as.factor(locs2$TAG)
locs2$uniqueID = paste(locs2$STANDID, locs2$PLOTNUMBER, locs2$TAG, sep = "-")


locs3 = rbind(locs2[c("STANDID", "PLOTNUMBER", "TAG", "XCOORD", "YCOORD", "SPECIES", "DBH", "LiveDead")], 
	data.frame(data2[c("STANDID", "PLOTNUMBER", "TAG", "XCOORD", "YCOORD", "SPECIES")], DBH = NA, LiveDead = NA))
names(locs3)[which(colnames(locs3) == "DBH")] = "DBH_loc"
names(locs3)[which(colnames(locs3) == "SPECIES")] = "SPECIES_loc"
locs4 = locs3[which(duplicated(locs3[c("STANDID", "PLOTNUMBER", "TAG")]) == F),]

measure3 = merge(measure2, locs4, by = c("STANDID", "PLOTNUMBER", "TAG"), all.x = T)
measure3 = measure3[order(measure3$STANDID, measure3$PLOTNUMBER, measure3$TAG, measure3$YEAR),]
measure3$uniqueID = paste(measure3$STANDID, measure3$PLOTNUMBER, measure3$TAG, sep = "-")

measure3$SPECIES = as.character(measure3$SPECIES)
measure3$SPECIES_loc = as.character(measure3$SPECIES_loc)
measure3$SPECIES[which(measure3$SPECIES != measure3$SPECIES_loc)] = measure3$SPECIES_loc[which(measure3$SPECIES != measure3$SPECIES_loc)]
sp.list = unique(measure3$SPECIES)[order(unique(measure3$SPECIES))]

length(unique(measure3$uniqueID))
length(unique(measure3$TREEID))

###################################################################################
### Split data by reference stand and census, quality checks on data

plot.ID.function = function(test) {
if((max(test$XCOORD) %% 25) < 10) {
	xmax = ((max(test$XCOORD) %/% 25)) * 25
} else {
	xmax = ((max(test$XCOORD) %/% 25) + 1) * 25
}
if((max(test$YCOORD) %% 25) < 10) {
	ymax = ((max(test$YCOORD) %/% 25)) * 25
} else {
	ymax = ((max(test$YCOORD) %/% 25) + 1) * 25
}
xbreaks = c(-5, seq(25, xmax - 25, by = 25), xmax + 10)
ybreaks = c(-5, seq(25, ymax - 25, by = 25), ymax + 10)
xvecm = as.numeric(cut(test$XCOORD, breaks = xbreaks))
yvecm = as.numeric(cut(test$YCOORD, breaks = ybreaks))
xvecm = sprintf("%02d",xvecm)
yvecm = sprintf("%02d",yvecm)
test$quad = as.character(paste(xvecm, yvecm, sep = ""))
return(test)
}

# NB: For RS01, RS02, RS03, censuses 2 & 3 were combined (surveyed different quadrats of the plot), and census 1 was removed for diversity metrics (survey of only a portion of the plot)
# NB: For RS27, quads were 20x20 instead of 25x25, so trees with GX > 100 or GY > 75 were removed and quads reassessed at 25x25 to make it consistent with other stands
# NB: Some trees were listed as within certain quads ("PLOT") in the data, but their mapped coordinates place them in another quad, thus this somtimes places them within a different MIN_DBH category. This was checked and corrected with the MIN_DBH files above which re-classify those trees into the proper MIN_DBH status -- MIN_DBH was only used for diversity analyses and recruitment analyses
# NB: In addition, the last census includes trees < 15 cm in several quads in RS01 that had previously been only surveyed trees >15 cm, these quads were removed from the diversity analysis because they did not consistencly include small trees

measure2 = measure3[!is.na(measure3$XCOORD),]
stands3 = stands2[which(stands2$STANDID %in% refplots == T),]
stands3 = stands3[order(stands3$STANDID),]
measure6.live = measure3.live = measure2
measure6.live = measure6.live[-which(measure6.live$STANDID == "RS27" & measure6.live$XCOORD > 100),]			# Standardizing plot size (see NB above)
measure6.live = measure6.live[-which(measure6.live$STANDID == "RS27" & measure6.live$YCOORD > 75),]			# Standardizing plot size (see NB above)
measure6.live$SAMPLEDATE[which(measure6.live$YEAR == 2008 & measure6.live$SAMPLEDATE == "2006-07-01")] = "2008-07-01"	# Corrected survey date
measure6.live$YEAR[which(measure6.live$TREEID == "RS38001600021" & measure6.live$YEAR == 2014)] = 2000		# Corrected survey year
measure6.live$YEAR[which(measure6.live$TREEID == "RS34001100016" & measure6.live$YEAR == 2000)] = 2001		# Corrected survey year
stands.census.key = read.csv("HJA_RefStands_Census_4Merge.csv", header = T)							# Table with census numbers by year for each reference stand
measure3.live = merge(measure6.live, stands.census.key, by = c("STANDID", "YEAR"), all.x = T)
measure3.live$census[which(measure3.live$STANDID %in% c("RS01", "RS02", "RS03") == T & measure3.live$TREE_STATUS > 3 & measure3.live$census == 2)] = 3	# Combine census 2 & 3 for RS01, RS02, and RS03 (see NB above)
measure3.live.list = split(measure3.live, measure3.live$STANDID)
measure3.live.list1 = lapply(measure3.live.list, plot.ID.function)
measure3.live.list1[[which(refplots == "RS38")]]$quad[which(measure3.live.list1[[which(refplots == "RS38")]]$quad == "0105")] = "0104"	# Correct quadrat code for trees maarked in adjacent quadrat
measure3.live.list1[[which(refplots == "RS03")]]$quad[which(measure3.live.list1[[which(refplots == "RS03")]]$quad == "0603")] = "0602"	# Correct quadrat code for trees maarked in adjacent quadrat
measure3.live.list2 = measure3.live.list1
rs01.mindbh.table = read.csv("HJA_RefStands_Min_DBH_Tables_20200131_RS01.csv", header = T)				# Table with corrected minimum DBH status for each quadrat in RS01 (see NB above)
rs01.mindbh.table$quad = paste("0", as.character(rs01.mindbh.table$quad), sep = "")
rsothers.mindbh.table = read.csv("HJA_RefStands_Min_DBH_Tables_20181008_other_stands.csv", header = T)
rsothers.mindbh.table$quad = paste("0", as.character(rsothers.mindbh.table$quad), sep = "")				# Table with corrected minimum DBH status for each quadrat in other reference stands besides RS01 (see NB above)
measure3.live.backtodf = do.call('rbind', measure3.live.list2)
measure3.live.backtodf.rs01 = measure3.live.backtodf[which(measure3.live.backtodf$STANDID == "RS01"),]
measure3.live.backtodf.rsothers = measure3.live.backtodf[-which(measure3.live.backtodf$STANDID == "RS01"),]
measure3.live.backtodf.rs01.2 = merge(measure3.live.backtodf.rs01, rs01.mindbh.table, by = c("STANDID", "quad", "YEAR"), all.x = T)
measure3.live.backtodf.rsothers.2 = merge(measure3.live.backtodf.rsothers, rsothers.mindbh.table, by = c("STANDID", "quad"), all.x = T)
measure3.live.backtodf2 = rbind(measure3.live.backtodf.rs01.2, measure3.live.backtodf.rsothers.2)
measure3.live.backtodf2 = measure3.live.backtodf2[,-which(colnames(measure3.live.backtodf2) == "MIN_DBH")]
names(measure3.live.backtodf2)[which(colnames(measure3.live.backtodf2) == "MIN_DBH_CHECKED")] = "MIN_DBH"
measure3.live.backtodf2 = measure3.live.backtodf2[order(measure3.live.backtodf2$STANDID),]
measure3.live.backtodf3 = measure3.live.backtodf2[which(measure3.live.backtodf2$TREE_STATUS <= 3),]
measure3.live.backtodf3 = measure3.live.backtodf3[-which(measure3.live.backtodf3$census == 1 & measure3.live.backtodf3$STANDID %in% c("RS01", "RS02", "RS03") == T),]
measure3.live.backtodf4 = measure3.live.backtodf2
measure3.live.list2 = split(measure3.live.backtodf3, measure3.live.backtodf3$STANDID)
measure3.live.list3 = lapply(measure3.live.list2, function(x) {split(x, x$census)})
measure3.live.list4 = split(measure3.live.backtodf4, measure3.live.backtodf4$STANDID)
measure3.live.list5 = lapply(measure3.live.list4, function(x) {split(x, x$census)})



# Save data for species richness analyses
div.data = measure3.live.list3
standclimate = stands3[,c("STANDID", "ELEVATION", "LATITUDE", "LONGITUDE")]
# save(div.data, standclimate, file = "HJA_LaManna_RefStand_Species_Richness_Data.RData")


# Save data for survival/growth analyses
hja.survival.growth.data = measure3.live.list5
# save(hja.survival.growth.data, sp.list, standclimate, file = "HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData")













### Figures across DBH classes for HJA-CNDD study


ests1 = list()
ests2 = list()
gests1 = list()
gests2 = list()
dbh = list()
dbh[[1]] = 5
dbh[[2]] = 7
dbh[[3]] = 10
dbh[[4]] = 15
dbh[[5]] = 20
dbh[[6]] = 25
dbh[[7]] = 35
dbh[[8]] = 55
dbh[[9]] = 100
dbh[[10]] = 200

load("HJA_CNDDELEV_5cmDBH_20210524.RData")
ests1[[1]] = cndd.m2ests
ests2[[1]] = cnddelev.m2ests
load("HJA_CNDDELEV_7cmDBH_20210524.RData")
ests1[[2]] = cndd.m2ests
ests2[[2]] = cnddelev.m2ests
load("HJA_CNDDELEV_10cmDBH_20210524.RData")
ests1[[3]] = cndd.m2ests
ests2[[3]] = cnddelev.m2ests
load("HJA_CNDDELEV_15cmDBH_20210524.RData")
ests1[[4]] = cndd.m2ests
ests2[[4]] = cnddelev.m2ests
load("HJA_CNDDELEV_20cmDBH_20210524.RData")
ests1[[5]] = cndd.m2ests
ests2[[5]] = cnddelev.m2ests
load("HJA_CNDDELEV_25cmDBH_20210524.RData")
ests1[[6]] = cndd.m2ests
ests2[[6]] = cnddelev.m2ests
load("HJA_CNDDELEV_35cmDBH_20210524.RData")
ests1[[7]] = cndd.m2ests
ests2[[7]] = cnddelev.m2ests
load("HJA_CNDDELEV_55cmDBH_20210524.RData")
ests1[[8]] = cndd.m2ests
ests2[[8]] = cnddelev.m2ests
load("HJA_CNDDELEV_100cmDBH_20210524.RData")
ests1[[9]] = cndd.m2ests
ests2[[9]] = cnddelev.m2ests
load("HJA_CNDDELEV_200cmDBH_20210524.RData")
ests1[[10]] = cndd.m2ests
ests2[[10]] = cnddelev.m2ests

load("HJA_CNDDELEV_Growth_5cmDBH_20210524.RData")
gests1[[1]] = cndd.m2ests
gests2[[1]] = cnddelev.m2ests
load("HJA_CNDDELEV_Growth_7cmDBH_20210524.RData")
gests1[[2]] = cndd.m2ests
gests2[[2]] = cnddelev.m2ests
load("HJA_CNDDELEV_Growth_10cmDBH_20210524.RData")
gests1[[3]] = cndd.m2ests
gests2[[3]] = cnddelev.m2ests
load("HJA_CNDDELEV_Growth_15cmDBH_20210524.RData")
gests1[[4]] = cndd.m2ests
gests2[[4]] = cnddelev.m2ests
load("HJA_CNDDELEV_Growth_20cmDBH_20210524.RData")
gests1[[5]] = cndd.m2ests
gests2[[5]] = cnddelev.m2ests
load("HJA_CNDDELEV_Growth_25cmDBH_20210524.RData")
gests1[[6]] = cndd.m2ests
gests2[[6]] = cnddelev.m2ests
load("HJA_CNDDELEV_Growth_35cmDBH_20210524.RData")
gests1[[7]] = cndd.m2ests
gests2[[7]] = cnddelev.m2ests
load("HJA_CNDDELEV_Growth_55cmDBH_20210524.RData")
gests1[[8]] = cndd.m2ests
gests2[[8]] = cnddelev.m2ests
load("HJA_CNDDELEV_Growth_100cmDBH_20210524.RData")
gests1[[9]] = cndd.m2ests
gests2[[9]] = cnddelev.m2ests
load("HJA_CNDDELEV_Growth_200cmDBH_20210524.RData")
gests1[[10]] = cndd.m2ests
gests2[[10]] = cnddelev.m2ests



elevmin = -1.45
elevmax = 1.7
upperquant = 0.84
lowerquant = 0.16


cnddLELEVupper = c()
cnddLELEVlower = c()
cnddLELEVmean = c()
cnddHELEVupper = c()
cnddHELEVlower = c()
cnddHELEVmean = c()
gcnddLELEVupper = c()
gcnddLELEVlower = c()
gcnddLELEVmean = c()
gcnddHELEVupper = c()
gcnddHELEVlower = c()
gcnddHELEVmean = c()
for(i in 1:length(ests1)) {
cnddLELEVupper[i] = quantile((ests1[[i]]+(ests2[[i]]*elevmin)),c(upperquant))
cnddLELEVlower[i] = quantile((ests1[[i]]+(ests2[[i]]*elevmin)),c(lowerquant))
cnddLELEVmean[i] = mean((ests1[[i]]+(ests2[[i]]*elevmin)))
cnddHELEVupper[i] = quantile((ests1[[i]]+(ests2[[i]]*elevmax)),c(upperquant))
cnddHELEVlower[i] = quantile((ests1[[i]]+(ests2[[i]]*elevmax)),c(lowerquant))
cnddHELEVmean[i] = mean((ests1[[i]]+(ests2[[i]]*elevmax)))
}
for(i in 1:length(gests1)) {
gcnddLELEVupper[i] = quantile((gests1[[i]]+(gests2[[i]]*elevmin)),c(upperquant))
gcnddLELEVlower[i] = quantile((gests1[[i]]+(gests2[[i]]*elevmin)),c(lowerquant))
gcnddLELEVmean[i] = mean((gests1[[i]]+(gests2[[i]]*elevmin)))
gcnddHELEVupper[i] = quantile((gests1[[i]]+(gests2[[i]]*elevmax)),c(upperquant))
gcnddHELEVlower[i] = quantile((gests1[[i]]+(gests2[[i]]*elevmax)),c(lowerquant))
gcnddHELEVmean[i] = mean((gests1[[i]]+(gests2[[i]]*elevmax)))
}







pdf("HJA_CNDD_Across_DBH_Size_Classes_BAYES_20210524.pdf", height = 8, width = 6.5, useDingbats=FALSE)
par(mfrow=c(2,1))
par(mar = c(5, 5, 4, 2) + 0.1)
spacing = 0.05
marginadjust = 0.7
plot(c(0,1), c(0,1), las = 1, ylab = "", type = "n", 
	main = "CNDD in annual survival across size classes", xlim=c(1,10), ylim=c(-0.092,0.022), xlab = "Tree size class (cm DBH)", xaxt = "n")
mtext(side = 2, line = 3.5, "Change in annual survival from CNDD")
abline(h=0,lty=2)
lines((1:length(cnddLELEVmean))-spacing, cnddLELEVmean, col = "red", lwd = 1.5)
lines((1:length(cnddHELEVmean))+spacing, cnddHELEVmean, col = "blue", lwd = 1.5)
for(i in 1:10) {
segments(i-spacing ,cnddLELEVupper[i],i-spacing , cnddLELEVlower[i], col = "red", lwd = 1.5)
segments(i+spacing ,cnddHELEVupper[i],i+spacing , cnddHELEVlower[i], col = "blue", lwd = 1.5)
}
for(i in c(1:3)) {points(i-spacing , cnddLELEVmean[i], pch = 19, cex = 2, col = "red")}
for(i in c(4:5)) {
	points(i-spacing , cnddLELEVmean[i], pch = 19, cex = 2, col = "red", lwd = 3)
	points(i-spacing , cnddLELEVmean[i], pch = 16, cex = 1.4, col = adjustcolor("white", alpha.f = marginadjust), lwd = 3)
}
for(i in c(6:10)) {points(i-spacing , cnddLELEVmean[i], pch = 21, bg = "white", cex = 2, col = "red", lwd = 3)}
# for(i in c(0)) {points(i+spacing , cnddHELEVmean[i], pch = 19, cex = 2, col = "blue")}
for(i in c(1:10)) {points(i+spacing , cnddHELEVmean[i], pch = 21, bg = "white", cex = 2, col = "blue", lwd = 3)}
axis(side=1, at = 1:length(cnddLELEVmean), labels = unlist(dbh)[1:length(cnddLELEVmean)])
text(c(1,2),rep(0.018,times=2), "*", cex=2)
text(c(3),rep(0.018,times=1), "�", cex=1)
legend("bottomright", legend = c("Low elev.", "High elev."), pch = 19, col = c("red", "blue"), bty = "n", lwd=1.5)

plot(c(0,1), c(0,1), las = 1, ylab = "", type = "n", 
	main = "CNDD in annual growth across size classes", xlim=c(1,10), ylim=c(-0.13,0.09), xlab = "Tree size class (cm DBH)", xaxt = "n")
mtext(side = 2, line = 3.5, "Change in annual growth from CNDD")
abline(h=0,lty=2)
lines((1:length(gcnddLELEVmean))-spacing, gcnddLELEVmean, col = "red", lwd = 1.5)
lines((1:length(gcnddHELEVmean))+spacing, gcnddHELEVmean, col = "blue", lwd = 1.5)
for(i in 1:10) {
segments(i-spacing ,gcnddLELEVupper[i],i-spacing , gcnddLELEVlower[i], col = "red", lwd = 1.5)
segments(i+spacing ,gcnddHELEVupper[i],i+spacing , gcnddHELEVlower[i], col = "blue", lwd = 1.5)
}
for(i in c(4,5,6)) {points(i-spacing , gcnddLELEVmean[i], pch = 19, cex = 2, col = "red")}
for(i in c(1,2,3,7,8,9,10)) {points(i-spacing , gcnddLELEVmean[i], pch = 21, bg = "white", cex = 2, col = "red", lwd = 3)}
for(i in c(1)) {points(i+spacing , gcnddHELEVmean[i], pch = 19, cex = 2, col = "blue")}
for(i in c(2)) {
	points(i+spacing , gcnddHELEVmean[i], pch = 19, cex = 2, col = "blue", lwd = 3)
	points(i+spacing , gcnddHELEVmean[i], pch = 16, cex = 1.4, col = adjustcolor("white", alpha.f = marginadjust), lwd = 3)
}
for(i in c(3:10)) {points(i+spacing , gcnddHELEVmean[i], pch = 21, bg = "white", cex = 2, col = "blue", lwd = 3)}
axis(side=1, at = 1:length(gcnddLELEVmean), labels = unlist(dbh)[1:length(gcnddLELEVmean)])
text(c(4,5),rep(0.08,times=2), "*", cex=2)
legend("bottomleft", legend = c("Low elev.", "High elev."), pch = 19, col = c("red", "blue"), bty = "n", lwd=1.5)

dev.off()


for(i in 1:10) {
estsL = (ests1[[i]]+(ests2[[i]]*elevmin))
estsH = (ests1[[i]]+(ests2[[i]]*elevmax))
print(sum((estsL - estsH) > 0) / length(estsL))
}

for(i in 1:10) {
estsL = (ests1[[i]]+(ests2[[i]]*elevmin))
print(sum(estsL > 0) / length(estsL))
}

for(i in 1:10) {
estsH = (ests1[[i]]+(ests2[[i]]*elevmax))
print(sum(estsH > 0) / length(estsH))
}


for(i in 1:10) {
estsL = (gests1[[i]]+(gests2[[i]]*elevmin))
estsH = (gests1[[i]]+(gests2[[i]]*elevmax))
print(sum((estsL - estsH) > 0) / length(estsL))
}

for(i in 1:10) {
estsL = (gests1[[i]]+(gests2[[i]]*elevmin))
print(sum((estsL) > 0) / length(estsL))
}

for(i in 1:10) {
estsH = (gests1[[i]]+(gests2[[i]]*elevmax))
print(sum((estsH) > 0) / length(estsH))
}








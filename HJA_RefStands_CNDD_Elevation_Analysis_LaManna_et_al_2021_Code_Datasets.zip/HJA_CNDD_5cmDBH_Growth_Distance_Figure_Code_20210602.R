### Figures across DBH classes for HJA-CNDD study



rings = c(0.000000,  3.779645,  5.345225,  6.546537,  7.559289,  8.451543,  9.258201, 10.000000)
rings2 = ((rings[2:length(rings)] - rings[1:length(rings)-1]) / 2) + rings[1:length(rings)-1]
estsL = list()
estsM = list()
estsH = list()
dbh = list()
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_Low_Elev_Annuli_1_20210603.RData")
estsL[[1]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_Mid_Elev_Annuli_1_20210603.RData")
estsM[[1]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_High_Elev_Annuli_1_20210603.RData")
estsH[[1]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_Low_Elev_Annuli_2_20210603.RData")
estsL[[2]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_Mid_Elev_Annuli_2_20210603.RData")
estsM[[2]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_High_Elev_Annuli_2_20210603.RData")
estsH[[2]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_Low_Elev_Annuli_3_20210603.RData")
estsL[[3]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_Mid_Elev_Annuli_3_20210603.RData")
estsM[[3]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_High_Elev_Annuli_3_20210603.RData")
estsH[[3]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_Low_Elev_Annuli_4_20210603.RData")
estsL[[4]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_Mid_Elev_Annuli_4_20210603.RData")
estsM[[4]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_High_Elev_Annuli_4_20210603.RData")
estsH[[4]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_Low_Elev_Annuli_5_20210603.RData")
estsL[[5]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_Mid_Elev_Annuli_5_20210603.RData")
estsM[[5]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_High_Elev_Annuli_5_20210603.RData")
estsH[[5]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_Low_Elev_Annuli_6_20210603.RData")
estsL[[6]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_Mid_Elev_Annuli_6_20210603.RData")
estsM[[6]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_High_Elev_Annuli_6_20210603.RData")
estsH[[6]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_Low_Elev_Annuli_7_20210603.RData")
estsL[[7]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_Mid_Elev_Annuli_7_20210603.RData")
estsM[[7]] = cnddmean
load("HJA_5cmDBH_Growth_Bayesian_EAA_CNDDMEAN_High_Elev_Annuli_7_20210603.RData")
estsH[[7]] = cnddmean



upperquant = 0.84
lowerquant = 0.16


cnddLELEVupper = c()
cnddLELEVlower = c()
cnddLELEVmean = c()
cnddMELEVupper = c()
cnddMELEVlower = c()
cnddMELEVmean = c()
cnddHELEVupper = c()
cnddHELEVlower = c()
cnddHELEVmean = c()
for(i in 1:length(estsL)) {
cnddLELEVupper[i] = quantile(estsL[[i]],c(upperquant))
cnddLELEVlower[i] = quantile(estsL[[i]],c(lowerquant))
cnddLELEVmean[i] = mean(estsL[[i]])
cnddMELEVupper[i] = quantile(estsM[[i]],c(upperquant))
cnddMELEVlower[i] = quantile(estsM[[i]],c(lowerquant))
cnddMELEVmean[i] = mean(estsM[[i]])
cnddHELEVupper[i] = quantile(estsH[[i]],c(upperquant))
cnddHELEVlower[i] = quantile(estsH[[i]],c(lowerquant))
cnddHELEVmean[i] = mean(estsH[[i]])
}




spacing = 0.1
marginadjust = 0.7

pdf("HJA_5cmDBH_CNDD_Growth_Across_Distance_BAYES_20210602.pdf", height = 5, width = 6.5, useDingbats=FALSE)
par(mar = c(5, 5, 4, 2) + 0.1)
plot(c(0,1), c(0,1), las = 1, ylab = "", type = "n", xaxs="i", 
	main = "CNDD in growth across distances from focal tree", xlim=c(0,10), ylim=c(-0.12,0.06), xlab = "Distance from focal tree (m)")
mtext(side = 2, line = 3.5, "Change in annual growth from CNDD")
abline(h=0,lty=2)
lines(rings2-spacing, cnddLELEVmean, col = "red", lwd = 1.5)
lines(rings2, cnddMELEVmean, col = "purple", lwd = 1.5)
lines(rings2+spacing, cnddHELEVmean, col = "blue", lwd = 1.5)
for(i in 1:length(rings2)) {
segments(rings2[i]-spacing ,cnddLELEVupper[i],rings2[i]-spacing , cnddLELEVlower[i], col = "red", lwd = 1.5)
segments(rings2[i],cnddMELEVupper[i],rings2[i],cnddMELEVlower[i], col = "purple", lwd = 1.5)
segments(rings2[i]+spacing ,cnddHELEVupper[i],rings2[i]+spacing , cnddHELEVlower[i], col = "blue", lwd = 1.5)
}
for(i in c(1,2,3,4,5)) {points(rings2[i]-spacing , cnddLELEVmean[i], pch = 19, cex = 2, col = "red")}
#for(i in c()) {
#	points(rings2[i]-spacing , cnddLELEVmean[i], pch = 19, cex = 2, col = "red", lwd = 3)
#	points(rings2[i]-spacing , cnddLELEVmean[i], pch = 16, cex = 1.4, col = adjustcolor("white", alpha.f = marginadjust), lwd = 3)
#}
for(i in c(6,7)) {points(rings2[i]-spacing, cnddLELEVmean[i], pch = 21, bg = "white", cex = 2, col = "red", lwd = 3)}
#for(i in c()) {points(rings2[i], cnddMELEVmean[i], pch = 19, cex = 2, col = "purple")}
for(i in c(2)) {
	points(rings2[i], cnddMELEVmean[i], pch = 19, cex = 2, col = "purple", lwd = 3)
	points(rings2[i], cnddMELEVmean[i], pch = 16, cex = 1.4, col = adjustcolor("white", alpha.f = marginadjust), lwd = 3)
}
for(i in c(1,3,4,5,6,7)) {points(rings2[i], cnddMELEVmean[i], pch = 21, bg = "white", cex = 2, col = "purple", lwd = 3)}
for(i in c(1)) {points(rings2[i]+spacing, cnddHELEVmean[i], pch = 19, cex = 2, col = "blue")}
for(i in c(7)) {
	points(rings2[i]+spacing, cnddHELEVmean[i], pch = 19, cex = 2, col = "blue", lwd = 3)
	points(rings2[i]+spacing, cnddHELEVmean[i], pch = 16, bg = "lightblue", cex = 1.4, col = adjustcolor("white", alpha.f = marginadjust), lwd = 3)
}
for(i in c(2,3,4,5,6)) {points(rings2[i]+spacing, cnddHELEVmean[i], pch = 21, bg = "white", cex = 2, col = "blue", lwd = 3)}
text(rings2[c(1,2,5)],rep(0.06,times=2), "*", cex=2)
#text(rings2[c()],rep(0.06,times=2), "�", cex=1)
legend("bottomright", legend = c("Low elev.", "Mid elev.", "High elev."), pch = 19, col = c("red", "purple", "blue"), bty = "n", lwd=1.5)

dev.off()





set.seed(3332)
i = 7
(lowhigh = sum((estsL[[i]][sample(length(estsL[[i]]), size = min(c(length(estsL[[i]]),length(estsH[[i]]))))] - estsH[[i]][sample(length(estsH[[i]]), size = min(c(length(estsL[[i]]),length(estsH[[i]]))))]) > 0) / min(c(length(estsL[[i]]),length(estsH[[i]]))))
(lowmid = sum((estsL[[i]][sample(length(estsL[[i]]), size = min(c(length(estsL[[i]]),length(estsM[[i]]))))] - estsM[[i]][sample(length(estsM[[i]]), size = min(c(length(estsL[[i]]),length(estsM[[i]]))))]) > 0) / min(c(length(estsL[[i]]),length(estsM[[i]]))))
(midhigh = sum((estsM[[i]][sample(length(estsM[[i]]), size = min(c(length(estsM[[i]]),length(estsH[[i]]))))] - estsH[[i]][sample(length(estsH[[i]]), size = min(c(length(estsM[[i]]),length(estsH[[i]]))))]) > 0) / min(c(length(estsM[[i]]),length(estsH[[i]]))))


for(i in 1:7) {print(sum(estsL[[i]] > 0) / length(estsL[[i]]))}
for(i in 1:7) {print(sum(estsM[[i]] > 0) / length(estsM[[i]]))}
for(i in 1:7) {print(sum(estsH[[i]] > 0) / length(estsH[[i]]))}






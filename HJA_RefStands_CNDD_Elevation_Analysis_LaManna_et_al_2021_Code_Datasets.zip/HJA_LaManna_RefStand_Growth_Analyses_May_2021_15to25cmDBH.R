### Script to perform analyses of HJA reference stand data
### Data prep for survival and growth analyses
### By: J. LaManna, reference stand data accessed: 12-23-2017

# Load necessary R packages
library(vegan)
library(doBy)
library(arm)
library(reshape)
library(nlme)
library(spatstat)
library(lme4)
library(vegan)
library(boot)
library(lmtest)
library(abind)
library(optimx)
library(nloptr)
library(parallel)
library(MASS)
library(stats)
library(DescTools)
library(purrr)
library(rstan)
library(rstanarm)
# Code for multi-core
options(mc.cores = parallel::detectCores())


# Load data for diversity analyses
load("HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData")

### IN ADDITION MAKE SURE THESE RData FILES ARE IN R WORKING DIRECTORY:
# "HJA_Species_Mean_Abundances_across_Censuses_by_Plot.RData"
# "HJA_CNDD_Analyses_Species_Colors_for_figures.RData"
# "HJA_GLMM_CENSORED_Growth_Model.stan"


# Load other analysis functions
dist.weighted.abund.function = function(adultlocs = adultlocs, saplocs = saplocs, fix.rad = TRUE, rad = 10, alpha = 0, beta = 0.2) {
xdist = crossdist(adultlocs[,2], adultlocs[,3], saplocs[,2], saplocs[,3])
same.tree.row = which(adultlocs$id %in% saplocs$id == T)
same.tree.col = match(adultlocs$id, saplocs$id)[which(adultlocs$id %in% saplocs$id == T)]
xdist[as.matrix(data.frame(same.tree.row, same.tree.col))] = NA
weight.mat = matrix((adultlocs$dbh^alpha), nrow = nrow(xdist), ncol = ncol(xdist))
if(fix.rad) {
xdist2 = xdist
xdist2[which(xdist2 > rad)] = NA
xdist.weighted = weight.mat * exp((-beta) * xdist2) 
} else {
xdist.weighted = weight.mat * exp((-beta) * xdist2) 
}
xdist.weighted[is.na(xdist.weighted)] = 0
species.names = unique(adultlocs[,1])
adult.weights = data.frame(matrix(NA,nrow = nrow(saplocs), ncol = length(species.names)))
colnames(adult.weights) = species.names
rownames(adult.weights) = saplocs[,1]
if(nrow(adult.weights) == 0) {
return(adult.weights)
} else {
for(z in 1:ncol(adult.weights)) {
if(ncol(xdist.weighted) > 1) {
if(length(which(adultlocs[,1] == species.names[z])) > 1) {
adult.weights[,z] = colSums(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
} else {
adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
}
} else {
if(length(which(adultlocs[,1] == species.names[z])) > 1) {
adult.weights[,z] = sum(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
} else {
adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
}
}}
return(adult.weights)
}}



Add.missing.sp.names = function(test) {
names.toAdd = sp.list[which(sp.list %in% colnames(test) == F)]
test2 = data.frame(test, data.frame(matrix(0, nrow = nrow(test), ncol = length(names.toAdd))))
colnames(test2) = c(colnames(test), names.toAdd)
test2 = test2[,order(colnames(test2))]
return(test2)
}









################################################################################################################
### LARGE-TREE GROWTH

# Load data for diversity analyses
load("HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData")


###########################
### BEGIN DATA PREP FUNCTION -- Remember to set values for 'beta' and 'weight.method' below, elim.radius set to 10 m

fd.adult.phi = list()
fd.sap.phi = list()
fd.adult.recruit = list()
fd.sap.recruit = list()
elim.radius = 10		# does not include trees within 10 m of plot edge (neighborhood density metrics, which have radii of 10 m, will be biased low for these individuals because we don't know what adults are outside the plot)
beta = 0.2			# Beta value determines the shape of the exponential decay of neighborhood effects across each 10-m radius neighborhood; 0 = no decay, higher values = stronger decay (Comita et al. 2010, Science)
alpha = 1.0			# alpha parameter for abundance-based neighborhood metrics, DBH^alpha

sp.list

for(q in 1:length(hja.survival.growth.data)) {
test = hja.survival.growth.data[[q]]
n.census = length(test)
adult.phi.list = list()
sap.phi.list = list()

for(i in 2:n.census) {
df = test[[i]]
df$ba = (((df$DBH/100)/2)^2)*pi  		# Calculate basal area for each individual
df$julian = as.numeric(julian(as.POSIXlt(df$SAMPLEDATE, format = "%Y-%m-%d")))
adult.sp = tapply(df$DBH[which(df$DBH >= 15)], as.character(df$SPECIES[which(df$DBH >= 15)]), length)
adult.sp2 = names(adult.sp)
focal = data.frame(STANDID = df$STANDID, census = df$census, YEAR = df$YEAR, DBH = df$DBH, quad = df$quad, canopy_class = df$CANOPY_CLASS, vigor = df$TREE_VIGOR,
	uniqueID = df$uniqueID, sp = df$SPECIES, gx = df$XCOORD, gy = df$YCOORD, status = df$TREE_STATUS, dbh_code = df$DBH_CODE, julian = df$julian, min_dbh = df$MIN_DBH, notes = df$CHECK_NOTES)
focal$sp = as.character(focal$sp)

test.var = 1
if(df$census[1] == 9 & df$STANDID[1] == "RS34") {test.var = 34}
if(df$census[1] == 9 & df$STANDID[1] == "RS38") {test.var = 38}
if(test.var == 34) {focal = focal[which(focal$gx >= 10 & focal$gx <= 190 & focal$gy >= 10 & focal$gy <= 90),]}
if(test.var == 38) {focal = focal[which(focal$gx >= 10 & focal$gx <= 165 & focal$gy >= 10 & focal$gy <= 90),]}
if(test.var == 1) {
maxcol = max(as.numeric(substr(df$quad,1,2)))
maxrow = max(as.numeric(substr(df$quad,3,4)))
mincol = min(as.numeric(substr(df$quad,1,2)))
minrow = min(as.numeric(substr(df$quad,3,4)))
focal.good = focal[which(focal$quad == 9999),]
for(k in mincol:maxcol) {
df2 = df[which(as.numeric(substr(df$quad,1,2)) == k),]
ymax = max(as.numeric(substr(df2$quad,3,4))) * 25
ymin = (min(as.numeric(substr(df2$quad,3,4))) - 1) * 25
focal.good = rbind(focal.good, focal[which(as.numeric(substr(focal$quad,1,2)) == k & focal$gy >= (ymin + elim.radius) & focal$gy <= (ymax - elim.radius)),])
}
focal.good2 = focal.good[which(focal.good$quad == 9999),]
for(k in minrow:maxrow) {
df2 = df[which(as.numeric(substr(df$quad,3,4)) == k),]
xmax = max(as.numeric(substr(df2$quad,1,2))) * 25
xmin = (min(as.numeric(substr(df2$quad,1,2))) - 1) * 25
focal.good2 = rbind(focal.good2, focal.good[which(as.numeric(substr(focal.good$quad,3,4)) == k & focal.good$gx >= (xmin + elim.radius) & focal.good$gx <= (xmax - elim.radius)),])
}

focal = focal.good2
focal$sp = as.character(focal$sp)
if(nrow(focal) == 0) {print(paste("ERROR: No individuals within plot buffer!", "STAND", q, "census", i)); next}
if(focal$STANDID[1] == "RS01" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 10 & focal$gx <= 40 & focal$gy >= 10 & focal$gy <= 40),]}
if(focal$STANDID[1] == "RS02" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 35 & focal$gx <= 65 & focal$gy >= 35 & focal$gy <= 65),]}
if(focal$STANDID[1] == "RS03" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 60 & focal$gx <= 90 & focal$gy >= 60 & focal$gy <= 90),]}
}
focal$sp = as.character(focal$sp)

# plot(df$XCOORD,df$YCOORD,asp=1)
# points(focal$gx,focal$gy,pch=19,col="red")
# points(focal.good2$gx,focal.good2$gy,pch=19,col="purple")

df.prev = test[[i-1]]
df.prev = df.prev[which(df.prev$TREE_STATUS %in% c(6,9) == F),]
df.prev$julian = as.numeric(julian(as.POSIXlt(df.prev$SAMPLEDATE, format = "%Y-%m-%d")))
focal.prev.time = df.prev
if(df$census[1] == 9 & df$STANDID[1] %in% c("RS34", "RS38") == T) {
	focal.prev.time$gx = focal.prev.time$XCOORD
	focal.prev.time$gy = focal.prev.time$YCOORD
	focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$uniqueID %in% focal$uniqueID == T),]
} else {
maxcol = max(as.numeric(substr(df.prev$quad,1,2)))
maxrow = max(as.numeric(substr(df.prev$quad,3,4)))
mincol = min(as.numeric(substr(df.prev$quad,1,2)))
minrow = min(as.numeric(substr(df.prev$quad,3,4)))
focal.prev.time$gx = focal.prev.time$XCOORD
focal.prev.time$gy = focal.prev.time$YCOORD
focal.prev.time.good = focal.prev.time[which(focal.prev.time$quad == 9999),]
for(k in mincol:maxcol) {
df.prev2 = df.prev[which(as.numeric(substr(df.prev$quad,1,2)) == k),]
ymax = max(as.numeric(substr(df.prev2$quad,3,4))) * 25
ymin = (min(as.numeric(substr(df.prev2$quad,3,4))) - 1) * 25
focal.prev.time.good = rbind(focal.prev.time.good, focal.prev.time[which(as.numeric(substr(focal.prev.time$quad,1,2)) == k & focal.prev.time$gy >= (ymin + elim.radius) & focal.prev.time$gy <= (ymax - elim.radius)),])
}
focal.prev.time.good2 = focal.prev.time.good[which(focal.prev.time.good$quad == 9999),]
for(k in minrow:maxrow) {
df.prev2 = df.prev[which(as.numeric(substr(df.prev$quad,3,4)) == k),]
xmax = max(as.numeric(substr(df.prev2$quad,1,2))) * 25
xmin = (min(as.numeric(substr(df.prev2$quad,1,2))) - 1) * 25
focal.prev.time.good2 = rbind(focal.prev.time.good2, focal.prev.time.good[which(as.numeric(substr(focal.prev.time.good$quad,3,4)) == k & focal.prev.time.good$gx >= (xmin + elim.radius) & focal.prev.time.good$gx <= (xmax - elim.radius)),])
}
if(focal.prev.time$STANDID[1] == "RS01" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 10 & focal.prev.time$gx <= 40 & focal.prev.time$gy >= 10 & focal.prev.time$gy <= 40),]}
if(focal.prev.time$STANDID[1] == "RS02" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 35 & focal.prev.time$gx <= 65 & focal.prev.time$gy >= 35 & focal.prev.time$gy <= 65),]}
if(focal.prev.time$STANDID[1] == "RS03" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 60 & focal.prev.time$gx <= 90 & focal.prev.time$gy >= 60 & focal.prev.time$gy <= 90),]}
}

# plot(df.prev$XCOORD,df.prev$YCOORD,asp=1)
# points(focal.prev.time$gx,focal.prev.time$gy,pch=19,col="red")
# points(focal.prev.time.good2$gx,focal.prev.time.good2$gy,pch=19,col="purple")

focal.prev.time = focal.prev.time.good2[,c("uniqueID", "DBH", "SPECIES", "YEAR", "gx", "gy", "STANDID", "quad", "TREE_STATUS", "julian", "DBH_CODE", "CANOPY_CLASS", "TREE_VIGOR", "MIN_DBH")]
names(focal.prev.time) = c("uniqueID", "DBH_prev", "sp", "YEAR_prev", "gx_prev", "gy_prev", "STANDID_prev", "quad_prev", "status_prev", "julian_prev", "dbh_code_prev", "canopy_class_prev", "vigor_prev", "min_dbh_prev")
focal.prev.time$sp = as.character(focal.prev.time$sp)
focal2 = merge(focal, focal.prev.time, by = c("uniqueID", "sp"), all = T)
focal2$growth = focal2$DBH - focal2$DBH_prev
focal2$numyr = (focal2$julian - focal2$julian_prev) / 365.25
focal2$growth.per.yr = focal2$growth / focal2$numyr
focal2$radial.growth.per.yr = (log(focal2$DBH/focal2$DBH_prev)) / focal2$numyr		# Relative Growth Rate per Wright et al. 2018 Ecology

# plot(df$XCOORD,df$YCOORD,asp=1)
# points(focal2$gx,focal2$gy,pch=19,col="red")
# points(focal.good2$gx,focal.good2$gy,pch=19,col="purple")

# Remove interior plot corners that are within 10 m of plot boundary (not captured in preceding code)
if(focal2$STANDID[1] == "RS01") {if(nrow(focal2[which(focal2$gx > 40 & focal2$gx < 50 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 40 & focal2$gx < 50 & focal2$gy > 50 & focal2$gy < 60),]}}
if(focal2$STANDID[1] == "RS03") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 40 & focal2$gy < 50),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 40 & focal2$gy < 50),]}}
if(focal2$STANDID[1] == "RS03") {if(nrow(focal2[which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 40 & focal2$gy < 50),]) > 0) {focal2 = focal2[-which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 40 & focal2$gy < 50),]}}
if(focal2$STANDID[1] == "RS23") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 50 & focal2$gy < 60),]}}
if(focal2$STANDID[1] == "RS23") {if(nrow(focal2[which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 50 & focal2$gy < 60),]}}
if(focal2$STANDID[1] == "RS38") {if(nrow(focal2[which(focal2$gx > 25 & focal2$gx < 35 & focal2$gy > 90 & focal2$gy < 100),]) > 0) {focal2 = focal2[-which(focal2$gx > 25 & focal2$gx < 35 & focal2$gy > 90 & focal2$gy < 100),]}}
if(focal2$STANDID[1] == "RS38") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 115 & focal2$gy < 125),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 115 & focal2$gy < 125),]}}


focal2$phi = c(1)
focal2$phi[is.na(focal2$DBH)] = 0
focal2$phi[is.na(focal2$DBH_prev)] = NA
focal2$gx[is.na(focal2$gx)] = focal2$gx_prev[is.na(focal2$gx)]
focal2$gy[is.na(focal2$gy)] = focal2$gy_prev[is.na(focal2$gy)]
focal2$quad = as.character(focal2$quad)
focal2$quad_prev = as.character(focal2$quad_prev)
focal2$STANDID = as.character(focal2$STANDID)
focal2$STANDID_prev = as.character(focal2$STANDID_prev)
focal2$quad[is.na(focal2$quad)] = focal2$quad_prev[is.na(focal2$quad)]
focal2$STANDID[is.na(focal2$STANDID)] = focal2$STANDID_prev[is.na(focal2$STANDID)]
focal2$census[is.na(focal2$census)] = c(unique(focal2$census[!is.na(focal2$YEAR)]))
focal2$YEAR[is.na(focal2$YEAR)] = c(unique(focal2$YEAR[!is.na(focal2$DBH)]))

adults = df[which(df$DBH >= 15),]
adults = adults[which(adults$TREE_STATUS %in% c(6,9) == F),]
adults.prev = df.prev[which(df.prev$DBH >= 15),]
adults.prev = adults.prev[which(adults.prev$TREE_STATUS %in% c(6,9) == F),]
adultlocs = data.frame(sp = adults$SPECIES, gx = adults$XCOORD, gy = adults$YCOORD, id = adults$uniqueID, dbh = adults$DBH)
adultlocs.prev = data.frame(sp = adults.prev$SPECIES, gx = adults.prev$XCOORD, gy = adults.prev$YCOORD, id = adults.prev$uniqueID, dbh = adults.prev$DBH)
unique.quads = unique(df$quad)
quad.gx = c()
quad.gy = c()
for(z in 1:length(unique.quads)) {
quad.gx[z] = (25*as.numeric(substr(unique.quads[z],1,2))-12.5)
quad.gy[z] = (25*as.numeric(substr(unique.quads[z],3,4))-12.5)
}
quadlocs = data.frame(id = unique.quads, gx = quad.gx, gy = quad.gy)
quad.weights.prev = dist.weighted.abund.function(adultlocs = adultlocs.prev, saplocs = quadlocs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
quad.weights2.prev = Add.missing.sp.names(quad.weights.prev)
if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
	quad.weights.combined = quad.weights2.prev
} else {
	quad.weights = dist.weighted.abund.function(adultlocs = adultlocs, saplocs = quadlocs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
	quad.weights2 = Add.missing.sp.names(quad.weights)
	quad.weights.combined = (quad.weights2 + quad.weights2.prev) / 2
}

adult.phi = focal2[which(focal2$DBH_prev >= 15),]
sap.phi = focal2[which(focal2$DBH_prev < 15),]

if(nrow(adult.phi) > 0) {
adult.phi$order = c(1:nrow(adult.phi))
adult.phi = adult.phi[order(adult.phi$sp),]
adult.phi.locs = data.frame(id = adult.phi$uniqueID, gx = adult.phi$gx, gy = adult.phi$gy)
adult.phi.weights.prev = dist.weighted.abund.function(adultlocs = adultlocs.prev, saplocs = adult.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
adult.phi.weights2.prev = Add.missing.sp.names(adult.phi.weights.prev)
if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
	adult.phi.weights.combined = adult.phi.weights2.prev
} else {
adult.phi.weights = dist.weighted.abund.function(adultlocs = adultlocs, saplocs = adult.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
adult.phi.weights2 = Add.missing.sp.names(adult.phi.weights)
adult.phi.weights.combined = (adult.phi.weights2 + adult.phi.weights2.prev) / 2
}
adult.phi = data.frame(adult.phi, adult.phi.weights.combined)
adult.phi = adult.phi[order(adult.phi$order),]
adult.phi.list[[i-1]] = adult.phi
}
if(nrow(sap.phi) > 0) {
sap.phi$order = c(1:nrow(sap.phi))
sap.phi = sap.phi[order(sap.phi$sp),]
sap.phi.locs = data.frame(id = sap.phi$uniqueID, gx = sap.phi$gx, gy = sap.phi$gy)
sap.phi.weights.prev = dist.weighted.abund.function(adultlocs = adultlocs.prev, saplocs = sap.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
sap.phi.weights2.prev = Add.missing.sp.names(sap.phi.weights.prev)
if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
	sap.phi.weights.combined = sap.phi.weights2.prev
} else {
sap.phi.weights = dist.weighted.abund.function(adultlocs = adultlocs, saplocs = sap.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
sap.phi.weights2 = Add.missing.sp.names(sap.phi.weights)
sap.phi.weights.combined = (sap.phi.weights2 + sap.phi.weights2.prev) / 2
}
sap.phi = data.frame(sap.phi, sap.phi.weights.combined)
sap.phi = sap.phi[order(sap.phi$order),]
sap.phi.list[[i-1]] = sap.phi
}
}
if(length(adult.phi.list) > 0) {
adult.phi.list = adult.phi.list[which(lapply(adult.phi.list, function(x) {nrow(x) > 0}) == T)]
adult.phi2 = do.call('rbind', adult.phi.list)
adult.phi2$yr = adult.phi2$YEAR - 2000
fd.adult.phi[[q]] = adult.phi2
}
if(length(sap.phi.list) > 0) {
sap.phi.list = sap.phi.list[which(lapply(sap.phi.list, function(x) {nrow(x) > 0}) == T)]
sap.phi2 = do.call('rbind', sap.phi.list)
sap.phi2$yr = sap.phi2$YEAR - 2000
fd.sap.phi[[q]] = sap.phi2
}
}






###############
## Prepare large-tree data for analysis (selected beta value = 0.3, basal area selected as metric of neighborhood density)
yr.value = 2008
fd.adult.phi4 = do.call('rbind', fd.adult.phi)
fd.adult.grow5 = merge(fd.adult.phi4, standclimate, by = "STANDID", all.x = T)
fd.adult.grow5 = fd.adult.grow5[which(fd.adult.grow5$phi == 1),]
fd.adult.grow5 = fd.adult.grow5[!is.na(fd.adult.grow5$growth.per.yr),]
fd.adult.grow5$yr2 = fd.adult.grow5$YEAR - yr.value
fd.adult.grow5$conspp = c(NA)
fd.adult.grow5$allspp = c(NA)
fd.adult.grow5$heterospp = c(NA)
adult.cols = which(colnames(fd.adult.grow5) %in% sp.list == T)
for(i in 1:nrow(fd.adult.grow5)) {
fd.adult.grow5$conspp[i] = fd.adult.grow5[i,which(colnames(fd.adult.grow5) == fd.adult.grow5$sp[i])]
fd.adult.grow5$allspp[i] = sum(fd.adult.grow5[i,adult.cols])
fd.adult.grow5$heterospp[i] = sum(fd.adult.grow5[i,adult.cols[which(colnames(fd.adult.grow5[,adult.cols]) != fd.adult.grow5$sp[i])]])
}
fd.adult.grow5 = fd.adult.grow5[which(fd.adult.grow5$census < 9),]
fd.adult.grow5 = fd.adult.grow5[which(fd.adult.grow5$dbh_code == "G"),]		# Remove trees where measurements were not considered accurate by observer in field
fd.adult.grow5 = fd.adult.grow5[which(fd.adult.grow5$dbh_code_prev == "G"),]	# Remove trees where measurements were not considered accurate by observer in field
fd.adult.grow6 = fd.adult.grow5

# Measurements removed due to sloughing bark or tags falling off tree
adult.growth.update = read.csv("HJA_RefStands_Adult_negGrowth_Checks_20200807update.csv", header = T)	# Remove trees that had negative growth due to bark or mechanical damage
adult.growth.update = adult.growth.update[,c("uniqueID", "YEAR", "growth.update")]
adult.growth.update = adult.growth.update[which(adult.growth.update$growth.update == 1),]
fd.adult.grow7 = fd.adult.grow6
for(i in 1:nrow(adult.growth.update)) {fd.adult.grow7$growth.per.yr[which(fd.adult.grow7$uniqueID == as.character(adult.growth.update$uniqueID[i]) & fd.adult.grow7$YEAR == adult.growth.update$YEAR[i])] = NA}
fd.adult.grow7 = fd.adult.grow7[!is.na(fd.adult.grow7$growth.per.yr),]








###### Analysis for large-tree growth

third = 1			# which third of the data for analysis (1, 2, 3)
quant3 = c(0, 25.4,  52.06667, 500)

d = fd.adult.grow7[which(fd.adult.grow7$DBH_prev >= quant3[third] & fd.adult.grow7$DBH_prev < quant3[third+1]),]
d = d[order(d$uniqueID,d$census),]
d$ID = as.character(d$uniqueID)
growth = scale(log(d$growth.per.yr+1))

uniID = as.numeric(factor(d$uniqueID))
consppid = tapply(d$conspp, uniID, mean)
heterosppid = tapply(d$heterospp, uniID, mean)

conhetero1 = c(consppid^(0.1), heterosppid^(0.1))
rtconspp1 = ((d$conspp^(0.1)) - mean(conhetero1)) / sd(conhetero1)
rtheterospp1 = ((d$heterospp^(0.1)) - mean(conhetero1)) / sd(conhetero1)
conhetero2 = c(consppid^(0.2), heterosppid^(0.2))
rtconspp2 = ((d$conspp^(0.2)) - mean(conhetero2)) / sd(conhetero2)
rtheterospp2 = ((d$heterospp^(0.2)) - mean(conhetero2)) / sd(conhetero2)
conhetero4 = c(consppid^(0.4), heterosppid^(0.4))
rtconspp4 = ((d$conspp^(0.4)) - mean(conhetero4)) / sd(conhetero4)
rtheterospp4 = ((d$heterospp^(0.4)) - mean(conhetero4)) / sd(conhetero4)
conhetero5 = c(consppid^(0.5), heterosppid^(0.5))
rtconspp5 = ((d$conspp^(0.5)) - mean(conhetero5)) / sd(conhetero5)
rtheterospp5 = ((d$heterospp^(0.5)) - mean(conhetero5)) / sd(conhetero5)
conhetero6 = c(consppid^(0.6), heterosppid^(0.6))
rtconspp6 = ((d$conspp^(0.6)) - mean(conhetero6)) / sd(conhetero6)
rtheterospp6 = ((d$heterospp^(0.6)) - mean(conhetero6)) / sd(conhetero6)
conhetero7 = c(consppid^(0.7), heterosppid^(0.7))
rtconspp7 = ((d$conspp^(0.7)) - mean(conhetero7)) / sd(conhetero7)
rtheterospp7 = ((d$heterospp^(0.7)) - mean(conhetero7)) / sd(conhetero7)
conhetero8 = c(consppid^(0.8), heterosppid^(0.8))
rtconspp8 = ((d$conspp^(0.8)) - mean(conhetero8)) / sd(conhetero8)
rtheterospp8 = ((d$heterospp^(0.8)) - mean(conhetero8)) / sd(conhetero8)
conhetero10 = c(consppid^(1.0), heterosppid^(1.0))
rtconspp10 = ((d$conspp^(1.0)) - mean(conhetero10)) / sd(conhetero10)
rtheterospp10 = ((d$heterospp^(1.0)) - mean(conhetero10)) / sd(conhetero10)
conhetero20 = c(consppid^(2.0), heterosppid^(2.0))
rtconspp20 = ((d$conspp^(2.0)) - mean(conhetero20)) / sd(conhetero20)
rtheterospp20 = ((d$heterospp^(2.0)) - mean(conhetero20)) / sd(conhetero20)
conhetero30 = c(consppid^(3.0), heterosppid^(3.0))
rtconspp30 = ((d$conspp^(3.0)) - mean(conhetero30)) / sd(conhetero30)
rtheterospp30 = ((d$heterospp^(3.0)) - mean(conhetero30)) / sd(conhetero30)

elevid = tapply(d$ELEVATION, uniID, mean)
dbhid = tapply(d$DBH_prev, uniID, mean)
yrid = tapply(d$julian_prev/365.25, uniID, mean)
ELEV = (d$ELEVATION - mean(elevid)) / sd(elevid)
dbh = (d$DBH_prev - mean(dbhid)) / sd(dbhid)
yr = ((d$julian_prev/365.25) - mean(yrid)) / sd(yrid)
yr2 = yr^2
census = as.numeric(as.character(factor(as.character(d$census)))) - 1
sp = as.numeric(factor(as.character(d$sp)))
sp.info = unique(data.frame(sp.name = d$sp, sp = sp))
plotsp = as.numeric(factor(as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID)))))
plotsp.info = unique(data.frame(sp = d$sp, plot = d$STANDID, combo = as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID))), plotELEV = ELEV, plotsp = plotsp))
plotcen = as.numeric(factor(as.character(factor(as.character(d$STANDID)):factor(as.character(d$census)))))
plotcen.info = unique(data.frame(yr = d$census, plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID)):factor(as.character(d$census))), plotELEV = ELEV, census = plotcen))
n.census = length(unique(census))
n.ID = length(unique(uniID))
n = nrow(d)
spINplot = plotsp.info$sp[order(plotsp.info$plotsp)]
plotELEV = plotsp.info$plotELEV[order(plotsp.info$plotsp)]


# Density exponent test models

adult.off.abs.growth.m1 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp1 + rtheterospp1 + ELEV + ELEV:rtconspp1 + ELEV:rtheterospp1 + dbh:rtconspp1 + dbh:rtheterospp1 +
	(rtconspp1 + rtheterospp1|sp) + (rtconspp1 + rtheterospp1|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m1)

adult.off.abs.growth.m2 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp2 + rtheterospp2 + ELEV + ELEV:rtconspp2 + ELEV:rtheterospp2 + dbh:rtconspp2 + dbh:rtheterospp2 +  
	(rtconspp2 + rtheterospp2|sp) + (rtconspp2 + rtheterospp2|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m2)

adult.off.abs.growth.m4 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp4 + rtheterospp4 + ELEV + ELEV:rtconspp4 + ELEV:rtheterospp4 + dbh:rtconspp4 + dbh:rtheterospp4 + 
	(rtconspp4 + rtheterospp4|sp) + (rtconspp4 + rtheterospp4|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m4)

adult.off.abs.growth.m5 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp5 + rtheterospp5 + ELEV + ELEV:rtconspp5 + ELEV:rtheterospp5 + dbh:rtconspp5 + dbh:rtheterospp5 + 
	(rtconspp5 + rtheterospp5|sp) + (rtconspp5 + rtheterospp5|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m5)

adult.off.abs.growth.m6 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp6 + rtheterospp6 + ELEV + ELEV:rtconspp6 + ELEV:rtheterospp6 + dbh:rtconspp6 + dbh:rtheterospp6 + 
	(rtconspp6 + rtheterospp6|sp) + (rtconspp6 + rtheterospp6|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m6)

adult.off.abs.growth.m7 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp7 + rtheterospp7 + ELEV + ELEV:rtconspp7 + ELEV:rtheterospp7 + dbh:rtconspp7 + dbh:rtheterospp7 +  
	(rtconspp7 + rtheterospp7|sp) + (rtconspp7 + rtheterospp7|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m7)

adult.off.abs.growth.m8 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp8 + rtheterospp8 + ELEV + ELEV:rtconspp8 + ELEV:rtheterospp8 + dbh:rtconspp8 + dbh:rtheterospp8 + 
	(rtconspp8 + rtheterospp8|sp) + (rtconspp8 + rtheterospp8|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m8)

adult.off.abs.growth.m10 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp10 + rtheterospp10 + ELEV + ELEV:rtconspp10 + ELEV:rtheterospp10 + dbh:rtconspp10 + dbh:rtheterospp10 + 
	(rtconspp10 + rtheterospp10|sp) + (rtconspp10 + rtheterospp10|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m10)

adult.off.abs.growth.m20 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp20 + rtheterospp20 + ELEV + ELEV:rtconspp20 + ELEV:rtheterospp20 + dbh:rtconspp20 + dbh:rtheterospp20 + 
	(rtconspp20 + rtheterospp20|sp) + (rtconspp20 + rtheterospp20|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m20)

adult.off.abs.growth.m30 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp30 + rtheterospp30 + ELEV + ELEV:rtconspp30 + ELEV:rtheterospp30 + dbh:rtconspp30 + dbh:rtheterospp30 + 
	(rtconspp30 + rtheterospp30|sp) + (rtconspp30 + rtheterospp30|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m30)

anova(adult.off.abs.growth.m1, adult.off.abs.growth.m2, adult.off.abs.growth.m4, adult.off.abs.growth.m5, 
	adult.off.abs.growth.m6, adult.off.abs.growth.m7, adult.off.abs.growth.m8, adult.off.abs.growth.m10, adult.off.abs.growth.m20, adult.off.abs.growth.m30)
alpha
beta







rtallspp7 = c(scale(d$allspp^(0.7)))
adult.off.abs.growth.m7a = lme4::lmer(growth ~ dbh + yr + yr2 + rtallspp7 + ELEV + ELEV:rtallspp7 + dbh:rtallspp7 +  
	(rtallspp7|sp) + (rtallspp7|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
anova(adult.off.abs.growth.m7a, adult.off.abs.growth.m7)











######################################
### GOODNESS OF FIT TESTS

# Residual plots
m1 = update(adult.off.abs.growth.m7, REML = T)
m1.noreml = adult.off.abs.growth.m7
conspp = rtconspp7
heterospp = rtheterospp7

plot(predict(m1), resid(m1, type = "pearson"))
plot(conspp, resid(m1, type = "pearson"), xlab = "Conspecific BA")
plot(heterospp, resid(m1, type = "pearson"), xlab = "Heterospecific BA")
plot(dbh, resid(m1, type = "pearson"), xlab = "DBH")
plot(yr, resid(m1, type = "pearson"), xlab = "DBH")
plot(yr2, resid(m1, type = "pearson"), xlab = "DBH2")
plot(ELEV, resid(m1, type = "pearson"), xlab = "Elevation")
plot(resid(m1, type = "pearson") ~ factor(plotcen))
plot(resid(m1, type = "pearson") ~ factor(sp))
plot(resid(m1, type = "pearson") ~ factor(plotsp))
plot(resid(m1, type = "pearson") ~ factor(ELEV))


























#######################################################################################
### BAYESIAN MODEL OF ADULT GROWTH	


third = 1			# which third of the data for analysis (1, 2, 3)
quant3 = c(0, 25.4,  52.06667, 500)
DenExp = 0.7

d = fd.adult.grow7[which(fd.adult.grow7$DBH_prev >= quant3[third] & fd.adult.grow7$DBH_prev < quant3[third+1]),]
d = d[order(d$uniqueID,d$census),]

d$ID = as.character(d$uniqueID)
uniID = as.numeric(factor(d$uniqueID))
consppid = tapply(d$conspp, uniID, mean)
heterosppid = tapply(d$heterospp, uniID, mean)
growth = c(scale(log(d$growth.per.yr+1)))

conhetero = c(consppid^(DenExp), heterosppid^(DenExp))
conspp = ((d$conspp^(DenExp)) - mean(conhetero)) / sd(conhetero)
heterospp = ((d$heterospp^(DenExp)) - mean(conhetero)) / sd(conhetero)

elevid = tapply(d$ELEVATION, uniID, mean)
dbhid = tapply(d$DBH_prev, uniID, mean)
yrid = tapply(d$julian_prev/365.25, uniID, mean)
ELEV = (d$ELEVATION - mean(elevid)) / sd(elevid)
dbh = (d$DBH_prev - mean(dbhid)) / sd(dbhid)
yr = ((d$julian_prev/365.25) - mean(yrid)) / sd(yrid)
yr2 = yr^2
census = as.numeric(as.character(factor(as.character(d$census)))) - 1
sp = as.numeric(factor(as.character(d$sp)))
sp.info = unique(data.frame(sp.name = d$sp, sp = sp))
plotsp = as.numeric(factor(as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID)))))
plotsp.info = unique(data.frame(sp = d$sp, plot = d$STANDID, combo = as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID))), plotELEV = ELEV, plotsp = plotsp))
plotcen = as.numeric(factor(as.character(factor(as.character(d$STANDID)):factor(as.character(d$census)))))
plotcen.info = unique(data.frame(yr = d$census, plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID)):factor(as.character(d$census))), plotELEV = ELEV, census = plotcen))
uniID = as.numeric(factor(d$uniqueID))
n.census = length(unique(census))
n.ID = length(unique(uniID))
n.plotcen = length(unique(plotcen))
n = nrow(d)
x = cbind(rep(1,times = n), dbh, yr, yr2, conspp, heterospp, ELEV, conspp*ELEV, heterospp*ELEV, conspp*dbh, heterospp*dbh)
K = ncol(x)
PX = cbind(rep(1,times = n), conspp, heterospp)
PK = ncol(PX)
PJ = length(unique(plotsp))
SX = cbind(rep(1,times = n), conspp, heterospp)
SK = ncol(SX)
SJ = length(unique(sp))
spINplot = plotsp.info$sp[order(plotsp.info$plotsp)]
plotELEV = plotsp.info$plotELEV[order(plotsp.info$plotsp)]


# Split data for censored regression (many zeros that are likely negative growth)

U = unique(growth[which(d$growth.per.yr == 0)])		# censor point

nonzero = which(growth != U)
zeros = which(growth == U)
growth.nonzero = growth[nonzero]
x.nonzero = x[nonzero,]
PX.nonzero = PX[nonzero,]
SX.nonzero = SX[nonzero,]
plotsp.nonzero = plotsp[nonzero]
sp.nonzero = sp[nonzero]
uniID.nonzero = uniID[nonzero]
plotcen.nonzero = plotcen[nonzero]
yr.nonzero = yr[nonzero]
n.nonzero = length(growth.nonzero)

growth.zeros = growth[zeros]
x.zeros = x[zeros,]
PX.zeros = PX[zeros,]
SX.zeros = SX[zeros,]
plotsp.zeros = plotsp[zeros]
sp.zeros = sp[zeros]
uniID.zeros = uniID[zeros]
plotcen.zeros = plotcen[zeros]
yr.zeros = yr[zeros]
n.zeros = length(growth.zeros)


# Bundle data
dat <- list(y = growth.nonzero, x = x.nonzero, xZ = x.zeros, K = K, plotsp = plotsp.nonzero, sp = sp.nonzero, uniID = uniID.nonzero, census = plotcen.nonzero, yr = yr.nonzero,  
	ncensus = n.plotcen, PJ = PJ, PK = PK, PX = PX.nonzero, SJ = SJ, SK = SK, SX = SX.nonzero, nID = n.ID, N = n.nonzero, U = U, 
	plotspZ = plotsp.zeros, spZ = sp.zeros, uniIDZ = uniID.zeros, censusZ = plotcen.zeros, yrZ = yr.zeros, PXZ = PX.zeros, SXZ = SX.zeros, NZ = n.zeros)

# LMER model with ML for ranef variance estimates (once run, comment off with #)
set.seed(314)
m1 = lme4::lmer(growth ~ dbh + yr + yr2 + conspp + heterospp + ELEV + conspp:ELEV + heterospp:ELEV + conspp:dbh + heterospp:dbh + 
	(conspp + heterospp|sp) + (conspp + heterospp|plotsp) + (1|uniID) + (1|plotcen), 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(m1)



### Fit stan model 
# HMC Parameters
nchains = 12
postburn = 5000
burnin = 3000
its = postburn + burnin
thin = 1
hmc_seed = 55406

# Initial values from LMER model
vc <- VarCorr(m1)
sigma_SB_lmer = as.matrix(Matrix::bdiag(vc$sp))
sigma_PB_lmer = as.matrix(Matrix::bdiag(vc$plotsp))
inits <- replicate(nchains, list(
  Pz = t(data.matrix(ranef(m1)$'plotsp')),
  PL_Omega = sigma_PB_lmer,
  Ptau_unif = runif(PK),
  Sz = t(data.matrix(ranef(m1)$'sp')),
  SL_Omega = sigma_SB_lmer,
  Stau_unif = runif(SK),
  beta = fixef(m1),
  sigma_ID = attr(summary(m1)$varcor$uniID,"stddev")[[1]], 
  uniqueID = ranef(m1)$'uniID'[[1]], 
  sigma_YEAR = attr(summary(m1)$varcor$plotcen,"stddev")[[1]],
  YEAR = ranef(m1)$'plotcen'[[1]], 
  PB = data.matrix(ranef(m1)$'plotsp'), 
  sigma_PB = sigma_PB_lmer, 
  Ptau = runif(PK), 
  SB = data.matrix(ranef(m1)$'sp'), 
  sigma_SB = sigma_SB_lmer, 
  Stau = runif(SK),
  sigma_res = summary(m1)$sigma, 
  yZ = rep(1.1*U, times = n.zeros)
), simplify = F)


# Run model
begin = Sys.time()
fit <- stan(file = "HJA_GLMM_CENSORED_Growth_Model.stan", 					# Stan model
  data = dat,   										# named list of data
  init = inits,											# initial values for parameters
  chains = nchains,             								# number of Markov chains
  warmup = burnin,          									# number of warmup iterations per chain
  iter = its,            									# total number of iterations per chain
  cores = nchains,              								# number of cores (could use one per chain)
  thin = thin,
  seed = hmc_seed,
  control = list(adapt_delta = 0.99)
  )
end = Sys.time()
(duration = end - begin)

# save(fit, file = "HJA_15to25cmDBH_Growth_Bayesian_alpha1-0_beta0-2root0-7_censored_STAN_20210524.RData")





divergent <- get_sampler_params(fit, inc_warmup=FALSE)
divergent2 = list()
for(i in 1:length(divergent)) {divergent2[[i]] = data.frame(div = divergent[[i]][,'divergent__'], chain = i)}
divergent = do.call('rbind', divergent2)
sum(divergent$div)
table(divergent$chain[which(divergent$div == 1)])

treedepth <- get_sampler_params(fit, inc_warmup=FALSE)
tree.depth = list()
for(i in 1:length(treedepth)) {tree.depth[[i]] = data.frame(treedepth = treedepth[[i]][,'treedepth__'], chain = i)}
tree.depth = do.call('rbind', tree.depth)
summary(tree.depth$treedepth)
table(tree.depth$treedepth)
table(tree.depth$chain[which(tree.depth$treedepth > 9)])





divergent <- get_sampler_params(fit, inc_warmup=FALSE)
divergent2 = list()
for(i in 1:length(divergent)) {divergent2[[i]] = data.frame(div = divergent[[i]][,'divergent__'], chain = i)}
divergent = do.call('rbind', divergent2)
sum(divergent$div)
table(divergent$chain[which(divergent$div == 1)])
div.chains = unique(divergent$chain[which(divergent$div == 1)])
draws <- extract(fit, permuted = FALSE)
draws = draws[,which(c(1:nchains) %in% div.chains == F),] # Remove chains 2 and 5, which had divergences (only 1 divergence on each chains) 


thin1 = 20
acf(c(draws[seq(1,postburn,by=thin1),,"beta[1]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"beta[2]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"beta[3]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"beta[4]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"beta[5]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"beta[6]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"beta[7]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"beta[8]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_ID"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_YEAR"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_PB[1,1]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_PB[2,2]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_PB[3,3]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_PB[1,2]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_PB[1,3]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_PB[2,3]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_SB[1,1]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_SB[2,2]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_SB[3,3]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_SB[1,2]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_SB[1,3]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_SB[2,3]"]), lag.max = 100)



thin1 = 20
beta.m = apply(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta")],3,c)
SB.m = apply(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB")],3,c)
SB.m = array(SB.m, dim = c(nrow(SB.m),SJ,SK), dimnames = list(paste("it",c(1:nrow(SB.m)),sep=""),paste("sp",c(1:SJ),sep=""),paste("SB",c(1:SK),sep="")))
PB.m = apply(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB")],3,c)
PB.m = array(PB.m, dim = c(nrow(PB.m),PJ,PK), dimnames = list(paste("it",c(1:nrow(PB.m)),sep=""),paste("plotsp",c(1:PJ),sep=""),paste("PB",c(1:PK),sep="")))
census.m = apply(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")],3,c)
ID.m = apply(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,8) == "uniqueID")],3,c)
sigmaSB.m = apply(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB")],3,c)
sigmaPB.m = apply(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB")],3,c)
sigmaYR.m = c(draws[seq(1,postburn,by=thin1),,"sigma_YEAR"])
sigmaID.m = c(draws[seq(1,postburn,by=thin1),,"sigma_ID"])
sigmaRES.m = c(draws[seq(1,postburn,by=thin1),,"sigma_res"])
yZ.m = apply(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,2) == "yZ")],3,c)

# Estimates
t(apply(beta.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(beta.m,2,mean)
t(apply(sigmaSB.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(sigmaSB.m,2,mean)
t(apply(sigmaPB.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(sigmaPB.m,2,mean)
quantile(sigmaYR.m^2,c(0.025,0.975,0.05,0.95,0.5)); mean(sigmaYR.m^2)
quantile(sigmaID.m^2,c(0.025,0.975,0.05,0.95,0.5)); mean(sigmaID.m^2)
quantile(sigmaRES.m^2,c(0.025,0.975,0.05,0.95,0.5)); mean(sigmaRES.m^2)













# Posterior point-wise log-likelihoods
Z = length(sigmaYR.m)
fitted.m = matrix(NA,nrow=Z,ncol=n)
log_lik = matrix(NA,nrow=Z,ncol=n)
res = matrix(NA,nrow=Z,ncol=n)
for(z in 1:Z) {
  SBbysp = matrix(NA,nrow=n,ncol=SK)
  for(i in 1:n) {SBbysp[i,] = SB.m[z,sp[i],]}
  PBbyplotsp = matrix(NA,nrow=n,ncol=PK)
  for(i in 1:n) {PBbyplotsp[i,] = PB.m[z,plotsp[i],]}
  IDbyind = c()
  for(i in 1:n) {IDbyind[i] = ID.m[z,uniID[i]]}
  YRbycensus = c()
  for(i in 1:n) {YRbycensus[i] = census.m[z,plotcen[i]]}
  fitted.m[z,] = (x %*% beta.m[z,]) + rowSums(SX*SBbysp) + rowSums(PX*PBbyplotsp) + IDbyind + YRbycensus
  for(i in 1:length(growth)) {
    if(growth[i] != U) {log_lik[z,i] = dnorm(growth[i], mean = fitted.m[z,i], sd = sigmaRES.m[z], log = T)}
    if(growth[i] == U) {log_lik[z,i] = pnorm(growth[i], mean = fitted.m[z,i], sd = sigmaRES.m[z], log = T)}
  }
  growth.wcens = growth
  growth.wcens[zeros] = yZ.m[z,]
  res[z,] = growth.wcens - fitted.m[z,]
}
loglik.m = rowSums(log_lik)
dev.m = rowSums(log_lik)*-2


# logLik and dev at mean posterior parameters
beta.mean = apply(beta.m, 2, mean)
SB.mean = apply(SB.m,c(2,3),mean)
PB.mean = apply(PB.m,c(2,3),mean)
ID.mean = apply(ID.m, 2, mean)
census.mean = apply(census.m, 2, mean)
  SBbysp = matrix(NA,nrow=n,ncol=SK)
  for(i in 1:n) {SBbysp[i,] = SB.mean[sp[i],]}
  PBbyplotsp = matrix(NA,nrow=n,ncol=PK)
  for(i in 1:n) {PBbyplotsp[i,] = PB.mean[plotsp[i],]}
  IDbyind = c()
  for(i in 1:n) {IDbyind[i] = ID.mean[uniID[i]]}
  YRbycensus = c()
  for(i in 1:n) {YRbycensus[i] = census.mean[plotcen[i]]}
y.cens = apply(yZ.m,2,mean)
fitted.meanpar = (x %*% beta.mean) + rowSums(SX*SBbysp) + rowSums(PX*PBbyplotsp) + IDbyind + YRbycensus
growth.meanpar.wcens = growth
growth.meanpar.wcens[zeros] = y.cens
res.meanpar = growth.meanpar.wcens - fitted.meanpar
logLik.meanpar = c()
  for(i in 1:length(growth)) {
    if(growth[i] != U) {logLik.meanpar[i] = dnorm(growth[i], mean = fitted.meanpar[i], sd = mean(sigmaRES.m), log = T)}
    if(growth[i] == U) {logLik.meanpar[i] = pnorm(growth[i], mean = fitted.meanpar[i], sd = mean(sigmaRES.m), log = T)}
  }
logLik.meanpar.sum = sum(logLik.meanpar)
dev.meanpar = -2 * logLik.meanpar.sum
pD = mean(dev.m) - dev.meanpar
DIC = dev.meanpar + (2*pD)
dev.meanpar; pD; DIC

# Approximate leave-one-out fit metrics
library(loo)
begin = Sys.time()
r_eff <- relative_eff(exp(log_lik), chain_id = rep(1:11,each=250), cores = 5)
loo_1 <- loo(log_lik, r_eff = r_eff, cores = 5)
end = Sys.time()
(duration = end - begin)
print(loo_1)


# save(loo_1, file = "HJA_Growth_15to25cmDBH_LOO_regular.RData")
loo_base = loo_1

load("HJA_Growth_15to25cmDBH_LOO_DBHre.RData")
sum(loo_base$pointwise[,1] - loo_1$pointwise[,1])		# Difference in ELPD between models
sqrt(n*var(loo_base$pointwise[,1] - loo_1$pointwise[,1]))	# SE of difference in ELPD

load("HJA_Growth_15to25cmDBH_LOO_confam.RData")
sum(loo_base$pointwise[,1] - loo_1$pointwise[,1])		# Difference in ELPD between models
sqrt(n*var(loo_base$pointwise[,1] - loo_1$pointwise[,1]))	# SE of difference in ELPD




## Residual plots
meanGrowth = mean(log(d$growth.per.yr + 1)); sdGrowth = sd(log(d$growth.per.yr + 1))
growth.trans = function(x) {exp((x * sdGrowth) + meanGrowth) - 1}


#pdf("HJA_15-25cmDBH_Growth_Bayesian_residual_plots_20210524.pdf", height = 7, width = 5, useDingbats=FALSE)
set.seed(314)
itres = sample(Z, size=1)
par(mfrow=c(4,2))
par(mar=c(4,4,2,2))
cexptvalue = 0.7
transparencyvalue = 0.4
plot(growth.trans(fitted.m[itres,]),res[itres,],las=1,xlab="Predicted annual growth (cm/yr)",ylab="Residuals",cex=cexptvalue,col = adjustcolor("blue",alpha.f=transparencyvalue)); abline(h=0,lty=2)
binnedplot(growth.trans(fitted.m[itres,]),res[itres,],nclass = round(n.ID/4,0),las=1,xlab="Predicted annual growth (cm/yr)",ylab="Binned residuals",main="",cex.pts=cexptvalue-0.2); abline(h=0,lty=2)
plot(conspp,res[itres,],las=1,xlab="Std. local conspecific density",ylab="Residuals",cex=cexptvalue,col = adjustcolor("blue",alpha.f=transparencyvalue)); abline(h=0,lty=2)
plot(heterospp,res[itres,],las=1,xlab="Std. local heterospecific density",ylab="Residuals",cex=cexptvalue,col = adjustcolor("blue",alpha.f=transparencyvalue)); abline(h=0,lty=2)
plot(dbh,res[itres,],las=1,xlab="Standardized initial DBH",ylab="Residuals",cex=cexptvalue,col = adjustcolor("blue",alpha.f=transparencyvalue)); abline(h=0,lty=2)
plot(ELEV,res[itres,],las=1,xlab="Standardized elevation",ylab="Residuals",cex=cexptvalue,col = adjustcolor("blue",alpha.f=transparencyvalue)); abline(h=0,lty=2)
plot(plotsp,res[itres,],las=1,xlab="Plot-by-species combination",ylab="Residuals",cex=cexptvalue,col = adjustcolor("blue",alpha.f=transparencyvalue)); abline(h=0,lty=2)
plot(yr,res[itres,],las=1,xlab="Standardized initial year in census",ylab="Residuals",cex=cexptvalue,col = adjustcolor("blue",alpha.f=transparencyvalue)); abline(h=0,lty=2)
#dev.off()







## For Posterior Predictive Check (based on all samples from the posterior parameter distributions)
rep.m = list()
for(i in 1:nrow(fitted.m)){
	rep.m[[i]] = as.numeric(rnorm(n = length(fitted.m[i,]), mean = fitted.m[i,], sd = sigmaRES.m[i]))
	censored = sample(which(rep.m[[i]] < U), size = length(zeros), replace = F)
	rep.m[[i]][censored] = U
}
rep.m = do.call('rbind', rep.m)
logliks.sim = matrix(NA,nrow=Z,ncol=n)
for(z in 1:nrow(rep.m)){
  for(i in 1:ncol(rep.m)) {
    if(rep.m[z,i] != U) {logliks.sim[z,i] = dnorm(rep.m[z,i], mean = fitted.m[z,i], sd = sigmaRES.m[z], log = T)}
    if(rep.m[z,i] == U) {logliks.sim[z,i] = pnorm(rep.m[z,i], mean = fitted.m[z,i], sd = sigmaRES.m[z], log = T)}
  }
}
loglik.sim = rowSums(logliks.sim)


# LogLik comparison
#pdf("HJA_15to25cmDBH_Growth_logLik_PPC_BAYES_20210524.pdf", height = 4, width = 5, useDingbats=FALSE)
hist(loglik.sim, breaks=30, xlim=c(range(loglik.sim,median(loglik.m), na.rm=T)), xlab = "Log-likelihood of simulated data", 
	col = "gray85", las = 1, main = "15-25 cm DBH growth log-likelihood PPC")
abline(v = mean(loglik.m), lwd = 2, col = "red")
sum(loglik.sim > mean(loglik.m)) / nrow(rep.m)
#dev.off()


# What proportion of actual response data falls outside min and max of simulated data
test = apply(rep.m, 1, function(x) {length(which(growth < min(x) | growth > max(x)))/length(growth)})
summary(test)


# Prediction test
diffp = c()
for(i in 1:nrow(d)) {
diffp[i] = length(which(rep.m[,i] > growth[i])) / length(rep.m[,i])
}
diffp2 = diffp
diffp2[which(diffp2 > 0.5)] = 1 - diffp2[which(diffp2 > 0.5)] 
hist(diffp2,breaks=50)
1 - length(which(diffp>0.975|diffp<0.025))/length(diffp)	# Percent of the data that are predicted (within 95% Credible interval of predictions)
1 - length(which(diffp2<0.025))/length(diffp2)	# Percent of the data that are predicted (within 95% Credible interval of predictions)










dbhtest = 15
DenExp = 0.7
StdAdultDBH = 60
meanGrowth = mean(log(d$growth.per.yr + 1)); sdGrowth = sd(log(d$growth.per.yr + 1))
growth.trans = function(x) {exp((x * sdGrowth) + meanGrowth) - 1}
zerotree = (0 - mean(conhetero)) / sd(conhetero)
onetree = (((StdAdultDBH^alpha)^DenExp) - mean(conhetero)) / sd(conhetero)
consppmeantree = (mean(consppid^(DenExp)) - mean(conhetero)) / sd(conhetero)
heterosppmeantree = (mean(heterosppid^(DenExp)) - mean(conhetero)) / sd(conhetero)
plotsp.info2 = plotsp.info[order(plotsp.info$plotsp),]
names(plotsp.info2)[1] = "sp.name"
plotsp.info2 = merge(plotsp.info2, sp.info, by = "sp.name", all = T)
dbh.m = beta.m[,2]
dbhtest2 = (dbhtest - mean(dbhid)) / sd(dbhid)
cndd.m = beta.m[,5]
hndd.m = beta.m[,6]
cnddelev.m = beta.m[,8]
hnddelev.m = beta.m[,9]
cndddbh.m = beta.m[,10]
hndddbh.m = beta.m[,11]
alpha.m = beta.m[,1]
alt.m = beta.m[,7]
plot.alpha = list()
plot.alpha2 = list()
cndd = list()
hndd = list()
realcon = list()
realhet = list()
realcndd = list()
sp.alpha = list()
sp.alpha2 = list()
for(i in 1:PJ) {
  plot.alpha[[i]] = alpha.m + (dbh.m*dbhtest2) + SB.m[,plotsp.info2$sp[i],1] + PB.m[,plotsp.info2$plotsp[i],1] + (alt.m * plotsp.info2$plotELEV[i])
  cndd[[i]] = cndd.m + (cndddbh.m*dbhtest2) + SB.m[,plotsp.info2$sp[i],2] + PB.m[,plotsp.info2$plotsp[i],2] + (cnddelev.m * plotsp.info2$plotELEV[i])
  hndd[[i]] = hndd.m + (hndddbh.m*dbhtest2) + SB.m[,plotsp.info2$sp[i],3] + PB.m[,plotsp.info2$plotsp[i],3] + (hnddelev.m * plotsp.info2$plotELEV[i])
  realcndd[[i]] = (growth.trans(plot.alpha[[i]] + (cndd[[i]]*onetree) + (hndd[[i]]*zerotree))) - (growth.trans(plot.alpha[[i]] + (cndd[[i]]*zerotree) + (hndd[[i]]*onetree)))
  realcon[[i]] = (growth.trans(plot.alpha[[i]] + (cndd[[i]]*onetree) + (hndd[[i]]*zerotree))) - (growth.trans(plot.alpha[[i]] + (cndd[[i]]*zerotree) + (hndd[[i]]*zerotree)))
  realhet[[i]] = (growth.trans(plot.alpha[[i]] + (cndd[[i]]*zerotree) + (hndd[[i]]*onetree))) - (growth.trans(plot.alpha[[i]] + (cndd[[i]]*zerotree) + (hndd[[i]]*zerotree)))
#  realcndd[[i]] = realcon[[i]] - realhet[[i]]		## Mathematically the same as 'realcndd' above
  plot.alpha2[[i]] = plot.alpha[[i]] + (cndd[[i]]*zerotree) + (hndd[[i]]*zerotree)
  sp.alpha[[i]] = alpha.m + (dbh.m*dbhtest2) + SB.m[,plotsp.info2$sp[i],1] + PB.m[,plotsp.info2$plotsp[i],1]
  sp.alpha2[[i]] = alpha.m + (dbh.m*dbhtest2) + SB.m[,plotsp.info2$sp[i],1] + PB.m[,plotsp.info2$plotsp[i],1] + ((cndd.m + (cndddbh.m*dbhtest2) + SB.m[,plotsp.info2$sp[i],2] + PB.m[,plotsp.info2$plotsp[i],2])*zerotree) + ((hndd.m + (hndddbh.m*dbhtest2) + SB.m[,plotsp.info2$sp[i],3] + PB.m[,plotsp.info2$plotsp[i],3])*zerotree)
}
plot.alpha = do.call('cbind', plot.alpha)
plot.alpha2 = do.call('cbind', plot.alpha2)
cndd = do.call('cbind', cndd)
hndd = do.call('cbind', hndd)
realcon = do.call('cbind', realcon)
realhet = do.call('cbind', realhet)
realcndd = do.call('cbind', realcndd)
sp.alpha = do.call('cbind', sp.alpha)
sp.alpha2 = do.call('cbind', sp.alpha2)
alpha.mean = mean(growth.trans(alpha.m + (dbh.m*dbhtest2) + ((cndd.m + (cndddbh.m*dbhtest2))*zerotree) + ((hndd.m + (hndddbh.m*dbhtest2))*zerotree)))
elevseq = seq(min(ELEV),max(ELEV),length=1000)
temp.mean = c()
for(i in 1:length(elevseq)) {temp.mean[i] = mean(growth.trans(alpha.m + (dbh.m*dbhtest2) + (alt.m*elevseq[i]) + ((cndd.m + (cndddbh.m*dbhtest2) + (cnddelev.m*elevseq[i]))*zerotree) + ((hndd.m + (hndddbh.m*dbhtest2) + (hnddelev.m*elevseq[i]))*zerotree)))}
sp.temp.mean = matrix(NA,nrow=length(elevseq),ncol=ncol(sp.alpha2))
for(j in 1:ncol(sp.alpha2)) {
 for(i in 1:length(elevseq)) {sp.temp.mean[i,j] = mean(growth.trans(sp.alpha2[,j] + (alt.m*elevseq[i]) + ((cnddelev.m*elevseq[i])*zerotree) + ((hnddelev.m*elevseq[i])*zerotree)))}
}
sp.alpha.mean = list()
for(i in 1:SJ) {
  if(is.null(ncol(sp.temp.mean[,which(plotsp.info2$sp == i)]))) {sp.alpha.mean[[i]] = sp.temp.mean[,which(plotsp.info2$sp == i)]}
  if(!is.null(ncol(sp.temp.mean[,which(plotsp.info2$sp == i)]))) {sp.alpha.mean[[i]] = rowSums(sp.temp.mean[,which(plotsp.info2$sp == i)]) / length(which(plotsp.info2$sp == i))}
}
sp.alpha.mean = do.call('cbind', sp.alpha.mean)



# Standardized estimates
cddelev.m2 = list()
hddelev.m2 = list()
cnddelev.m2 = list()
for(i in 1:nrow(realcndd)) {
  cddelev.m2[[i]] = lmer(realcon[i,] ~ plotsp.info2$plotELEV + (1|plotsp.info2$sp))
  hddelev.m2[[i]] = lmer(realhet[i,] ~ plotsp.info2$plotELEV + (1|plotsp.info2$sp))
  cnddelev.m2[[i]] = lmer(realcndd[i,] ~ plotsp.info2$plotELEV + (1|plotsp.info2$sp))
}

cdd.m2ests = unlist(lapply(cddelev.m2, function(x) {return(summary(x)$coef[1,1])}))
cddelev.m2ests = unlist(lapply(cddelev.m2, function(x) {return(summary(x)$coef[2,1])}))
cdd.m2ests.sp = do.call('cbind',lapply(cddelev.m2, function(x) {return(ranef(x)[[1]])}))
hdd.m2ests = unlist(lapply(hddelev.m2, function(x) {return(summary(x)$coef[1,1])}))
hddelev.m2ests = unlist(lapply(hddelev.m2, function(x) {return(summary(x)$coef[2,1])}))
hdd.m2ests.sp = do.call('cbind',lapply(hddelev.m2, function(x) {return(ranef(x)[[1]])}))
cndd.m2ests = unlist(lapply(cnddelev.m2, function(x) {return(summary(x)$coef[1,1])}))
cnddelev.m2ests = unlist(lapply(cnddelev.m2, function(x) {return(summary(x)$coef[2,1])}))
cndd.m2ests.sp = do.call('cbind',lapply(cnddelev.m2, function(x) {return(ranef(x)[[1]])}))

quantile(cddelev.m2ests, c(0.05,0.5,0.95))
sum(cddelev.m2ests < 0) / length(cddelev.m2ests)

quantile(hddelev.m2ests, c(0.05,0.5,0.95))
sum(hddelev.m2ests < 0) / length(hddelev.m2ests)

quantile(cndd.m2ests, c(0.05,0.5,0.95))
1-(sum(cndd.m2ests < 0) / length(cndd.m2ests))

quantile(cnddelev.m2ests, c(0.05,0.5,0.95))
sum(cnddelev.m2ests < 0) / length(cnddelev.m2ests)



# save(cndd.m2ests, cnddelev.m2ests, file = paste("HJA_CNDDELEV_Growth_",dbhtest,"cmDBH_20210524.RData", sep = ""))


plot(plotsp.info2$plotELEV, apply(realcndd,2,mean), las = 1, ylab = "Change in annual growth (cm DBH/yr) from CNDD", 
	main = paste("DBH = ", dbhtest, " cm", sep=""))
abline(h=0,lty=2)
curve(mean(cndd.m2ests) + (mean(cnddelev.m2ests)*x), add = T, xlim = range(plotsp.info2$plotELEV), lwd = 2)
elevseq = seq(min(ELEV),max(ELEV),length=1000)
upper = c()
for(i in 1:length(elevseq)) {upper[i] = quantile((cndd.m2ests+(cnddelev.m2ests*elevseq[i])),c(0.95))}
lower = c()
for(i in 1:length(elevseq)) {lower[i] = quantile((cndd.m2ests+(cnddelev.m2ests*elevseq[i])),c(0.05))}
lines((elevseq), upper, lty = 3, lwd = 2)
lines((elevseq), lower, lty = 3, lwd = 2)


# Mean at low elev, mean at high elev, and difference
data.frame(est = c(mean((cndd.m2ests+(cnddelev.m2ests*min(elevseq)))), mean((cndd.m2ests+(cnddelev.m2ests*max(elevseq)))), mean((cndd.m2ests+(cnddelev.m2ests*min(elevseq))) - (cndd.m2ests+(cnddelev.m2ests*max(elevseq))))))

# 90% CI at low elev, mean at high elev, and difference
rbind(quantile((cndd.m2ests+(cnddelev.m2ests*min(elevseq))),c(0.05,0.95)),
quantile((cndd.m2ests+(cnddelev.m2ests*max(elevseq))),c(0.05,0.95)),
quantile((cndd.m2ests+(cnddelev.m2ests*min(elevseq))) - (cndd.m2ests+(cnddelev.m2ests*max(elevseq))),c(0.05,0.95)))

# One-sided test for each (proportion of posterior distribution more extreme than zero)
data.frame(test = c(sum((cndd.m2ests+(cnddelev.m2ests*min(elevseq))) > 0) / length(cnddelev.m2ests),
sum((cndd.m2ests+(cnddelev.m2ests*max(elevseq))) > 0) / length(cnddelev.m2ests),
sum((cndd.m2ests+(cnddelev.m2ests*min(elevseq))) - (cndd.m2ests+(cnddelev.m2ests*max(elevseq))) > 0) / length(cnddelev.m2ests)))












# Plot relationship between elevation and mean adult survival
plot.alpha.real = growth.trans(plot.alpha2)
plot.alpha.mean = apply(plot.alpha.real, 2, mean)
plot.alpha.u50 = apply(plot.alpha.real,2,quantile, 0.75)
plot.alpha.l50 = apply(plot.alpha.real,2,quantile, 0.25)
plot.alpha.u68 = apply(plot.alpha.real,2,quantile, 0.84)
plot.alpha.l68 = apply(plot.alpha.real,2,quantile, 0.16)

sp.cdd = list()
sp.hdd = list()
sp.nfd = list()
for(i in 1:length(cndd.m2ests)) {
	sp.cdd[[i]] = cdd.m2ests[i] + cdd.m2ests.sp[,i]
	sp.hdd[[i]] = hdd.m2ests[i] + hdd.m2ests.sp[,i]
	sp.nfd[[i]] = cndd.m2ests[i] + cndd.m2ests.sp[,i]
}
sp.cdd = do.call('rbind', sp.cdd)
sp.hdd = do.call('rbind', sp.hdd)
sp.nfd = do.call('rbind', sp.nfd)

plotsp.info2 = data.frame(plotsp.info[order(plotsp.info$plotsp),], plot.alpha.mean = plot.alpha.mean, plot.alpha.u50 = plot.alpha.u50, 
	plot.alpha.l50 = plot.alpha.l50, plot.alpha.u68 = plot.alpha.u68, plot.alpha.l68 = plot.alpha.l68, plot.nfd.mean = apply(realcndd,2,mean), plot.nfd.u50 = apply(realcndd,2,quantile,0.75), 
	plot.nfd.l50 = apply(realcndd,2,quantile,0.25), plot.nfd.u68 = apply(realcndd,2,quantile,0.84), plot.nfd.l68 = apply(realcndd,2,quantile,0.16), plot.cdd.mean = apply(realcon,2,mean), 
	plot.hdd.mean = apply(realhet,2,mean))
sp.info2 = data.frame(sp.info[order(sp.info$sp),], sp.nfd.mean = apply(sp.nfd,2,mean), sp.nfdelev.mean = mean(cnddelev.m2ests), 
	sp.cdd.mean = apply(sp.cdd,2,mean), sp.cddelev.mean = mean(cddelev.m2ests), 
	sp.hdd.mean = apply(sp.hdd,2,mean), sp.hddelev.mean = mean(hddelev.m2ests))
load("HJA_CNDD_Analyses_Species_Colors_for_figures.RData")
sp.info2 = merge(sp.info2, sp.col[,c("sp.name", "sp.col", "sp.pch")], by = "sp.name", all.x = T)
sp.col2 = data.frame(sp = sp.col$sp.name, sp.col = sp.col$sp.col, sp.pch = sp.col$sp.pch)
plotsp.info2 = merge(plotsp.info2, sp.col2, by = "sp", all.x = T)
meanELEV = mean(elevid); sdELEV = sd(elevid)
elev.trans = function(x) {(x * sdELEV) + meanELEV}
elev.back.trans = function(x) {(x - meanELEV) / sdELEV}







pdf(paste("HJA_",dbhtest,"cmDBH_Growth_CNDD-HNDD_BAYES_20210524.pdf",sep=""), height = 5, width = 5, useDingbats=FALSE)
par(pty="s")
# Plot CNDD-HNDD estiamtes across plots and species (posterior means)
plot(elev.trans(plotsp.info2$plotELEV), plotsp.info2$plot.nfd.mean, cex.lab = 1.2, 
#	ylim=range(-0.26,0.05), 
	xlab = "Elevation", ylab = "", 
	pch=19, las=1, main = paste("CNDD in Annual Growth (", dbhtest," cm DBH trees)",sep=""), type = "n", cex.axis = 1.2)
mtext("Change in growth (cm / yr) from CNDD", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
elevseq = seq(min(ELEV),max(ELEV),length=1000)
upper = c()
for(i in 1:1000) {upper[i] = quantile((cndd.m2ests+(cnddelev.m2ests*elevseq[i])),c(0.95))}
lower = c()
for(i in 1:1000) {lower[i] = quantile((cndd.m2ests+(cnddelev.m2ests*elevseq[i])),c(0.05))}
polygon(x = c(elev.trans(elevseq), rev(elev.trans(elevseq))), y = c(upper, rev(lower)),
        col =  adjustcolor("gray45", alpha.f = 0.15), border = NA)
set.seed(314)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info2[which(plotsp.info2$sp == sp.info2$sp.name[i]),]
#jitterELEV = elev.trans(plot.subset$plotELEV)
jitterELEV = jitter(elev.trans(plot.subset$plotELEV), amount = 5)
if(nrow(plot.subset) > 1) {
curve((sp.info2$sp.nfd.mean[i] + (sp.info2$sp.nfdelev.mean[i] * elev.back.trans(x))), lwd = 2, col = as.character(sp.info2$sp.col[i]), add = T, 
	xlim = range(elev.trans(plot.subset$plotELEV)))}
#segments(jitterELEV, plot.subset$plot.nfd.l50, jitterELEV, plot.subset$plot.nfd.u50, lwd=0.5, col=as.character(plot.subset$sp.col))
points(jitterELEV, plot.subset$plot.nfd.mean, col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)}
curve((mean(cndd.m2ests) + (mean(cnddelev.m2ests) * elev.back.trans(x))), lwd = 3, col = "black", add = T, xlim = range(elev.trans(plotsp.info2$plotELEV)))
rp = vector('expression',1)
rp[2] = substitute(expression(italic(p) == MYOTHERVALUE), list(MYOTHERVALUE = format(round(sum(cnddelev.m2ests < 0) / length(cnddelev.m2ests),3), nsmall = 3)))[2]
legend("bottomright", legend = rp, bty = "n", cex = 1)

dev.off()





pdf(paste("HJA_",dbhtest,"cmDBH_Growth_MeanPhi_BAYES_meanconspp_meanheterospp_20210524.pdf",sep=""), height = 5, width = 5, useDingbats=FALSE)
par(pty="s")
# Plot Growth estiamtes across plots and species (posterior means)
plot(elev.trans(plotsp.info2$plotELEV), plotsp.info2$plot.alpha.mean, cex.lab = 1.2, 
	xlab = "Elevation", ylab = "",
	pch=19, las=1, main = paste("Standardized Annual Growth (", dbhtest," cm DBH trees)",sep=""), type = "n", cex.axis = 1.2)
mtext("Annual growth rate (cm / yr)", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
set.seed(314)
elevseq = seq(min(ELEV),max(ELEV),length=1000)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info2[which(plotsp.info2$sp == sp.info2$sp.name[i]),]
jitterELEV = jitter(elev.trans(plot.subset$plotELEV), amount = 5)
lines(elev.trans(elevseq)[which(elev.trans(elevseq) > range(elev.trans(plot.subset$plotELEV))[1] & elev.trans(elevseq) < range(elev.trans(plot.subset$plotELEV))[2])],
	sp.alpha.mean[which(elev.trans(elevseq) > range(elev.trans(plot.subset$plotELEV))[1] & elev.trans(elevseq) < range(elev.trans(plot.subset$plotELEV))[2]),i], lwd = 2, col = as.character(sp.info2$sp.col[i]))
#segments(elev.trans(plot.subset$plotELEV), plot.subset$plot.alpha.l50, elev.trans(plot.subset$plotELEV), plot.subset$plot.alpha.u50, lwd=0.5, col=as.character(plot.subset$sp.col))
points(jitterELEV, plot.subset$plot.alpha.mean, col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)
}
lines(elev.trans(elevseq),temp.mean, lwd = 3, col = "black")
rp = vector('expression',1)
rp[2] = substitute(expression(italic(p) == MYOTHERVALUE), list(MYOTHERVALUE = format(round(sum(alt.m > 0) / length(alt.m),3), nsmall = 3)))[2]
legend("topright", legend = rp, bty = "n", cex = 1, adj = c(0.1,-0.4))

dev.off()





mean(c(mean(apply(plot.alpha.real[,which(plotsp.info2$plot == "RS20")],2,mean)),
mean(apply(plot.alpha.real[,which(plotsp.info2$plot == "RS38")],2,mean)),
mean(apply(plot.alpha.real[,which(plotsp.info2$plot == "RS02")],2,mean)),
mean(apply(plot.alpha.real[,which(plotsp.info2$plot == "RS01")],2,mean)),
mean(apply(plot.alpha.real[,which(plotsp.info2$plot == "RS17")],2,mean)),
mean(apply(plot.alpha.real[,which(plotsp.info2$plot == "RS08")],2,mean)),
mean(plot.alpha.real[,which(plotsp.info2$plot == "RS07")])))








pdf(paste("HJA_",dbhtest,"cmDBH_Growth_CDD_BAYES_20210524.pdf",sep=""), height = 5, width = 5, useDingbats=FALSE)
par(pty="s")
# Plot CNDD-HNDD estiamtes across plots and species (posterior means)
plot(elev.trans(plotsp.info2$plotELEV), plotsp.info2$plot.cdd.mean, cex.lab = 1.2, 
	ylim=c(range(plotsp.info2$plot.cdd.mean,plotsp.info2$plot.hdd.mean)), 
	xlab = "Elevation", ylab = "", 
	pch=19, las=1, main = paste("CDD in Annual Growth (", dbhtest," cm DBH trees)",sep=""), type = "n", cex.axis = 1.2)
mtext("Change in growth from CDD", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
elevseq = seq(min(ELEV),max(ELEV),length=1000)
upper = c()
for(i in 1:1000) {upper[i] = quantile((cdd.m2ests+(cddelev.m2ests*elevseq[i])),c(0.95))}
lower = c()
for(i in 1:1000) {lower[i] = quantile((cdd.m2ests+(cddelev.m2ests*elevseq[i])),c(0.05))}
polygon(x = c(elev.trans(elevseq), rev(elev.trans(elevseq))), y = c(upper, rev(lower)),
        col =  adjustcolor("gray45", alpha.f = 0.15), border = NA)
set.seed(314)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info2[which(plotsp.info2$sp == sp.info2$sp.name[i]),]
#jitterELEV = elev.trans(plot.subset$plotELEV)
jitterELEV = jitter(elev.trans(plot.subset$plotELEV), amount = 5)
if(nrow(plot.subset) > 1) {
curve((sp.info2$sp.cdd.mean[i] + (sp.info2$sp.cddelev.mean[i] * elev.back.trans(x))), lwd = 2, col = as.character(sp.info2$sp.col[i]), add = T, 
	xlim = range(elev.trans(plot.subset$plotELEV)))}
points(jitterELEV, plot.subset$plot.cdd.mean, col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)}
curve((mean(cdd.m2ests) + (mean(cddelev.m2ests) * elev.back.trans(x))), lwd = 3, col = "black", add = T, xlim = range(elev.trans(plotsp.info2$plotELEV)))
rp = vector('expression',1)
rp[2] = substitute(expression(italic(p) == MYOTHERVALUE), list(MYOTHERVALUE = format(round(sum(cddelev.m2ests < 0) / length(cddelev.m2ests),3), nsmall = 3)))[2]
legend("bottomright", legend = rp, bty = "n", cex = 1)

dev.off()




pdf(paste("HJA_",dbhtest,"cmDBH_Growth_HDD_BAYES_20210524.pdf",sep=""), height = 5, width = 5, useDingbats=FALSE)
par(pty="s")
# Plot CNDD-HNDD estiamtes across plots and species (posterior means)
plot(elev.trans(plotsp.info2$plotELEV), plotsp.info2$plot.hdd.mean, cex.lab = 1.2, 
	ylim=c(range(plotsp.info2$plot.cdd.mean,plotsp.info2$plot.hdd.mean)), 
	xlab = "Elevation", ylab = "", 
	pch=19, las=1, main = paste("HDD in Annual Growth (", dbhtest," cm DBH trees)",sep=""), type = "n", cex.axis = 1.2)
mtext("Change in growth from HDD", side = 2, line = 4, cex = 1.2)
abline(h = 0, lty = 2)
elevseq = seq(min(ELEV),max(ELEV),length=1000)
upper = c()
for(i in 1:1000) {upper[i] = quantile((hdd.m2ests+(hddelev.m2ests*elevseq[i])),c(0.95))}
lower = c()
for(i in 1:1000) {lower[i] = quantile((hdd.m2ests+(hddelev.m2ests*elevseq[i])),c(0.05))}
polygon(x = c(elev.trans(elevseq), rev(elev.trans(elevseq))), y = c(upper, rev(lower)),
        col =  adjustcolor("gray45", alpha.f = 0.15), border = NA)
set.seed(314)
for(i in 1:nrow(sp.info2)) {
plot.subset = plotsp.info2[which(plotsp.info2$sp == sp.info2$sp.name[i]),]
#jitterELEV = elev.trans(plot.subset$plotELEV)
jitterELEV = jitter(elev.trans(plot.subset$plotELEV), amount = 5)
if(nrow(plot.subset) > 1) {
curve((sp.info2$sp.hdd.mean[i] + (sp.info2$sp.hddelev.mean[i] * elev.back.trans(x))), lwd = 2, col = as.character(sp.info2$sp.col[i]), add = T, 
	xlim = range(elev.trans(plot.subset$plotELEV)))}
points(jitterELEV, plot.subset$plot.hdd.mean, col=adjustcolor(as.character(plot.subset$sp.col), alpha.f = 0.80), pch = plot.subset$sp.pch)}
curve((mean(hdd.m2ests) + (mean(hddelev.m2ests) * elev.back.trans(x))), lwd = 3, col = "black", add = T, xlim = range(elev.trans(plotsp.info2$plotELEV)))
rp = vector('expression',1)
rp[2] = substitute(expression(italic(p) == MYOTHERVALUE), list(MYOTHERVALUE = format(round(sum(hddelev.m2ests < 0) / length(hddelev.m2ests),3), nsmall = 3)))[2]
legend("bottomright", legend = rp, bty = "n", cex = 1)

dev.off()












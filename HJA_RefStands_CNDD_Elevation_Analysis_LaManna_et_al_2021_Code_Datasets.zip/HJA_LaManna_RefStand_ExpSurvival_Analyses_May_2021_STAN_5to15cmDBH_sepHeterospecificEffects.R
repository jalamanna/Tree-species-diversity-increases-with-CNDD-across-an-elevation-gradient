### Script to perform analyses of HJA reference stand data
### Data prep for survival and growth analyses
### By: J. LaManna, reference stand data accessed: 12-23-2017

# Load necessary R packages
library(vegan)
library(doBy)
library(arm)
library(reshape)
library(nlme)
library(spatstat)
library(lme4)
library(vegan)
library(boot)
library(lmtest)
library(abind)
library(optimx)
library(nloptr)
library(parallel)
library(MASS)
library(stats)
library(DescTools)
library(purrr)
library(rstan)
library(rstanarm)
# Code for multi-core
options(mc.cores = parallel::detectCores())


# Load data for diversity analyses
load("HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData")

### IN ADDITION MAKE SURE THESE RData FILES ARE IN R WORKING DIRECTORY:
# "HJA_Species_Mean_Abundances_across_Censuses_by_Plot.RData"
# "HJA_CNDD_Analyses_Species_Colors_for_figures.RData"
# "HJA_GLMM_ExpHazard_Model_STAN.stan"


# Load other analysis functions
dist.weighted.abund.function = function(adultlocs = adultlocs, saplocs = saplocs, fix.rad = TRUE, rad = 10, alpha = 0, beta = 0.2) {
xdist = crossdist(adultlocs[,2], adultlocs[,3], saplocs[,2], saplocs[,3])
same.tree.row = which(adultlocs$id %in% saplocs$id == T)
same.tree.col = match(adultlocs$id, saplocs$id)[which(adultlocs$id %in% saplocs$id == T)]
xdist[as.matrix(data.frame(same.tree.row, same.tree.col))] = NA
weight.mat = matrix((adultlocs$dbh^alpha), nrow = nrow(xdist), ncol = ncol(xdist))
if(fix.rad) {
xdist2 = xdist
xdist2[which(xdist2 > rad)] = NA
xdist.weighted = weight.mat * exp((-beta) * xdist2) 
} else {
xdist.weighted = weight.mat * exp((-beta) * xdist2) 
}
xdist.weighted[is.na(xdist.weighted)] = 0
species.names = unique(adultlocs[,1])
adult.weights = data.frame(matrix(NA,nrow = nrow(saplocs), ncol = length(species.names)))
colnames(adult.weights) = species.names
rownames(adult.weights) = saplocs[,1]
if(nrow(adult.weights) == 0) {
return(adult.weights)
} else {
for(z in 1:ncol(adult.weights)) {
if(ncol(xdist.weighted) > 1) {
if(length(which(adultlocs[,1] == species.names[z])) > 1) {
adult.weights[,z] = colSums(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
} else {
adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
}
} else {
if(length(which(adultlocs[,1] == species.names[z])) > 1) {
adult.weights[,z] = sum(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
} else {
adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
}
}}
return(adult.weights)
}}



Add.missing.sp.names = function(test) {
names.toAdd = sp.list[which(sp.list %in% colnames(test) == F)]
test2 = data.frame(test, data.frame(matrix(0, nrow = nrow(test), ncol = length(names.toAdd))))
colnames(test2) = c(colnames(test), names.toAdd)
test2 = test2[,order(colnames(test2))]
return(test2)
}














################################################################################################################
### SMALL-TREE SURVIVAL


###########################
### BEGIN DATA PREP FUNCTION -- Remember to set values for 'beta' and 'weight.method' below, elim.radius set to 10 m

fd.adult.phi = list()
fd.sap.phi = list()
fd.adult.recruit = list()
fd.sap.recruit = list()
elim.radius = 10		# does not include trees within 10 m of plot edge (neighborhood density metrics, which have radii of 10 m, will be biased low for these individuals because we don't know what adults are outside the plot)
beta = 0.35			# Beta value determines the shape of the exponential decay of neighborhood effects across each 10-m radius neighborhood; 0 = no decay, higher values = stronger decay (Comita et al. 2010, Science)
alpha = 0.0			# alpha parameter for abundance-based neighborhood metrics, DBH^alpha / distance^beta

sp.list

for(q in 1:length(hja.survival.growth.data)) {
test = hja.survival.growth.data[[q]]
n.census = length(test)
adult.phi.list = list()
sap.phi.list = list()

for(i in 2:n.census) {
df = test[[i]]
df$ba = (((df$DBH/100)/2)^2)*pi  		# Calculate basal area for each individual
df$julian = as.numeric(julian(as.POSIXlt(df$SAMPLEDATE, format = "%Y-%m-%d")))
adult.sp = tapply(df$DBH[which(df$DBH >= 15)], as.character(df$SPECIES[which(df$DBH >= 15)]), length)
adult.sp2 = names(adult.sp)
focal = data.frame(STANDID = df$STANDID, census = df$census, YEAR = df$YEAR, DBH = df$DBH, quad = df$quad, canopy_class = df$CANOPY_CLASS, vigor = df$TREE_VIGOR,
	uniqueID = df$uniqueID, sp = df$SPECIES, gx = df$XCOORD, gy = df$YCOORD, status = df$TREE_STATUS, dbh_code = df$DBH_CODE, julian = df$julian, min_dbh = df$MIN_DBH, notes = df$CHECK_NOTES)
focal$sp = as.character(focal$sp)

test.var = 1
if(df$census[1] == 9 & df$STANDID[1] == "RS34") {test.var = 34}
if(df$census[1] == 9 & df$STANDID[1] == "RS38") {test.var = 38}
if(test.var == 34) {focal = focal[which(focal$gx >= 10 & focal$gx <= 190 & focal$gy >= 10 & focal$gy <= 90),]}
if(test.var == 38) {focal = focal[which(focal$gx >= 10 & focal$gx <= 165 & focal$gy >= 10 & focal$gy <= 90),]}
if(test.var == 1) {
maxcol = max(as.numeric(substr(df$quad,1,2)))
maxrow = max(as.numeric(substr(df$quad,3,4)))
mincol = min(as.numeric(substr(df$quad,1,2)))
minrow = min(as.numeric(substr(df$quad,3,4)))
focal.good = focal[which(focal$quad == 9999),]
for(k in mincol:maxcol) {
df2 = df[which(as.numeric(substr(df$quad,1,2)) == k),]
ymax = max(as.numeric(substr(df2$quad,3,4))) * 25
ymin = (min(as.numeric(substr(df2$quad,3,4))) - 1) * 25
focal.good = rbind(focal.good, focal[which(as.numeric(substr(focal$quad,1,2)) == k & focal$gy >= (ymin + elim.radius) & focal$gy <= (ymax - elim.radius)),])
}
focal.good2 = focal.good[which(focal.good$quad == 9999),]
for(k in minrow:maxrow) {
df2 = df[which(as.numeric(substr(df$quad,3,4)) == k),]
xmax = max(as.numeric(substr(df2$quad,1,2))) * 25
xmin = (min(as.numeric(substr(df2$quad,1,2))) - 1) * 25
focal.good2 = rbind(focal.good2, focal.good[which(as.numeric(substr(focal.good$quad,3,4)) == k & focal.good$gx >= (xmin + elim.radius) & focal.good$gx <= (xmax - elim.radius)),])
}

focal = focal.good2
focal$sp = as.character(focal$sp)
if(nrow(focal) == 0) {print(paste("ERROR: No individuals within plot buffer!", "STAND", q, "census", i)); next}
if(focal$STANDID[1] == "RS01" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 10 & focal$gx <= 40 & focal$gy >= 10 & focal$gy <= 40),]}
if(focal$STANDID[1] == "RS02" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 35 & focal$gx <= 65 & focal$gy >= 35 & focal$gy <= 65),]}
if(focal$STANDID[1] == "RS03" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 60 & focal$gx <= 90 & focal$gy >= 60 & focal$gy <= 90),]}
}
focal$sp = as.character(focal$sp)

# plot(df$XCOORD,df$YCOORD,asp=1)
# points(focal$gx,focal$gy,pch=19,col="red")
# points(focal.good2$gx,focal.good2$gy,pch=19,col="purple")

df.prev = test[[i-1]]
df.prev = df.prev[which(df.prev$TREE_STATUS %in% c(6,9) == F),]
df.prev$julian = as.numeric(julian(as.POSIXlt(df.prev$SAMPLEDATE, format = "%Y-%m-%d")))
focal.prev.time = df.prev
if(df$census[1] == 9 & df$STANDID[1] %in% c("RS34", "RS38") == T) {
	focal.prev.time$gx = focal.prev.time$XCOORD
	focal.prev.time$gy = focal.prev.time$YCOORD
	focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$uniqueID %in% focal$uniqueID == T),]
} else {
maxcol = max(as.numeric(substr(df.prev$quad,1,2)))
maxrow = max(as.numeric(substr(df.prev$quad,3,4)))
mincol = min(as.numeric(substr(df.prev$quad,1,2)))
minrow = min(as.numeric(substr(df.prev$quad,3,4)))
focal.prev.time$gx = focal.prev.time$XCOORD
focal.prev.time$gy = focal.prev.time$YCOORD
focal.prev.time.good = focal.prev.time[which(focal.prev.time$quad == 9999),]
for(k in mincol:maxcol) {
df.prev2 = df.prev[which(as.numeric(substr(df.prev$quad,1,2)) == k),]
ymax = max(as.numeric(substr(df.prev2$quad,3,4))) * 25
ymin = (min(as.numeric(substr(df.prev2$quad,3,4))) - 1) * 25
focal.prev.time.good = rbind(focal.prev.time.good, focal.prev.time[which(as.numeric(substr(focal.prev.time$quad,1,2)) == k & focal.prev.time$gy >= (ymin + elim.radius) & focal.prev.time$gy <= (ymax - elim.radius)),])
}
focal.prev.time.good2 = focal.prev.time.good[which(focal.prev.time.good$quad == 9999),]
for(k in minrow:maxrow) {
df.prev2 = df.prev[which(as.numeric(substr(df.prev$quad,3,4)) == k),]
xmax = max(as.numeric(substr(df.prev2$quad,1,2))) * 25
xmin = (min(as.numeric(substr(df.prev2$quad,1,2))) - 1) * 25
focal.prev.time.good2 = rbind(focal.prev.time.good2, focal.prev.time.good[which(as.numeric(substr(focal.prev.time.good$quad,3,4)) == k & focal.prev.time.good$gx >= (xmin + elim.radius) & focal.prev.time.good$gx <= (xmax - elim.radius)),])
}
if(focal.prev.time$STANDID[1] == "RS01" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 10 & focal.prev.time$gx <= 40 & focal.prev.time$gy >= 10 & focal.prev.time$gy <= 40),]}
if(focal.prev.time$STANDID[1] == "RS02" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 35 & focal.prev.time$gx <= 65 & focal.prev.time$gy >= 35 & focal.prev.time$gy <= 65),]}
if(focal.prev.time$STANDID[1] == "RS03" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 60 & focal.prev.time$gx <= 90 & focal.prev.time$gy >= 60 & focal.prev.time$gy <= 90),]}
}

# plot(df.prev$XCOORD,df.prev$YCOORD,asp=1)
# points(focal.prev.time$gx,focal.prev.time$gy,pch=19,col="red")
# points(focal.prev.time.good2$gx,focal.prev.time.good2$gy,pch=19,col="purple")

focal.prev.time = focal.prev.time.good2[,c("uniqueID", "DBH", "SPECIES", "YEAR", "gx", "gy", "STANDID", "quad", "TREE_STATUS", "julian", "DBH_CODE", "CANOPY_CLASS", "TREE_VIGOR", "MIN_DBH")]
names(focal.prev.time) = c("uniqueID", "DBH_prev", "sp", "YEAR_prev", "gx_prev", "gy_prev", "STANDID_prev", "quad_prev", "status_prev", "julian_prev", "dbh_code_prev", "canopy_class_prev", "vigor_prev", "min_dbh_prev")
focal.prev.time$sp = as.character(focal.prev.time$sp)
focal2 = merge(focal, focal.prev.time, by = c("uniqueID", "sp"), all = T)
focal2$growth = focal2$DBH - focal2$DBH_prev
focal2$numyr = (focal2$julian - focal2$julian_prev) / 365.25
focal2$growth.per.yr = focal2$growth / focal2$numyr
focal2$radial.growth.per.yr = (log(focal2$DBH/focal2$DBH_prev)) / focal2$numyr		# Relative Growth Rate per Wright et al. 2018 Ecology

# plot(df$XCOORD,df$YCOORD,asp=1)
# points(focal2$gx,focal2$gy,pch=19,col="red")
# points(focal.good2$gx,focal.good2$gy,pch=19,col="purple")

# Remove interior plot corners that are within 10 m of plot boundary (not captured in preceding code)
if(focal2$STANDID[1] == "RS01") {if(nrow(focal2[which(focal2$gx > 40 & focal2$gx < 50 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 40 & focal2$gx < 50 & focal2$gy > 50 & focal2$gy < 60),]}}
if(focal2$STANDID[1] == "RS03") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 40 & focal2$gy < 50),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 40 & focal2$gy < 50),]}}
if(focal2$STANDID[1] == "RS03") {if(nrow(focal2[which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 40 & focal2$gy < 50),]) > 0) {focal2 = focal2[-which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 40 & focal2$gy < 50),]}}
if(focal2$STANDID[1] == "RS23") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 50 & focal2$gy < 60),]}}
if(focal2$STANDID[1] == "RS23") {if(nrow(focal2[which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 50 & focal2$gy < 60),]}}
if(focal2$STANDID[1] == "RS38") {if(nrow(focal2[which(focal2$gx > 25 & focal2$gx < 35 & focal2$gy > 90 & focal2$gy < 100),]) > 0) {focal2 = focal2[-which(focal2$gx > 25 & focal2$gx < 35 & focal2$gy > 90 & focal2$gy < 100),]}}
if(focal2$STANDID[1] == "RS38") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 115 & focal2$gy < 125),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 115 & focal2$gy < 125),]}}


focal2$phi = c(1)
focal2$phi[is.na(focal2$DBH)] = 0
focal2$phi[is.na(focal2$DBH_prev)] = NA
focal2$gx[is.na(focal2$gx)] = focal2$gx_prev[is.na(focal2$gx)]
focal2$gy[is.na(focal2$gy)] = focal2$gy_prev[is.na(focal2$gy)]
focal2$quad = as.character(focal2$quad)
focal2$quad_prev = as.character(focal2$quad_prev)
focal2$STANDID = as.character(focal2$STANDID)
focal2$STANDID_prev = as.character(focal2$STANDID_prev)
focal2$quad[is.na(focal2$quad)] = focal2$quad_prev[is.na(focal2$quad)]
focal2$STANDID[is.na(focal2$STANDID)] = focal2$STANDID_prev[is.na(focal2$STANDID)]
focal2$census[is.na(focal2$census)] = c(unique(focal2$census[!is.na(focal2$YEAR)]))
focal2$YEAR[is.na(focal2$YEAR)] = c(unique(focal2$YEAR[!is.na(focal2$DBH)]))

adults = df[which(df$DBH >= 15),]
adults = adults[which(adults$TREE_STATUS %in% c(6,9) == F),]
adults.prev = df.prev[which(df.prev$DBH >= 15),]
adults.prev = adults.prev[which(adults.prev$TREE_STATUS %in% c(6,9) == F),]
adultlocs = data.frame(sp = adults$SPECIES, gx = adults$XCOORD, gy = adults$YCOORD, id = adults$uniqueID, dbh = adults$DBH)
adultlocs.prev = data.frame(sp = adults.prev$SPECIES, gx = adults.prev$XCOORD, gy = adults.prev$YCOORD, id = adults.prev$uniqueID, dbh = adults.prev$DBH)
unique.quads = unique(df$quad)
quad.gx = c()
quad.gy = c()
for(z in 1:length(unique.quads)) {
quad.gx[z] = (25*as.numeric(substr(unique.quads[z],1,2))-12.5)
quad.gy[z] = (25*as.numeric(substr(unique.quads[z],3,4))-12.5)
}
quadlocs = data.frame(id = unique.quads, gx = quad.gx, gy = quad.gy)
quad.weights.prev = dist.weighted.abund.function(adultlocs = adultlocs.prev, saplocs = quadlocs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
quad.weights2.prev = Add.missing.sp.names(quad.weights.prev)
if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
	quad.weights.combined = quad.weights2.prev
} else {
	quad.weights = dist.weighted.abund.function(adultlocs = adultlocs, saplocs = quadlocs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
	quad.weights2 = Add.missing.sp.names(quad.weights)
	quad.weights.combined = (quad.weights2 + quad.weights2.prev) / 2
}

adult.phi = focal2[which(focal2$DBH_prev >= 15),]
sap.phi = focal2[which(focal2$DBH_prev < 15),]

if(nrow(adult.phi) > 0) {
adult.phi$order = c(1:nrow(adult.phi))
adult.phi = adult.phi[order(adult.phi$sp),]
adult.phi.locs = data.frame(id = adult.phi$uniqueID, gx = adult.phi$gx, gy = adult.phi$gy)
adult.phi.weights.prev = dist.weighted.abund.function(adultlocs = adultlocs.prev, saplocs = adult.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
adult.phi.weights2.prev = Add.missing.sp.names(adult.phi.weights.prev)
if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
	adult.phi.weights.combined = adult.phi.weights2.prev
} else {
adult.phi.weights = dist.weighted.abund.function(adultlocs = adultlocs, saplocs = adult.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
adult.phi.weights2 = Add.missing.sp.names(adult.phi.weights)
adult.phi.weights.combined = (adult.phi.weights2 + adult.phi.weights2.prev) / 2
}
adult.phi = data.frame(adult.phi, adult.phi.weights.combined)
adult.phi = adult.phi[order(adult.phi$order),]
adult.phi.list[[i-1]] = adult.phi
}
if(nrow(sap.phi) > 0) {
sap.phi$order = c(1:nrow(sap.phi))
sap.phi = sap.phi[order(sap.phi$sp),]
sap.phi.locs = data.frame(id = sap.phi$uniqueID, gx = sap.phi$gx, gy = sap.phi$gy)
sap.phi.weights.prev = dist.weighted.abund.function(adultlocs = adultlocs.prev, saplocs = sap.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
sap.phi.weights2.prev = Add.missing.sp.names(sap.phi.weights.prev)
if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
	sap.phi.weights.combined = sap.phi.weights2.prev
} else {
sap.phi.weights = dist.weighted.abund.function(adultlocs = adultlocs, saplocs = sap.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
sap.phi.weights2 = Add.missing.sp.names(sap.phi.weights)
sap.phi.weights.combined = (sap.phi.weights2 + sap.phi.weights2.prev) / 2
}
sap.phi = data.frame(sap.phi, sap.phi.weights.combined)
sap.phi = sap.phi[order(sap.phi$order),]
sap.phi.list[[i-1]] = sap.phi
}
}
if(length(adult.phi.list) > 0) {
adult.phi.list = adult.phi.list[which(lapply(adult.phi.list, function(x) {nrow(x) > 0}) == T)]
adult.phi2 = do.call('rbind', adult.phi.list)
adult.phi2$yr = adult.phi2$YEAR - 2000
fd.adult.phi[[q]] = adult.phi2
}
if(length(sap.phi.list) > 0) {
sap.phi.list = sap.phi.list[which(lapply(sap.phi.list, function(x) {nrow(x) > 0}) == T)]
sap.phi2 = do.call('rbind', sap.phi.list)
sap.phi2$yr = sap.phi2$YEAR - 2000
fd.sap.phi[[q]] = sap.phi2
}
}




fam.list=c("Abies", "Abies", "Abies", "Angio", "Angio", "Angio", "Angio", "CupressTax", "Angio", "Pinoid", "Pinoid", "Angio", "Pinoid", "Angio", "Angio", "CupressTax", "CupressTax", "Tsuga", "Tsuga")
families = data.frame(sp = sp.list, fam = fam.list)


########################################
## Prepare small-tree data for analysis (selected beta value = 0.2, stem abundance selected as metric of neighborhood density)
yr.value = 2008
fd.sap.phi4 = do.call('rbind', fd.sap.phi)
fd.sap.phi5 = merge(fd.sap.phi4, standclimate, by = "STANDID", all.x = T)
fd.sap.phi5$yr2 = fd.sap.phi5$YEAR - yr.value
fd.sap.phi5$conspp = c(NA)
fd.sap.phi5$confam = c(NA)
fd.sap.phi5$allspp = c(NA)
fd.sap.phi5$heterofam = c(NA)
fd.sap.phi5$heterospp = c(NA)
fd.sap.phi5 = merge(fd.sap.phi5, families, by = "sp", all.x = T)
adult.cols = which(colnames(fd.sap.phi5) %in% sp.list == T)
for(i in 1:nrow(fd.sap.phi5)) {
fd.sap.phi5$conspp[i] = fd.sap.phi5[i,which(colnames(fd.sap.phi5) == fd.sap.phi5$sp[i])]
fd.sap.phi5$allspp[i] = sum(fd.sap.phi5[i,adult.cols])
fd.sap.phi5$confam[i] = sum(fd.sap.phi5[i,adult.cols[which(colnames(fd.sap.phi5[,adult.cols]) %in% families$sp[which(families$fam == fd.sap.phi5$fam[i])])]]) - fd.sap.phi5$conspp[i]
fd.sap.phi5$heterofam[i] = fd.sap.phi5$allspp[i] - fd.sap.phi5$conspp[i] - fd.sap.phi5$confam[i]
fd.sap.phi5$heterospp[i] = sum(fd.sap.phi5[i,adult.cols[which(colnames(fd.sap.phi5[,adult.cols]) != fd.sap.phi5$sp[i])]])
}
fd.sap.phi6 = fd.sap.phi5[which(fd.sap.phi5$census < 9),]
fd.sap.phi6$plotcen = as.numeric(factor(as.character(factor(as.character(fd.sap.phi6$STANDID)):factor(as.character(fd.sap.phi6$census)))))
fd.sap.phi7 = split(fd.sap.phi6, fd.sap.phi6$plotcen)
sap.census.intervals = unlist(lapply(fd.sap.phi7,function(x) {(mean(x$julian[which(x$YEAR == max(x$YEAR))]) - mean(x$julian_prev[which(x$YEAR == max(x$YEAR))]))/365.25}))
sap.census.intervals = data.frame(census.interval = sap.census.intervals, plotcen = names(sap.census.intervals))
sap.census.intervals$cenyr = unlist(lapply(fd.sap.phi7,function(x) {max(x$YEAR)}))
fd.sap.phi6 = merge(fd.sap.phi6, sap.census.intervals, by = "plotcen", all.x = T)














###### Analysis for small-tree survival

d = fd.sap.phi6[order(fd.sap.phi6$uniqueID, fd.sap.phi6$census),]
dlist = split(d, as.character(d$uniqueID))
for(i in 1:length(dlist)) {dlist[[i]]$tinterval = c(1:nrow(dlist[[i]]))}
d = do.call('rbind', dlist)
hazard = 1 - d$phi
lgexposure = log(d$numyr)
surv = d$phi
d$ID = as.character(d$uniqueID)
tinterval = d$tinterval

uniID = as.numeric(factor(d$uniqueID))
consppid = tapply(d$conspp, uniID, mean)
heterosppid = tapply(d$heterospp, uniID, mean)

conhetero4 = c(consppid^(0.4), heterosppid^(0.4))
rtconspp4 = ((d$conspp^(0.4)) - mean(conhetero4)) / sd(conhetero4)
rtconfam4 = ((d$confam^(0.4)) - mean(conhetero4)) / sd(conhetero4)
rtheterospp4 = ((d$heterospp^(0.4)) - mean(conhetero4)) / sd(conhetero4)
rtheterofam4 = ((d$heterofam^(0.4)) - mean(conhetero4)) / sd(conhetero4)


elevid = tapply(d$ELEVATION, uniID, mean)
dbhid = tapply(d$DBH_prev, uniID, mean)
yrid = tapply(d$julian_prev/365.25, uniID, mean)
ELEV = (d$ELEVATION - mean(elevid)) / sd(elevid)
dbh = (d$DBH_prev - mean(dbhid)) / sd(dbhid)
yr = ((d$julian_prev/365.25) - mean(yrid)) / sd(yrid)
yr2 = yr^2
census = as.numeric(as.character(factor(as.character(d$census)))) - 1
sp = as.numeric(factor(as.character(d$sp)))
sp.info = unique(data.frame(sp.name = d$sp, sp = sp))
plotsp = as.numeric(factor(as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID)))))
plotsp.info = unique(data.frame(sp = d$sp, plot = d$STANDID, combo = as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID))), plotELEV = ELEV, plotsp = plotsp))
plotcen = d$plotcen
plotcen.info = unique(data.frame(yr = d$census, plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID)):factor(as.character(d$census))), plotELEV = ELEV, plotcen = plotcen))
n.census = length(unique(census))
n.ID = length(unique(uniID))
n = nrow(d)
spINplot = plotsp.info$sp[order(plotsp.info$plotsp)]
plotELEV = plotsp.info$plotELEV[order(plotsp.info$plotsp)]
plot = as.numeric(as.factor(d$STANDID))
prevyr = d$julian_prev/365.25
firstyr = tapply(d$julian_prev/365.25, uniID, min)[uniID]
texp = tapply(exp(lgexposure), uniID, sum)[uniID]
totalexp = (prevyr - firstyr) + exp(lgexposure)
totalexp[tinterval] = firstyr[tinterval] + exp(lgexposure[tinterval])
totalexp[which(totalexp > texp)] = texp[which(totalexp > texp)]



sap.off.abs.phi.m4b = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + rtconspp4 + rtconfam4 + rtheterofam4 + ELEV + ELEV:rtconspp4 + ELEV:rtconfam4 + ELEV:rtheterofam4 + dbh:rtconspp4 + dbh:rtconfam4 + dbh:rtheterofam4 +  
	(rtconspp4 + rtconfam4 + rtheterofam4|sp) + (rtconspp4 + rtconfam4 + rtheterofam4|plotsp) + (1|plotcen),  
	family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(sap.off.abs.phi.m4b)


sum(((predict(sap.off.abs.phi.m4b,type = "link")-lgexposure) * hazard) - exp(predict(sap.off.abs.phi.m4b,type = "link")))







######################################
### GOODNESS OF FIT TESTS

# Residual plots

m1 = sap.off.abs.phi.m4b
conspp = rtconspp4
heterospp = rtheterospp4
cumhaz = exp(predict(m1,type = "link"))
insthaz = exp(predict(m1,type = "link") - lgexposure)
chid = c()
mres = c()
hazid = c()
consppid = c()
heterosppid = c()
dbhid = c()
spid = c()
expid = c()
elevid = c()
plotspid = c()
plotcenid = c()
cenid = c()
yrid = c()
lasthazid = c()
for(i in 1:n.ID) {
  chid[i] = sum(cumhaz[uniID == i])
  hazid[i] = max(hazard[uniID == i])
  lasthazid[i] = insthaz[uniID == i][which(census[uniID == i] == max(census[uniID == i]))]
  mres[i] = max(hazard[uniID == i]) - chid[i]
  consppid[i] = mean(conspp[uniID == i])
  heterosppid[i] = mean(heterospp[uniID == i])
  dbhid[i] = min(dbh[uniID == i])
  elevid[i] = mean(ELEV[uniID == i])
  spid[i] = (sp[uniID == i])[1]
  plotspid[i] = (plotsp[uniID == i])[1]
  yrid[i] = (yr[uniID == i])[1]
  plotcenid[i] = (plotcen[uniID == i])[1]
  cenid[i] = min(census[uniID == i])
  expid[i] = sum(exp(lgexposure)[uniID == i])
}
dres = sqrt(2)*sqrt(-mres - (hazid * log(hazid - mres)))
dres[which(mres<0)] = dres[which(mres<0)]*-1


plot(consppid,dres, col = "blue"); points(consppid[hazid==1],dres[hazid==1], col="red"); abline(h=0,lty=2)
plot(heterosppid,dres, col = "blue"); points(heterosppid[hazid==1],dres[hazid==1], col="red"); abline(h=0,lty=2)
plot(dbhid,dres, col = "blue"); points(dbhid[hazid==1],dres[hazid==1], col="red"); abline(h=0,lty=2)
plot(elevid,dres, col = "blue"); points(elevid[hazid==1],dres[hazid==1], col="red"); abline(h=0,lty=2)
plot(plotspid,dres, col = "blue"); points(plotspid[hazid==1],dres[hazid==1], col="red"); abline(h=0,lty=2)
plot(plotcenid,dres, col = "blue"); points(plotcenid[hazid==1],dres[hazid==1], col="red"); abline(h=0,lty=2)
plot(spid,dres, col = "blue"); points(spid[hazid==1],dres[hazid==1], col="red"); abline(h=0,lty=2)
plot(yrid,dres, col = "blue"); points(yrid[hazid==1],dres[hazid==1], col="red"); abline(h=0,lty=2)
plot(cenid,dres, col = "blue"); points(cenid[hazid==1],dres[hazid==1], col="red"); abline(h=0,lty=2)






# Predicted values with expected length of exposure based on length of exposure for trees that survive from the first census

hazmat = matrix(NA, nrow = n.ID, ncol = max(census))
hazmat[cbind(uniID, census)] = cumhaz
yrcensus = tapply(yr, plotcen, mean)
expcensus = tapply(lgexposure[hazard==0], plotcen[hazard==0], mean)

maxcenexp = 1
expm1 = lm(apply(hazmat[hazid==0 & cenid <= maxcenexp,],1,function(x) {sum(!is.na(x))})~exp(dbhid[hazid==0 & cenid <= maxcenexp]))
plot(dbhid[hazid==0 & cenid <= maxcenexp], jitter(apply(hazmat[hazid==0 & cenid <= maxcenexp,],1,function(x) {sum(!is.na(x))})))	#### try accounting for expected length of exposure given size at first census
x = seq(min(dbhid), max(dbhid), length=500); lines(x, coef(expm1)[1] + (coef(expm1)[2]*exp(x)))

sum(hazard*log(insthaz) - cumhaz)


for(i in 1:nrow(hazmat)) {
  if(hazid[i] == 1) {
    use = which(uniID == i)
    use2 = use[which(census[use] == max(census[use]))]
    expectedsurveys = ifelse(round(coef(expm1)[1] + (coef(expm1)[2]*exp(dbhid[i])),0) > length(use), round(coef(expm1)[1] + (coef(expm1)[2]*exp(dbhid[i])),0) - length(use), 0)
    if(expectedsurveys + max(census[uniID == i]) > 7) {expectedsurveys = 7 - max(census[uniID == i])}
    test = data.frame(sp = sp[use2], plot = plot[use2], plotsp = plotsp[use2], dbh = dbh[use2], tinterval = tinterval[use2], census = census[use2], rtconspp4 = conspp[use2], rtheterospp4 = heterospp[use2], ELEV = ELEV[use2])
    test2 = test[rep(1, times = (8 - max(census[use]))),]
    test2$tinterval = test2$tinterval[1]:(test2$tinterval[1]+(7 - max(census[use])))
    test2$census = test2$census[1]:(test2$census[1]+(7 - max(census[use])))
    for(j in 1:nrow(test2)) {test2$plotcen[j] = unique(plotcen[which(plot == test2$plot[j] & census == test2$census[j])])}
    test2$yr = yrcensus[test2$plotcen]
    test2$yr2 = test2$yr^2
    test2$yr[1] = yr[use2]
    test2$yr2[1] = yr2[use2]
    test2$lgexposure = expcensus[test2$plotcen]
    if(test2$lgexposure[1] < lgexposure[use2]) {test2$lgexposure[1] = lgexposure[use2]}
    hazmat[i,(max(census[uniID == i])):(max(census[uniID == i])+expectedsurveys)] = (exp(predict(m1, newdata = test2, type = "link"))*exp(test2$lgexposure))[1:(1+expectedsurveys)]
  }
}
predS = exp(-1*rowSums(hazmat, na.rm = T))	# Predicted survival
summary(predS)
meanhazsim = replicate(mean(rbinom(n = length(predS), size = 1, prob = predS)), n = 1000)
hist(meanhazsim); sum(meanhazsim < 1-mean(hazid)) / length(meanhazsim)
abline(v=1-mean(hazid))

sims = replicate((1-rbinom(n = length(predS), size = 1, prob = predS)), n = 1000)
summary(unlist(apply(sims, 2, function(x) {sum(x==1 & hazid==1) / sum(hazid==1)})))	# Prediction accuracy for deaths
summary(unlist(apply(sims, 2, function(x) {sum(x==0 & hazid==0) / sum(hazid==0)})))	# Prediction accuracy for survival
summary(unlist(apply(sims, 2, function(x) {(sum(x==1 & hazid==1) + sum(x==0 & hazid==0)) / length(hazid)})))	# Prediction accuracy for survival
summary(unlist(apply(sims, 2, function(x) {((sum(x==1 & hazid==1) / sum(hazid==1)) + (sum(x==0 & hazid==0) / sum(hazid==0))) / 2})))	# Prediction accuracy for survival

logliksim = replicate(sum((1-rbinom(n = length(predS), size = 1, prob = predS))*log(lasthazid) - chid), n = 1000)
sum(hazard*log(insthaz) - cumhaz)
ll.obs = sum(hazid*log(lasthazid) - chid)
hist(logliksim); abline(v = sum(hazid*log(lasthazid) - chid))
sum(logliksim < ll.obs) / length(logliksim)


















#######################################################################################
### BAYESIAN MODEL OF SAPLING SURVIVAL	

DenExp = 0.4
d = fd.sap.phi6[order(fd.sap.phi6$uniqueID, fd.sap.phi6$census),]
dlist = split(d, as.character(d$uniqueID))
for(i in 1:length(dlist)) {dlist[[i]]$tinterval = c(1:nrow(dlist[[i]]))}
d = do.call('rbind', dlist)
hazard = 1 - d$phi
lgexposure = log(d$numyr)
surv = d$phi
d$ID = as.character(d$uniqueID)
tinterval = d$tinterval

uniID = as.numeric(factor(d$uniqueID))
consppid = tapply(d$conspp, uniID, mean)
heterosppid = tapply(d$heterospp, uniID, mean)

conhetero = c(consppid^(DenExp), heterosppid^(DenExp))
conspp = ((d$conspp^(DenExp)) - mean(conhetero)) / sd(conhetero)
heterospp = ((d$heterospp^(DenExp)) - mean(conhetero)) / sd(conhetero)
heterofam = ((d$heterofam^(DenExp)) - mean(conhetero)) / sd(conhetero)
confam = ((d$confam^(DenExp)) - mean(conhetero)) / sd(conhetero)

elevid = tapply(d$ELEVATION, uniID, mean)
dbhid = tapply(d$DBH_prev, uniID, mean)
yrid = tapply(d$julian_prev/365.25, uniID, mean)
ELEV = (d$ELEVATION - mean(elevid)) / sd(elevid)
dbh = (d$DBH_prev - mean(dbhid)) / sd(dbhid)
yr = ((d$julian_prev/365.25) - mean(yrid)) / sd(yrid)
yr2 = yr^2
census = as.numeric(as.character(factor(as.character(d$census)))) - 1
sp = as.numeric(factor(as.character(d$sp)))
sp.info = unique(data.frame(sp.name = d$sp, sp = sp))
plotsp = as.numeric(factor(as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID)))))
plotsp.info = unique(data.frame(sp = d$sp, plot = d$STANDID, combo = as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID))), plotELEV = ELEV, plotsp = plotsp))
plotcen = d$plotcen
plotcen.info = unique(data.frame(yr = d$census, plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID)):factor(as.character(d$census))), plotELEV = ELEV, plotcen = plotcen))
n.census = length(unique(census))
n.ID = length(unique(uniID))
n = nrow(d)
spINplot = plotsp.info$sp[order(plotsp.info$plotsp)]
plotELEV = plotsp.info$plotELEV[order(plotsp.info$plotsp)]
plot = as.numeric(as.factor(d$STANDID))
n.plotcen = length(unique(plotcen))
tinterval2 = rep(0, times = length(tinterval)); tinterval2[which(tinterval == 2)] = 1
tinterval3 = rep(0, times = length(tinterval)); tinterval3[which(tinterval == 3)] = 1
tinterval4 = rep(0, times = length(tinterval)); tinterval4[which(tinterval == 4)] = 1
tinterval5 = rep(0, times = length(tinterval)); tinterval5[which(tinterval == 5)] = 1
tinterval6 = rep(0, times = length(tinterval)); tinterval6[which(tinterval == 6)] = 1
tinterval7 = rep(0, times = length(tinterval)); tinterval7[which(tinterval == 7)] = 1
x = cbind(rep(1,times = n), dbh, tinterval2, tinterval3, tinterval4, tinterval5, tinterval6, tinterval7, yr, yr2, conspp, confam, heterofam, ELEV, conspp*ELEV, confam*ELEV, heterofam*ELEV, conspp*dbh, confam*dbh, heterofam*dbh)	
K = ncol(x)
PX = cbind(rep(1,times = n), conspp, confam, heterofam)
PK = ncol(PX)
PJ = length(unique(plotsp))
SX = cbind(rep(1,times = n), conspp, confam, heterofam)
SK = ncol(SX)
SJ = length(unique(sp))
spINplot = plotsp.info$sp[order(plotsp.info$plotsp)]
plotELEV = plotsp.info$plotELEV[order(plotsp.info$plotsp)]


# Bundle data
dat <- list(y = hazard, lgexposure = lgexposure, x = x, K = K, plotsp = plotsp, sp = sp, census = plotcen, nID = n.ID, uniID = uniID,
	ncensus = n.plotcen, PJ = PJ, PK = PK, PX = PX, SJ = SJ, SK = SK, SX = SX, N = n)

# LMER model with ML for ranef variance estimates (once run, comment off with #)
set.seed(314)
m1 = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + conspp + confam + heterofam + ELEV + conspp:ELEV + confam:ELEV + heterofam:ELEV + conspp:dbh + confam:dbh + heterofam:dbh + 
	(conspp + confam + heterofam|sp) + (conspp + confam + heterofam|plotsp) + (1|plotcen), family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(m1)
sum(((predict(m1,type = "link")-lgexposure) * hazard) - exp(predict(m1,type = "link")))



### Fit stan model 
# HMC Parameters
nchains = 12
postburn = 5000
burnin = 3000
its = postburn + burnin
thin = 1					
hmc_seed = 55406

# Initial values from LMER model
vc <- VarCorr(m1)
sigma_SB_lmer = as.matrix(Matrix::bdiag(vc$sp))
sigma_PB_lmer = as.matrix(Matrix::bdiag(vc$plotsp))
inits <- replicate(nchains, list(
  Pz = t(data.matrix(ranef(m1)$'plotsp')),
  PL_Omega = sigma_PB_lmer,
  Ptau_unif = runif(PK),
  Sz = t(data.matrix(ranef(m1)$'sp')),
  SL_Omega = sigma_SB_lmer,
  Stau_unif = runif(SK),
  beta = fixef(m1),
  sigma_YEAR = attr(summary(m1)$varcor$plotcen,"stddev")[[1]],
  YEAR = ranef(m1)$'plotcen'[[1]], 
  PB = data.matrix(ranef(m1)$'plotsp'), 
  sigma_PB = sigma_PB_lmer, 
  Ptau = runif(PK), 
  SB = data.matrix(ranef(m1)$'sp'), 
  sigma_SB = sigma_SB_lmer, 
  Stau = runif(SK)
), simplify = F)


# Run model
begin = Sys.time()
fit <- stan(file = "HJA_GLMM_ExpHazard_Model_STAN.stan", 				# Stan model
  data = dat,   									# named list of data
  init = inits,										# initial values for parameters
  chains = nchains,             							# number of Markov chains
  warmup = burnin,          								# number of warmup iterations per chain
  iter = its,            								# total number of iterations per chain
  cores = nchains,              							# number of cores (could use one per chain)
  thin = thin,
  seed = hmc_seed,
  control = list(adapt_delta = 0.99)
  )
end = Sys.time()
(duration = end - begin)

# save(fit, file = "HJA_5to15cmDBH_ExpHazard_Bayesian_alpha0-0_beta0-35_exp0-4_STAN_20210524_Separate_Heterospecific_Effects.RData")






divergent <- get_sampler_params(fit, inc_warmup=FALSE)
divergent2 = list()
for(i in 1:length(divergent)) {divergent2[[i]] = data.frame(div = divergent[[i]][,'divergent__'], chain = i)}
divergent = do.call('rbind', divergent2)
sum(divergent$div)
table(divergent$chain[which(divergent$div == 1)])

treedepth <- get_sampler_params(fit, inc_warmup=FALSE)
tree.depth = list()
for(i in 1:length(treedepth)) {tree.depth[[i]] = data.frame(treedepth = treedepth[[i]][,'treedepth__'], chain = i)}
tree.depth = do.call('rbind', tree.depth)
summary(tree.depth$treedepth)
table(tree.depth$treedepth)
table(tree.depth$chain[which(tree.depth$treedepth > 9)])




# HMC traceplots
traceplot(fit, pars = c("beta"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("sigma_YEAR"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("sigma_PB"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("sigma_SB"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("sigma_ID"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("PL_Omega"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("SL_Omega"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("Sz"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("Stau"), inc_warmup = TRUE, nrow = 3)
traceplot(fit, pars = c("Ptau"), inc_warmup = TRUE, nrow = 3)






# Remove divergent chains
divergent <- get_sampler_params(fit, inc_warmup=FALSE)
divergent2 = list()
for(i in 1:length(divergent)) {divergent2[[i]] = data.frame(div = divergent[[i]][,'divergent__'], chain = i)}
divergent = do.call('rbind', divergent2)
sum(divergent$div)
table(divergent$chain[which(divergent$div == 1)])
div.chains = unique(divergent$chain[which(divergent$div == 1)])
draws <- extract(fit, permuted = FALSE)
draws = draws[,which(c(1:nchains) %in% div.chains == F),] # Remove chains 2 and 5, which had divergences (only 1 divergence on each chains) 


# test for thinning interval that removes auto-correlation in chains
thin1 = 20
acf(c(draws[seq(1,postburn,by=thin1),,"beta[1]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"beta[2]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"beta[3]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"beta[4]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"beta[5]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"beta[6]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"beta[7]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_YEAR"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_PB[1,1]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_PB[2,2]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_PB[1,2]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_SB[1,1]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_SB[2,2]"]), lag.max = 100)
acf(c(draws[seq(1,postburn,by=thin1),,"sigma_SB[1,2]"]), lag.max = 100)



# Extract estimates
thin1 = 20
beta.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta")])),3,c)
SB.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB")])),3,c)
SB.m = array(SB.m, dim = c(nrow(SB.m),SJ,SK), dimnames = list(paste("it",c(1:nrow(SB.m)),sep=""),paste("sp",c(1:SJ),sep=""),paste("SB",c(1:SK),sep="")))
PB.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB")])),3,c)
PB.m = array(PB.m, dim = c(nrow(PB.m),PJ,PK), dimnames = list(paste("it",c(1:nrow(PB.m)),sep=""),paste("plotsp",c(1:PJ),sep=""),paste("PB",c(1:PK),sep="")))
census.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")])),3,c)
plotcen.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")])),3,c)
sigmaSB.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB")])),3,c)
sigmaPB.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB")])),3,c)
sigmaYR.m = c(draws[seq(1,postburn,by=thin1),,"sigma_YEAR"])

Sz.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,2) == "Sz")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "Sz"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "Sz")])),3,c)

Stau.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,4) == "Stau")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "Stau"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "Stau")])),3,c)
SL_Omega.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,8) == "SL_Omega")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "SL_Omega"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "SL_Omega")])),3,c)
(SL_Cholesky = diag(apply(Stau.m,2,mean)[5:8])%*%matrix(apply(SL_Omega.m,2,mean),nrow=4,ncol=4))
Ptau.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,4) == "Ptau")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "Ptau"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "Ptau")])),3,c)
matrix(apply(sigmaSB.m,2,mean),nrow=4,ncol=4)
cov2cor(matrix(apply(sigmaSB.m,2,mean),nrow=4,ncol=4))

PL_Omega.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,8) == "PL_Omega")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "PL_Omega"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "PL_Omega")])),3,c)
(PL_Cholesky = diag(apply(Ptau.m,2,mean)[5:8])%*%matrix(apply(PL_Omega.m,2,mean),nrow=4,ncol=4))
matrix(apply(sigmaPB.m,2,mean),nrow=4,ncol=4)
cov2cor(matrix(apply(sigmaPB.m,2,mean),nrow=4,ncol=4))

getME(m1,"theta")	# Cholesky factors from the lmer model


# Estimates
t(apply(beta.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(beta.m,2,mean)
t(apply(sigmaSB.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(sigmaSB.m,2,mean)
t(apply(sigmaPB.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(sigmaPB.m,2,mean)
quantile(sigmaYR.m^2,c(0.025,0.975,0.05,0.95,0.5)); mean(sigmaYR.m^2)





# Hazard and survival through time
interval.exposure = tapply(exp(lgexposure[hazard==0]), tinterval[hazard==0], mean)
baseline.hazard = mean(beta.m[,1]) + c(0, apply(beta.m[,3:8], 2, mean))
hazardx = c()
timex = seq(0,sum(interval.exposure), length=100)
for(i in 1:(length(timex)-1)) {hazardx[i] = baseline.hazard[which(timex[i] < cumsum(interval.exposure) & timex[i] >= (cumsum(interval.exposure) - interval.exposure))]}
hazardx[length(timex)] = baseline.hazard[length(baseline.hazard)]

plot(timex, exp(hazardx), xlab = "Time (years since entering census)", ylab = "Instantaneous hazard", main = "5-15 cm DBH Size Class")

cumhazx = c()
for(i in 1:(length(hazardx)-1)) {cumhazx[i] = exp(hazardx[i+1])*(timex[2:length(timex)] - timex[1:(length(timex)-1)])[i]}

plot(timex, c(1,exp(-cumsum(cumhazx))), ylim=c(0,1), xlab = "Time (years since entering census)", ylab = "Cumulative survival of average tree", main = "5-15 cm DBH Size Class")









# Posterior point-wise log-likelihoods

Z = length(sigmaYR.m)
fitted.m = matrix(NA,nrow=Z,ncol=n)
cumhaz.m = matrix(NA,nrow=Z,ncol=n)
predS.m = matrix(NA,nrow=Z,ncol=n.ID)
hazmat.m = list()
log_lik = matrix(NA,nrow=Z,ncol=n)
hazid = c()
dbhid = c()
cenid = c()
for(i in 1:n.ID) {
  hazid[i] = max(hazard[uniID == i])
  dbhid[i] = min(dbh[uniID == i])
  cenid[i] = min(census[uniID == i])
}
yrcensus = tapply(yr, plotcen, mean)
expcensus = log(tapply(exp(lgexposure[hazard==0]), plotcen[hazard==0], mean))
testmat = matrix(NA, nrow = n.ID, ncol = max(census))
testmat[cbind(uniID, census)] = 1
maxcenexp = 1
expm1 = lm(apply(testmat[hazid==0 & cenid <= maxcenexp,],1,function(x) {sum(!is.na(x))})~exp(dbhid[hazid==0 & cenid <= maxcenexp]))
plot(dbhid[hazid==0 & cenid <= maxcenexp], jitter(apply(testmat[hazid==0 & cenid <= maxcenexp,],1,function(x) {sum(!is.na(x))})))	#### accounting for expected length of exposure given size at first census
x1 = seq(min(dbhid), max(dbhid), length=500); lines(x1, coef(expm1)[1] + (coef(expm1)[2]*exp(x1)))

begin.time = Sys.time()
for(z in 1:Z) {
  SBbysp = matrix(NA,nrow=n,ncol=SK)
  for(i in 1:n) {SBbysp[i,] = SB.m[z,sp[i],]}
  PBbyplotsp = matrix(NA,nrow=n,ncol=PK)
  for(i in 1:n) {PBbyplotsp[i,] = PB.m[z,plotsp[i],]}
  YRbycensus = c()
  for(i in 1:n) {YRbycensus[i] = plotcen.m[z,plotcen[i]]}
  fitted.m[z,] = exp((x %*% beta.m[z,]) + rowSums(SX*SBbysp) + rowSums(PX*PBbyplotsp) + YRbycensus)
  cumhaz.m[z,] = fitted.m[z,] * exp(lgexposure)
  hazmat.m[[z]] = matrix(NA, nrow = n.ID, ncol = max(census))
  hazmat.m[[z]][cbind(uniID, census)] = cumhaz.m[z,]
  for(i in 1:nrow(hazmat.m[[z]])) {
    if(hazid[i] == 1) {
      use = which(uniID == i)
      use2 = use[which(census[use] == max(census[use]))]
      expectedsurveys = ifelse(round(coef(expm1)[1] + (coef(expm1)[2]*exp(dbhid[i])),0) > length(use), round(coef(expm1)[1] + (coef(expm1)[2]*exp(dbhid[i])),0) - length(use), 0)
      if(expectedsurveys + max(census[uniID == i]) > 7) {expectedsurveys = 7 - max(census[uniID == i])}
      test = data.frame(sp = sp[use2], plot = plot[use2], plotsp = plotsp[use2], dbh = dbh[use2], tinterval = tinterval[use2], census = census[use2], conspp = conspp[use2], confam = confam[use2], heterofam = heterofam[use2], ELEV = ELEV[use2])
      test2 = test[rep(1, times = (8 - max(census[use]))),]
      test2$tinterval = test2$tinterval[1]:(test2$tinterval[1]+(7 - max(census[use])))
      test2$census = test2$census[1]:(test2$census[1]+(7 - max(census[use])))
      for(j in 1:nrow(test2)) {test2$plotcen[j] = unique(plotcen[which(plot == test2$plot[j] & census == test2$census[j])])}
      test2$yr = yrcensus[test2$plotcen]
      test2$yr2 = test2$yr^2
      test2$yr[1] = yr[use2]
      test2$yr2[1] = yr2[use2]
      test2$lgexposure = expcensus[test2$plotcen]
      if(test2$lgexposure[1] < lgexposure[use2]) {test2$lgexposure[1] = lgexposure[use2]}
      test2$tinterval2 = c(0); test2$tinterval2[which(test2$tinterval == 2)] = 1
      test2$tinterval3 = c(0); test2$tinterval3[which(test2$tinterval == 3)] = 1
      test2$tinterval4 = c(0); test2$tinterval4[which(test2$tinterval == 4)] = 1
      test2$tinterval5 = c(0); test2$tinterval5[which(test2$tinterval == 5)] = 1
      test2$tinterval6 = c(0); test2$tinterval6[which(test2$tinterval == 6)] = 1
      test2$tinterval7 = c(0); test2$tinterval7[which(test2$tinterval == 7)] = 1
      testX = as.matrix(cbind(rep(1, times = nrow(test2)), test2[,c("dbh", "tinterval2", "tinterval3", "tinterval4", "tinterval5", "tinterval6", "tinterval7", "yr", "yr2", "conspp", "confam", "heterofam", "ELEV")], 
		test2$conspp*test2$ELEV, test2$confam*test2$ELEV, test2$heterofam*test2$ELEV, test2$conspp*test2$dbh, test2$confam*test2$dbh, test2$heterofam*test2$dbh))
      testSX = as.matrix(cbind(rep(1, times = nrow(test2)), test2[,c("conspp", "confam", "heterofam")]))
      testPX = as.matrix(cbind(rep(1, times = nrow(test2)), test2[,c("conspp", "confam", "heterofam")]))
      predicted.cumhazard = (c(exp((testX %*% beta.m[z,]) + (testSX %*% SB.m[z,test2$sp[1],]) + (testPX %*% PB.m[z,test2$plotsp[1],]) + plotcen.m[z,test2$plotcen]))*exp(test2$lgexposure))[1:(1+expectedsurveys)]
      hazmat.m[[z]][i,(max(census[uniID == i])):(max(census[uniID == i])+expectedsurveys)] = predicted.cumhazard
    }
  }
  predS.m[z,] = exp(-1*rowSums(hazmat.m[[z]], na.rm = T))		# Predicted survival
  log_lik[z,] = (log(fitted.m[z,]) * hazard) - (fitted.m[z,] * exp(lgexposure))
}
end.time = Sys.time()
dev.m = rowSums(log_lik)*-2
(duration = end.time - begin.time)




# logLik and dev at mean posterior parameters
beta.mean = apply(beta.m, 2, mean)
SB.mean = apply(SB.m,c(2,3),mean)
PB.mean = apply(PB.m,c(2,3),mean)
plotcen.mean = apply(plotcen.m, 2, mean)
  SBbysp = matrix(NA,nrow=n,ncol=SK)
  for(i in 1:n) {SBbysp[i,] = SB.mean[sp[i],]}
  PBbyplotsp = matrix(NA,nrow=n,ncol=PK)
  for(i in 1:n) {PBbyplotsp[i,] = PB.mean[plotsp[i],]}
  YRbycensus = c()
  for(i in 1:n) {YRbycensus[i] = plotcen.mean[plotcen[i]]}
fitted.meanpar = exp((x %*% beta.mean) + rowSums(SX*SBbysp) + rowSums(PX*PBbyplotsp) + YRbycensus)
cumhaz = fitted.meanpar * exp(lgexposure)
hazmat = matrix(NA, nrow = n.ID, ncol = max(census))
hazmat[cbind(uniID, census)] = cumhaz

for(i in 1:nrow(hazmat)) {
  if(hazid[i] == 1) {
    use = which(uniID == i)
    use2 = use[which(census[use] == max(census[use]))]
    expectedsurveys = ifelse(round(coef(expm1)[1] + (coef(expm1)[2]*exp(dbhid[i])),0) > length(use), round(coef(expm1)[1] + (coef(expm1)[2]*exp(dbhid[i])),0) - length(use), 0)
    if(expectedsurveys + max(census[uniID == i]) > 7) {expectedsurveys = 7 - max(census[uniID == i])}
    test = data.frame(sp = sp[use2], plot = plot[use2], plotsp = plotsp[use2], dbh = dbh[use2], tinterval = tinterval[use2], census = census[use2], conspp = conspp[use2], confam = confam[use2], heterofam = heterofam[use2], ELEV = ELEV[use2])
    test2 = test[rep(1, times = (8 - max(census[use]))),]
    test2$tinterval = test2$tinterval[1]:(test2$tinterval[1]+(7 - max(census[use])))
    test2$census = test2$census[1]:(test2$census[1]+(7 - max(census[use])))
    for(j in 1:nrow(test2)) {test2$plotcen[j] = unique(plotcen[which(plot == test2$plot[j] & census == test2$census[j])])}
    test2$yr = yrcensus[test2$plotcen]
    test2$yr2 = test2$yr^2
    test2$yr[1] = yr[use2]
    test2$yr2[1] = yr2[use2]
    test2$lgexposure = expcensus[test2$plotcen]
    if(test2$lgexposure[1] < lgexposure[use2]) {test2$lgexposure[1] = lgexposure[use2]}
    test2$tinterval2 = c(0); test2$tinterval2[which(test2$tinterval == 2)] = 1
    test2$tinterval3 = c(0); test2$tinterval3[which(test2$tinterval == 3)] = 1
    test2$tinterval4 = c(0); test2$tinterval4[which(test2$tinterval == 4)] = 1
    test2$tinterval5 = c(0); test2$tinterval5[which(test2$tinterval == 5)] = 1
    test2$tinterval6 = c(0); test2$tinterval6[which(test2$tinterval == 6)] = 1
    test2$tinterval7 = c(0); test2$tinterval7[which(test2$tinterval == 7)] = 1
    testX = as.matrix(cbind(rep(1, times = nrow(test2)), test2[,c("dbh", "tinterval2", "tinterval3", "tinterval4", "tinterval5", "tinterval6", "tinterval7", "yr", "yr2", "conspp", "confam", "heterofam", "ELEV")], 
		test2$conspp*test2$ELEV, test2$confam*test2$ELEV, test2$heterofam*test2$ELEV, test2$conspp*test2$dbh, test2$confam*test2$dbh, test2$heterofam*test2$dbh))
    testSX = as.matrix(cbind(rep(1, times = nrow(test2)), test2[,c("conspp", "confam", "heterofam")]))
    testPX = as.matrix(cbind(rep(1, times = nrow(test2)), test2[,c("conspp", "confam", "heterofam")]))
    predicted.cumhazard = (c(exp((testX %*% beta.m[z,]) + (testSX %*% SB.m[z,test2$sp[1],]) + (testPX %*% PB.m[z,test2$plotsp[1],]) + plotcen.m[z,test2$plotcen]))*exp(test2$lgexposure))[1:(1+expectedsurveys)]
    hazmat[i,(max(census[uniID == i])):(max(census[uniID == i])+expectedsurveys)] = predicted.cumhazard
  }
}
predS = exp(-1*rowSums(hazmat, na.rm = T))	# Predicted survival
summary(predS)
logLik.meanpar = (log(fitted.meanpar) * hazard) - (fitted.meanpar * exp(lgexposure))
logLik.meanpar.sum = sum(logLik.meanpar)
dev.meanpar = -2 * logLik.meanpar.sum
pD = mean(dev.m) - dev.meanpar
DIC = dev.meanpar + (2*pD)
dev.meanpar; pD; DIC

# Approximate leave-one-out fit metrics
library(loo)
begin = Sys.time()
r_eff <- relative_eff(exp(log_lik), chain_id = rep(1:11,each=250), cores = 5)
loo_1 <- loo(log_lik, r_eff = r_eff, cores = 5)
end = Sys.time()
(duration = end - begin)
print(loo_1)

# save(loo_1, file = "LOO_ExpSurvival_5to15cmDBH_confam2.RData")





## Residual plots
cumhaz = cumhaz.m
insthaz = fitted.m
chid = matrix(NA,nrow=Z,ncol=n.ID)
llid = matrix(NA,nrow=Z,ncol=n.ID)
mres = matrix(NA,nrow=Z,ncol=n.ID)
lasthazid = matrix(NA,nrow=Z,ncol=n.ID)
hazid = c()
consppid = c()
heterosppid = c()
mindbhid = c()
meanelevid = c()
plotspid = c()
firstyrid = c()
for(i in 1:n.ID) {
  if(sum(uniID == i) > 1) {
    chid[,i] = rowSums(cumhaz[,uniID == i])
    llid[,i] = rowSums(log_lik[,uniID == i])
    lasthazid[,i] = insthaz[,uniID == i][,which(census[uniID == i] == max(census[uniID == i]))]
  }
  if(sum(uniID == i) == 1) {
    chid[,i] = cumhaz[,uniID == i]
    llid[,i] = log_lik[,uniID == i]
    lasthazid[,i] = insthaz[,uniID == i]
  }
  hazid[i] = max(hazard[uniID == i])
  mres[,i] = max(hazard[uniID == i]) - chid[,i]
  consppid[i] = mean(conspp[uniID == i])
  heterosppid[i] = mean(heterospp[uniID == i])
  mindbhid[i] = min(dbh[uniID == i])
  meanelevid[i] = mean(ELEV[uniID == i])
  plotspid[i] = (plotsp[uniID == i])[1]
  firstyrid[i] = (yr[uniID == i])[1]
}
dres = matrix(NA,nrow=Z,ncol=n.ID)
for(z in 1:Z) {
  dres[z,] = sqrt(2)*sqrt(-mres[z,] - (hazid * log(hazid - mres[z,])))
  dres[z,which(mres[z,]<0)] = dres[z,which(mres[z,]<0)]*-1
}


set.seed(314)
itres = sample(Z, size=1)
par(mfrow=c(4,2))
par(mar=c(4,4,2,2))
cexptvalue = 0.7
transparencyvalue = 0.4
plot(predS.m[itres,],dres[itres,],las=1,type="n",xlab="Predicted survival probability",ylab="Deviance residuals"); points(predS.m[itres,hazid==0],dres[itres,hazid==0],cex=cexptvalue,col = adjustcolor("blue",alpha.f=transparencyvalue)); points(predS.m[itres,hazid==1],dres[itres,hazid==1],cex=cexptvalue,col=adjustcolor("red",alpha.f=transparencyvalue)); abline(h=0,lty=2)
binnedplot(predS.m[itres,],dres[itres,],nclass = round(n.ID/4,0),las=1,xlab="Predicted survival probability",ylab="Binned deviance residuals",main="",cex.pts=cexptvalue-0.2); abline(h=0,lty=2)
plot(consppid,dres[itres,],las=1,type="n",xlab="Std. local conspecific density",ylab="Deviance residuals"); points(consppid[hazid==0],dres[itres,hazid==0],cex=cexptvalue,col = adjustcolor("blue",alpha.f=transparencyvalue)); points(consppid[hazid==1],dres[itres,hazid==1],cex=cexptvalue,col=adjustcolor("red",alpha.f=transparencyvalue)); abline(h=0,lty=2)
plot(heterosppid,dres[itres,],las=1,type="n",xlab="Std. local heterospecific density",ylab="Deviance residuals"); points(heterosppid[hazid==0],dres[itres,hazid==0],cex=cexptvalue,col = adjustcolor("blue",alpha.f=transparencyvalue)); points(heterosppid[hazid==1],dres[itres,hazid==1],cex=cexptvalue,col=adjustcolor("red",alpha.f=transparencyvalue)); abline(h=0,lty=2)
plot(mindbhid,dres[itres,],las=1,type="n",xlab="Standardized initial DBH",ylab="Deviance residuals"); points(mindbhid[hazid==0],dres[itres,hazid==0],cex=cexptvalue,col = adjustcolor("blue",alpha.f=transparencyvalue)); points(mindbhid[hazid==1],dres[itres,hazid==1],cex=cexptvalue,col=adjustcolor("red",alpha.f=transparencyvalue)); abline(h=0,lty=2)
plot(meanelevid,dres[itres,],las=1,type="n",xlab="Standardized elevation",ylab="Deviance residuals"); points(meanelevid[hazid==0],dres[itres,hazid==0],cex=cexptvalue,col = adjustcolor("blue",alpha.f=transparencyvalue)); points(meanelevid[hazid==1],dres[itres,hazid==1],cex=cexptvalue,col=adjustcolor("red",alpha.f=transparencyvalue)); abline(h=0,lty=2)
plot(plotspid,dres[itres,],las=1,type="n",xlab="Plot-by-species combination",ylab="Deviance residuals"); points(plotspid[hazid==0],dres[itres,hazid==0],cex=cexptvalue,col = adjustcolor("blue",alpha.f=transparencyvalue)); points(plotspid[hazid==1],dres[itres,hazid==1],cex=cexptvalue,col=adjustcolor("red",alpha.f=transparencyvalue)); abline(h=0,lty=2)
plot(firstyrid,dres[itres,],las=1,type="n",xlab="Initial year in census (standardized)",ylab="Deviance residuals"); points(firstyrid[hazid==0],dres[itres,hazid==0],cex=cexptvalue,col = adjustcolor("blue",alpha.f=transparencyvalue)); points(firstyrid[hazid==1],dres[itres,hazid==1],cex=cexptvalue,col=adjustcolor("red",alpha.f=transparencyvalue)); abline(h=0,lty=2)







## For Posterior Predictive Check (based on all samples from the posterior parameter distributions)
rep.m = list()
sim_log_lik = list()
prop.predict = c()
prop.predict.death = c()
prop.predict.live = c()
cumhaz.id = matrix(NA,nrow=Z,ncol=n.ID)
lasthaz.id = matrix(NA,nrow=Z,ncol=n.ID)
exposure.id = c()
sp.id = c()
plotsp.id = c()
hazard.id = c()
for(i in 1:n.ID) {
	if(sum(uniID == i) == 1) {cumhaz.id[,i] = fitted.m[,which(uniID == i)] * exp(lgexposure[which(uniID == i)])}
	if(sum(uniID == i) > 1) {cumhaz.id[,i] = fitted.m[,which(uniID == i)] %*% exp(lgexposure[which(uniID == i)])}
	lasthaz.id[,i] = fitted.m[,which(uniID == i)[which.max(census[which(uniID == i)])]]
	exposure.id[i] = sum(exp(lgexposure[which(uniID == i)]))
	hazard.id[i] = max(hazard[which(uniID == i)])
	sp.id[i] = mean(sp[which(uniID == i)])
	plotsp.id[i] = mean(plotsp[which(uniID == i)])
}
set.seed(314)
for(i in 1:nrow(fitted.m)){
	rep.m[[i]] = as.numeric(rbernoulli(n = length(1 - predS.m[i,]), p = (1 - predS.m[i,])))
#	rep.m[[i]] = rbinom(n = length(1 - predS.m[i,]), size = 1, prob = (1 - predS.m[i,]))
	sim_log_lik[[i]] = (log(lasthaz.id[z,]) * rep.m[[i]]) - (cumhaz.id[z,])
}
rep.m = do.call('rbind', rep.m)
sim_log_lik = do.call('rbind', sim_log_lik)
for(i in 1:nrow(rep.m)) {
prop.predict[i] = mean(hazard.id==rep.m[i,])
}
for(i in 1:nrow(rep.m)) {
prop.predict.death[i] = mean(rep.m[i,][which(hazard.id==1)])
}
for(i in 1:nrow(rep.m)) {
prop.predict.live[i] = 1-mean(rep.m[i,][which(hazard.id==0)])
}

summary(prop.predict)						# posterior classification accuracy
summary(prop.predict.live)					# posterior classification accuracy of survival
summary(prop.predict.death)					# posterior classification accuracy of death
summary((prop.predict.death + prop.predict.live)/2)	# posterior balanced classification accuracy


# LogLik posterior predictive test
loglik.obs = rowSums(log_lik)
loglik.sim = rowSums(sim_log_lik)
summary(loglik.obs)
summary(loglik.sim)
logLik.meanpar.sum
#pdf("HJA_5to15cmDBH_ExpSurvival_logLik_PPC_BAYES_20210512.pdf", height = 4, width = 5, useDingbats=FALSE)
hist(loglik.sim, breaks=30, xlab = "Log-likelihood of simulated data", las = 1, main = "5-15 cm DBH survival log-likelihood PPC")
abline(v = mean(loglik.obs), lwd = 2, col = "red")
sum(loglik.sim > mean(loglik.obs)) / nrow(rep.m)
#dev.off()


# Mortality posterior predictive test
mean(hazard.id)
mean.hazard.sim = apply(rep.m,1,mean)
summary(mean.hazard.sim)
#pdf("HJA_5to15cmDBH_ExpSurvival_Mortality_PPC_BAYES_20210512.pdf", height = 4, width = 5, useDingbats=FALSE)
hist(mean.hazard.sim, breaks=20, xlab = "Proportion of individuals dead in simulated data", las = 1, main = "5-15 cm DBH survival mortality PPC")
abline(v = mean(hazard.id), lwd = 2, col = "red")
sum(mean.hazard.sim > mean(hazard.id)) / nrow(rep.m)
#dev.off()


# Posterior predictive tests for mortality levels in each census-by-plot combo, each species, and each species-by-plot combo
sp.test = list()
for(i in 1:nrow(rep.m)) {
sp.test[[i]] = tapply(rep.m[i,], sp.id, mean)
}
sp.test = do.call('rbind', sp.test)
obs.sp.test = tapply(hazard.id, sp.id, mean)
sp.test.p = c()
for(j in 1:ncol(sp.test)) {
sp.test.p[j] = min(sum(sp.test[,j] >= obs.sp.test[j]), sum(sp.test[,j] <= obs.sp.test[j])) / length(sp.test[,j])
if(obs.sp.test[j] == 0 | obs.sp.test[j] == 1) {sp.test.p[j] = (sum(sp.test[,j] == obs.sp.test[j]) / length(sp.test[,j]))/2}
}
summary(sp.test.p); sum(sp.test.p < 0.025 | sp.test.p > 0.975)
tapply(hazard.id, sp.id, mean)
apply(sp.test,2,mean)
tapply(hazard.id, sp.id, mean) - apply(sp.test,2,mean)


plotsp.test = list()
for(i in 1:nrow(rep.m)) {
plotsp.test[[i]] = tapply(rep.m[i,], plotsp.id, mean)
}
plotsp.test = do.call('rbind', plotsp.test)
obs.plotsp.test = tapply(hazard.id, plotsp.id, mean)
plotsp.test.p = c()
for(j in 1:ncol(plotsp.test)) {
plotsp.test.p[j] = min(sum(plotsp.test[,j] >= obs.plotsp.test[j]), sum(plotsp.test[,j] <= obs.plotsp.test[j])) / length(plotsp.test[,j])
if(obs.plotsp.test[j] == 0 | obs.plotsp.test[j] == 1) {plotsp.test.p[j] = (sum(plotsp.test[,j] == obs.plotsp.test[j]) / length(plotsp.test[,j]))/2}
}
summary(plotsp.test.p); sum(plotsp.test.p < 0.025 | plotsp.test.p > 0.975) / length(plotsp.test.p)
tapply(hazard.id, plotsp.id, mean)
apply(plotsp.test,2,mean)
tapply(hazard.id, plotsp.id, mean) - apply(plotsp.test,2,mean)
















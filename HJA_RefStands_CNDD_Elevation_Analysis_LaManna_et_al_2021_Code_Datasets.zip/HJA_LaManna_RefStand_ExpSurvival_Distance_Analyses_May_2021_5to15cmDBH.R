### Script to perform analyses of HJA reference stand data
### Data prep for survival and growth analyses
### By: J. LaManna, reference stand data accessed: 04-08-2021

# Load necessary R packages
library(vegan)
library(doBy)
library(arm)
library(reshape)
library(nlme)
library(spatstat)
library(lme4)
library(vegan)
library(boot)
library(lmtest)
library(abind)
library(optimx)
library(nloptr)
library(parallel)
library(MASS)
library(stats)
library(DescTools)
library(purrr)
library(rstan)
library(rstanarm)
# Code for multi-core
options(mc.cores = parallel::detectCores())


# Load data for diversity analyses
load("HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData")

### IN ADDITION MAKE SURE THESE RData FILES ARE IN R WORKING DIRECTORY:	
# "HJA_Species_Mean_Abundances_across_Censuses_by_Plot.RData"
# "HJA_CNDD_Analyses_Species_Colors_for_figures.RData"
# "HJA_GLMM_ExpHazard_Model_STAN.stan"


# Load other analysis functions
dist.weighted.abund.function = function(adultlocs = adultlocs, saplocs = saplocs, fix.rad = TRUE, rad = 10, alpha = 0, beta = 0.2) {
xdist = crossdist(adultlocs[,2], adultlocs[,3], saplocs[,2], saplocs[,3])
same.tree.row = which(adultlocs$id %in% saplocs$id == T)
same.tree.col = match(adultlocs$id, saplocs$id)[which(adultlocs$id %in% saplocs$id == T)]
xdist[as.matrix(data.frame(same.tree.row, same.tree.col))] = NA
weight.mat = matrix((adultlocs$dbh^alpha), nrow = nrow(xdist), ncol = ncol(xdist))
if(fix.rad) {
xdist2 = xdist
xdist2[which(xdist2 > rad)] = NA
xdist.weighted = weight.mat * exp((-beta) * xdist2) 
} else {
xdist.weighted = weight.mat * exp((-beta) * xdist2) 
}
xdist.weighted[is.na(xdist.weighted)] = 0
species.names = unique(adultlocs[,1])
adult.weights = data.frame(matrix(NA,nrow = nrow(saplocs), ncol = length(species.names)))
colnames(adult.weights) = species.names
rownames(adult.weights) = saplocs[,1]
if(nrow(adult.weights) == 0) {
return(adult.weights)
} else {
for(z in 1:ncol(adult.weights)) {
if(ncol(xdist.weighted) > 1) {
if(length(which(adultlocs[,1] == species.names[z])) > 1) {
adult.weights[,z] = colSums(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
} else {
adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
}
} else {
if(length(which(adultlocs[,1] == species.names[z])) > 1) {
adult.weights[,z] = sum(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
} else {
adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
}
}}
return(adult.weights)
}}



dist.weighted.form.abund.function = function(adultlocs = adultlocs, saplocs = saplocs, fix.rad = TRUE, in.rad = 0, out.rad = 10, alpha = 0) {
xdist = crossdist(adultlocs[,2], adultlocs[,3], saplocs[,2], saplocs[,3])
same.tree.row = which(adultlocs$id %in% saplocs$id == T)
same.tree.col = match(adultlocs$id, saplocs$id)[which(adultlocs$id %in% saplocs$id == T)]
xdist[as.matrix(data.frame(same.tree.row, same.tree.col))] = NA
weight.mat = matrix((adultlocs$dbh^alpha), nrow = nrow(xdist), ncol = ncol(xdist))
xdist2 = xdist
xdist2[which(xdist >= out.rad)] = NA
xdist2[which(xdist < in.rad)] = NA
xdist2[which(xdist >= in.rad & xdist < out.rad)] = 1
xdist.weighted = weight.mat * xdist2
xdist.weighted[is.na(xdist.weighted)] = 0
species.names = unique(adultlocs[,1])
adult.weights = data.frame(matrix(NA,nrow = nrow(saplocs), ncol = length(species.names)))
colnames(adult.weights) = species.names
rownames(adult.weights) = saplocs[,1]
if(nrow(adult.weights) == 0) {
  return(adult.weights)
} else {
  for(z in 1:ncol(adult.weights)) {
    if(ncol(xdist.weighted) > 1) {
      if(length(which(adultlocs[,1] == species.names[z])) > 1) {
        adult.weights[,z] = colSums(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
      } else {
        adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
      }
    } else {
      if(length(which(adultlocs[,1] == species.names[z])) > 1) {
        adult.weights[,z] = sum(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
      } else {
        adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
      }
    }
   }
  return(adult.weights)
  }
}



Add.missing.sp.names = function(test) {
names.toAdd = sp.list[which(sp.list %in% colnames(test) == F)]
test2 = data.frame(test, data.frame(matrix(0, nrow = nrow(test), ncol = length(names.toAdd))))
colnames(test2) = c(colnames(test), names.toAdd)
test2 = test2[,order(colnames(test2))]
return(test2)
}



# Radii for equal area annuli
nhbd.radius = 10		# Radius of the entire neighborhood used in analyses
nrings = 7			# Number of equal area annuli in the 10 m radius neighborhoods
f=function(in.rad, out.rad) {(pi*(out.rad^2)) - (pi*(in.rad^2))}
f2=function(in.rad, area) {sqrt((area + (pi*(in.rad^2))) / pi)}
radius10area = f(0,nhbd.radius)
rings = c(0)
for(i in 1:nrings) {
  rings[i+1] = f2(rings[i], radius10area/nrings)
}


plot(c(-nhbd.radius,nhbd.radius),c(-nhbd.radius,nhbd.radius), type = "n", 
	xlab = "", ylab = "", asp = 1)
points(0,0,pch=19,cex=1.5)
theta <- seq(0, 2 * pi, length = 200)
for(i in 2:length(rings)) {
  radius <- rings[i]; lines(x = radius * cos(theta), y = radius * sin(theta))
}
abline(v=0,lty=2)
abline(h=0,lty=2)













################################################################################################################
### SMALL-TREE SURVIVAL


###########################
### BEGIN DATA PREP FUNCTION -- Remember to set values for 'beta' and 'weight.method' below, elim.radius set to 10 m

fd.adult.phi = list()
fd.sap.phi = list()
fd.adult.recruit = list()
fd.sap.recruit = list()
elim.radius = 10		# does not include trees within 10 m of plot edge (neighborhood density metrics, which have radii of 10 m, will be biased low for these individuals because we don't know what adults are outside the plot)
beta = 0.35			# Beta value determines the shape of the exponential decay of neighborhood effects across each 10-m radius neighborhood; 0 = no decay, higher values = stronger decay (Comita et al. 2010, Science)
alpha = 0.0			# alpha parameter for abundance-based neighborhood metrics, DBH^alpha / distance^beta

sp.list

for(q in 1:length(hja.survival.growth.data)) {
test = hja.survival.growth.data[[q]]
n.census = length(test)
adult.phi.list = list()
sap.phi.list = list()

for(i in 2:n.census) {
df = test[[i]]
df$ba = (((df$DBH/100)/2)^2)*pi  		# Calculate basal area for each individual
df$julian = as.numeric(julian(as.POSIXlt(df$SAMPLEDATE, format = "%Y-%m-%d")))
adult.sp = tapply(df$DBH[which(df$DBH >= 15)], as.character(df$SPECIES[which(df$DBH >= 15)]), length)
adult.sp2 = names(adult.sp)
focal = data.frame(STANDID = df$STANDID, census = df$census, YEAR = df$YEAR, DBH = df$DBH, quad = df$quad, canopy_class = df$CANOPY_CLASS, vigor = df$TREE_VIGOR,
	uniqueID = df$uniqueID, sp = df$SPECIES, gx = df$XCOORD, gy = df$YCOORD, status = df$TREE_STATUS, dbh_code = df$DBH_CODE, julian = df$julian, min_dbh = df$MIN_DBH, notes = df$CHECK_NOTES)
focal$sp = as.character(focal$sp)

test.var = 1
if(df$census[1] == 9 & df$STANDID[1] == "RS34") {test.var = 34}
if(df$census[1] == 9 & df$STANDID[1] == "RS38") {test.var = 38}
if(test.var == 34) {focal = focal[which(focal$gx >= 10 & focal$gx <= 190 & focal$gy >= 10 & focal$gy <= 90),]}
if(test.var == 38) {focal = focal[which(focal$gx >= 10 & focal$gx <= 165 & focal$gy >= 10 & focal$gy <= 90),]}
if(test.var == 1) {
maxcol = max(as.numeric(substr(df$quad,1,2)))
maxrow = max(as.numeric(substr(df$quad,3,4)))
mincol = min(as.numeric(substr(df$quad,1,2)))
minrow = min(as.numeric(substr(df$quad,3,4)))
focal.good = focal[which(focal$quad == 9999),]
for(k in mincol:maxcol) {
df2 = df[which(as.numeric(substr(df$quad,1,2)) == k),]
ymax = max(as.numeric(substr(df2$quad,3,4))) * 25
ymin = (min(as.numeric(substr(df2$quad,3,4))) - 1) * 25
focal.good = rbind(focal.good, focal[which(as.numeric(substr(focal$quad,1,2)) == k & focal$gy >= (ymin + elim.radius) & focal$gy <= (ymax - elim.radius)),])
}
focal.good2 = focal.good[which(focal.good$quad == 9999),]
for(k in minrow:maxrow) {
df2 = df[which(as.numeric(substr(df$quad,3,4)) == k),]
xmax = max(as.numeric(substr(df2$quad,1,2))) * 25
xmin = (min(as.numeric(substr(df2$quad,1,2))) - 1) * 25
focal.good2 = rbind(focal.good2, focal.good[which(as.numeric(substr(focal.good$quad,3,4)) == k & focal.good$gx >= (xmin + elim.radius) & focal.good$gx <= (xmax - elim.radius)),])
}

focal = focal.good2
focal$sp = as.character(focal$sp)
if(nrow(focal) == 0) {print(paste("ERROR: No individuals within plot buffer!", "STAND", q, "census", i)); next}
if(focal$STANDID[1] == "RS01" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 10 & focal$gx <= 40 & focal$gy >= 10 & focal$gy <= 40),]}
if(focal$STANDID[1] == "RS02" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 35 & focal$gx <= 65 & focal$gy >= 35 & focal$gy <= 65),]}
if(focal$STANDID[1] == "RS03" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 60 & focal$gx <= 90 & focal$gy >= 60 & focal$gy <= 90),]}
}
focal$sp = as.character(focal$sp)

# plot(df$XCOORD,df$YCOORD,asp=1)
# points(focal$gx,focal$gy,pch=19,col="red")
# points(focal.good2$gx,focal.good2$gy,pch=19,col="purple")

df.prev = test[[i-1]]
df.prev = df.prev[which(df.prev$TREE_STATUS %in% c(6,9) == F),]
df.prev$julian = as.numeric(julian(as.POSIXlt(df.prev$SAMPLEDATE, format = "%Y-%m-%d")))
focal.prev.time = df.prev
if(df$census[1] == 9 & df$STANDID[1] %in% c("RS34", "RS38") == T) {
	focal.prev.time$gx = focal.prev.time$XCOORD
	focal.prev.time$gy = focal.prev.time$YCOORD
	focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$uniqueID %in% focal$uniqueID == T),]
} else {
maxcol = max(as.numeric(substr(df.prev$quad,1,2)))
maxrow = max(as.numeric(substr(df.prev$quad,3,4)))
mincol = min(as.numeric(substr(df.prev$quad,1,2)))
minrow = min(as.numeric(substr(df.prev$quad,3,4)))
focal.prev.time$gx = focal.prev.time$XCOORD
focal.prev.time$gy = focal.prev.time$YCOORD
focal.prev.time.good = focal.prev.time[which(focal.prev.time$quad == 9999),]
for(k in mincol:maxcol) {
df.prev2 = df.prev[which(as.numeric(substr(df.prev$quad,1,2)) == k),]
ymax = max(as.numeric(substr(df.prev2$quad,3,4))) * 25
ymin = (min(as.numeric(substr(df.prev2$quad,3,4))) - 1) * 25
focal.prev.time.good = rbind(focal.prev.time.good, focal.prev.time[which(as.numeric(substr(focal.prev.time$quad,1,2)) == k & focal.prev.time$gy >= (ymin + elim.radius) & focal.prev.time$gy <= (ymax - elim.radius)),])
}
focal.prev.time.good2 = focal.prev.time.good[which(focal.prev.time.good$quad == 9999),]
for(k in minrow:maxrow) {
df.prev2 = df.prev[which(as.numeric(substr(df.prev$quad,3,4)) == k),]
xmax = max(as.numeric(substr(df.prev2$quad,1,2))) * 25
xmin = (min(as.numeric(substr(df.prev2$quad,1,2))) - 1) * 25
focal.prev.time.good2 = rbind(focal.prev.time.good2, focal.prev.time.good[which(as.numeric(substr(focal.prev.time.good$quad,3,4)) == k & focal.prev.time.good$gx >= (xmin + elim.radius) & focal.prev.time.good$gx <= (xmax - elim.radius)),])
}
if(focal.prev.time$STANDID[1] == "RS01" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 10 & focal.prev.time$gx <= 40 & focal.prev.time$gy >= 10 & focal.prev.time$gy <= 40),]}
if(focal.prev.time$STANDID[1] == "RS02" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 35 & focal.prev.time$gx <= 65 & focal.prev.time$gy >= 35 & focal.prev.time$gy <= 65),]}
if(focal.prev.time$STANDID[1] == "RS03" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 60 & focal.prev.time$gx <= 90 & focal.prev.time$gy >= 60 & focal.prev.time$gy <= 90),]}
}

# plot(df.prev$XCOORD,df.prev$YCOORD,asp=1)
# points(focal.prev.time$gx,focal.prev.time$gy,pch=19,col="red")
# points(focal.prev.time.good2$gx,focal.prev.time.good2$gy,pch=19,col="purple")

focal.prev.time = focal.prev.time.good2[,c("uniqueID", "DBH", "SPECIES", "YEAR", "gx", "gy", "STANDID", "quad", "TREE_STATUS", "julian", "DBH_CODE", "CANOPY_CLASS", "TREE_VIGOR", "MIN_DBH")]
names(focal.prev.time) = c("uniqueID", "DBH_prev", "sp", "YEAR_prev", "gx_prev", "gy_prev", "STANDID_prev", "quad_prev", "status_prev", "julian_prev", "dbh_code_prev", "canopy_class_prev", "vigor_prev", "min_dbh_prev")
focal.prev.time$sp = as.character(focal.prev.time$sp)
focal2 = merge(focal, focal.prev.time, by = c("uniqueID", "sp"), all = T)
focal2$growth = focal2$DBH - focal2$DBH_prev
focal2$numyr = (focal2$julian - focal2$julian_prev) / 365.25
focal2$growth.per.yr = focal2$growth / focal2$numyr
focal2$radial.growth.per.yr = (log(focal2$DBH/focal2$DBH_prev)) / focal2$numyr		# Relative Growth Rate per Wright et al. 2018 Ecology

# plot(df$XCOORD,df$YCOORD,asp=1)
# points(focal2$gx,focal2$gy,pch=19,col="red")
# points(focal.good2$gx,focal.good2$gy,pch=19,col="purple")

# Remove interior plot corners that are within 10 m of plot boundary (not captured in preceding code)
if(focal2$STANDID[1] == "RS01") {if(nrow(focal2[which(focal2$gx > 40 & focal2$gx < 50 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 40 & focal2$gx < 50 & focal2$gy > 50 & focal2$gy < 60),]}}
if(focal2$STANDID[1] == "RS03") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 40 & focal2$gy < 50),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 40 & focal2$gy < 50),]}}
if(focal2$STANDID[1] == "RS03") {if(nrow(focal2[which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 40 & focal2$gy < 50),]) > 0) {focal2 = focal2[-which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 40 & focal2$gy < 50),]}}
if(focal2$STANDID[1] == "RS23") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 50 & focal2$gy < 60),]}}
if(focal2$STANDID[1] == "RS23") {if(nrow(focal2[which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 50 & focal2$gy < 60),]}}
if(focal2$STANDID[1] == "RS38") {if(nrow(focal2[which(focal2$gx > 25 & focal2$gx < 35 & focal2$gy > 90 & focal2$gy < 100),]) > 0) {focal2 = focal2[-which(focal2$gx > 25 & focal2$gx < 35 & focal2$gy > 90 & focal2$gy < 100),]}}
if(focal2$STANDID[1] == "RS38") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 115 & focal2$gy < 125),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 115 & focal2$gy < 125),]}}


focal2$phi = c(1)
focal2$phi[is.na(focal2$DBH)] = 0
focal2$phi[is.na(focal2$DBH_prev)] = NA
focal2$gx[is.na(focal2$gx)] = focal2$gx_prev[is.na(focal2$gx)]
focal2$gy[is.na(focal2$gy)] = focal2$gy_prev[is.na(focal2$gy)]
focal2$quad = as.character(focal2$quad)
focal2$quad_prev = as.character(focal2$quad_prev)
focal2$STANDID = as.character(focal2$STANDID)
focal2$STANDID_prev = as.character(focal2$STANDID_prev)
focal2$quad[is.na(focal2$quad)] = focal2$quad_prev[is.na(focal2$quad)]
focal2$STANDID[is.na(focal2$STANDID)] = focal2$STANDID_prev[is.na(focal2$STANDID)]
focal2$census[is.na(focal2$census)] = c(unique(focal2$census[!is.na(focal2$YEAR)]))
focal2$YEAR[is.na(focal2$YEAR)] = c(unique(focal2$YEAR[!is.na(focal2$DBH)]))

adults = df[which(df$DBH >= 15),]
adults = adults[which(adults$TREE_STATUS %in% c(6,9) == F),]
adults.prev = df.prev[which(df.prev$DBH >= 15),]
adults.prev = adults.prev[which(adults.prev$TREE_STATUS %in% c(6,9) == F),]
adultlocs = data.frame(sp = adults$SPECIES, gx = adults$XCOORD, gy = adults$YCOORD, id = adults$uniqueID, dbh = adults$DBH)
adultlocs.prev = data.frame(sp = adults.prev$SPECIES, gx = adults.prev$XCOORD, gy = adults.prev$YCOORD, id = adults.prev$uniqueID, dbh = adults.prev$DBH)
unique.quads = unique(df$quad)
quad.gx = c()
quad.gy = c()
for(z in 1:length(unique.quads)) {
quad.gx[z] = (25*as.numeric(substr(unique.quads[z],1,2))-12.5)
quad.gy[z] = (25*as.numeric(substr(unique.quads[z],3,4))-12.5)
}
quadlocs = data.frame(id = unique.quads, gx = quad.gx, gy = quad.gy)
quad.weights.prev = dist.weighted.abund.function(adultlocs = adultlocs.prev, saplocs = quadlocs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
quad.weights2.prev = Add.missing.sp.names(quad.weights.prev)
if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
	quad.weights.combined = quad.weights2.prev
} else {
	quad.weights = dist.weighted.abund.function(adultlocs = adultlocs, saplocs = quadlocs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
	quad.weights2 = Add.missing.sp.names(quad.weights)
	quad.weights.combined = (quad.weights2 + quad.weights2.prev) / 2
}

adult.phi = focal2[which(focal2$DBH_prev >= 15),]
sap.phi = focal2[which(focal2$DBH_prev < 15),]


if(nrow(adult.phi) > 0) {
adult.phi$order = c(1:nrow(adult.phi))
adult.phi = adult.phi[order(adult.phi$sp),]
adult.phi.locs = data.frame(id = adult.phi$uniqueID, gx = adult.phi$gx, gy = adult.phi$gy)
adult.phi.weights.combined_all = list()
for(t in 2:length(rings)) {
adult.phi.weights.prev = dist.weighted.form.abund.function(adultlocs = adultlocs.prev, saplocs = adult.phi.locs, fix.rad = TRUE, in.rad = rings[(t-1)], out.rad = rings[t], alpha = alpha)
adult.phi.weights2.prev = Add.missing.sp.names(adult.phi.weights.prev)
if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
	adult.phi.weights.combined = adult.phi.weights2.prev
} else {
adult.phi.weights = dist.weighted.form.abund.function(adultlocs = adultlocs, saplocs = adult.phi.locs, fix.rad = TRUE, in.rad = rings[(t-1)], out.rad = rings[t], alpha = alpha)
adult.phi.weights2 = Add.missing.sp.names(adult.phi.weights)
adult.phi.weights.combined = (adult.phi.weights2 + adult.phi.weights2.prev) / 2
}
colnames(adult.phi.weights.combined) = paste(colnames(adult.phi.weights.combined), "_",t-2,t-1,sep="")
adult.phi.weights.combined_all[[(t-1)]] = adult.phi.weights.combined
}
adult.phi = data.frame(adult.phi, do.call('cbind',adult.phi.weights.combined_all))
adult.phi = adult.phi[order(adult.phi$order),]
adult.phi.list[[i-1]] = adult.phi
}
if(nrow(sap.phi) > 0) {
sap.phi$order = c(1:nrow(sap.phi))
sap.phi = sap.phi[order(sap.phi$sp),]
sap.phi.locs = data.frame(id = sap.phi$uniqueID, gx = sap.phi$gx, gy = sap.phi$gy)
sap.phi.weights.combined_all = list()
for(t in 2:length(rings)) {
sap.phi.weights.prev = dist.weighted.form.abund.function(adultlocs = adultlocs.prev, saplocs = sap.phi.locs, fix.rad = TRUE, in.rad = rings[(t-1)], out.rad = rings[t], alpha = alpha)
sap.phi.weights2.prev = Add.missing.sp.names(sap.phi.weights.prev)
if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
	sap.phi.weights.combined = sap.phi.weights2.prev
} else {
sap.phi.weights = dist.weighted.form.abund.function(adultlocs = adultlocs, saplocs = sap.phi.locs, fix.rad = TRUE, in.rad = rings[(t-1)], out.rad = rings[t], alpha = alpha)
sap.phi.weights2 = Add.missing.sp.names(sap.phi.weights)
sap.phi.weights.combined = (sap.phi.weights2 + sap.phi.weights2.prev) / 2
}
colnames(sap.phi.weights.combined) = paste(colnames(sap.phi.weights.combined), "_",t-2,t-1,sep="")
sap.phi.weights.combined_all[[(t-1)]] = sap.phi.weights.combined
}
sap.phi = data.frame(sap.phi, do.call('cbind',sap.phi.weights.combined_all))
sap.phi = sap.phi[order(sap.phi$order),]
sap.phi.list[[i-1]] = sap.phi
}
}
if(length(adult.phi.list) > 0) {
adult.phi.list = adult.phi.list[which(lapply(adult.phi.list, function(x) {nrow(x) > 0}) == T)]
adult.phi2 = do.call('rbind', adult.phi.list)
adult.phi2$yr = adult.phi2$YEAR - 2000
fd.adult.phi[[q]] = adult.phi2
}
if(length(sap.phi.list) > 0) {
sap.phi.list = sap.phi.list[which(lapply(sap.phi.list, function(x) {nrow(x) > 0}) == T)]
sap.phi2 = do.call('rbind', sap.phi.list)
sap.phi2$yr = sap.phi2$YEAR - 2000
fd.sap.phi[[q]] = sap.phi2
}
}



########################################
## Prepare small-tree data for analysis (stem abundance selected as metric of neighborhood density)
yr.value = 2008
fd.sap.phi4 = do.call('rbind', fd.sap.phi)
fd.sap.phi5 = merge(fd.sap.phi4, standclimate, by = "STANDID", all.x = T)
fd.sap.phi5$yr2 = fd.sap.phi5$YEAR - yr.value
for(t in 2:length(rings)) {
conspp = c()
allspp = c()
heterospp = c()
adult.cols = which(colnames(fd.sap.phi5) %in% paste(sp.list,"_",(t-2),(t-1),sep = "") == T)
for(i in 1:nrow(fd.sap.phi5)) {
conspp[i] = fd.sap.phi5[i,which(colnames(fd.sap.phi5) == paste(fd.sap.phi5$sp[i],"_",(t-2),(t-1),sep = ""))]
allspp[i] = sum(fd.sap.phi5[i,adult.cols])
heterospp[i] = allspp[i] - conspp[i]
}
fd.sap.phi5 = data.frame(fd.sap.phi5, conspp, heterospp, allspp)
colnames(fd.sap.phi5)[(ncol(fd.sap.phi5) - 2):ncol(fd.sap.phi5)] = c(paste("conspp_",(t-2),(t-1),sep = ""), paste("heterospp_",(t-2),(t-1),sep = ""), paste("allspp_",(t-2),(t-1),sep = ""))
}
fd.sap.phi6 = fd.sap.phi5[which(fd.sap.phi5$census < 9),]
fd.sap.phi6$plotcen = as.numeric(factor(as.character(factor(as.character(fd.sap.phi6$STANDID)):factor(as.character(fd.sap.phi6$census)))))
fd.sap.phi7 = split(fd.sap.phi6, fd.sap.phi6$plotcen)
sap.census.intervals = unlist(lapply(fd.sap.phi7,function(x) {(mean(x$julian[which(x$YEAR == max(x$YEAR))]) - mean(x$julian_prev[which(x$YEAR == max(x$YEAR))]))/365.25}))
sap.census.intervals = data.frame(census.interval = sap.census.intervals, plotcen = names(sap.census.intervals))
sap.census.intervals$cenyr = unlist(lapply(fd.sap.phi7,function(x) {max(x$YEAR)}))
fd.sap.phi6 = merge(fd.sap.phi6, sap.census.intervals, by = "plotcen", all.x = T)









###### Bayesian Analysis for survival at different distances from focal tree (Equal Area Annuli)

d1 = fd.sap.phi6
exponents = 0.4
consppall = d1[,which(substr(colnames(d1),1,6) == "conspp")]
heterosppall = d1[,which(substr(colnames(d1),1,9) == "heterospp")]

uniID = as.numeric(factor(d1$uniqueID))

consppalllist = split(consppall, uniID)
hetsppalllist = split(heterosppall, uniID)
consppall2 = lapply(consppalllist, function(x) {apply(x, 2, mean)}); consppall3 = do.call('rbind', consppall2)
hetsppall2 = lapply(hetsppalllist, function(x) {apply(x, 2, mean)}); hetsppall3 = do.call('rbind', hetsppall2)
conhet = c(c(as.matrix(consppall3^exponents)), c(as.matrix(hetsppall3^exponents)))


for(j in 1:3) {
if(j == 1) {d = fd.sap.phi6[which(fd.sap.phi6$ELEVATION < 700),]}
if(j == 2) {d = fd.sap.phi6[which(fd.sap.phi6$ELEVATION < 950 & fd.sap.phi6$ELEVATION >= 700),]}
if(j == 3) {d = fd.sap.phi6[which(fd.sap.phi6$ELEVATION >= 950),]}

d = d[order(d$uniqueID, d$census),]
dlist = split(d, as.character(d$uniqueID))
for(i in 1:length(dlist)) {dlist[[i]]$tinterval = c(1:nrow(dlist[[i]]))}
d = do.call('rbind', dlist)
hazard = 1 - d$phi
lgexposure = log(d$numyr)
surv = d$phi
d$ID = as.character(d$uniqueID)
tinterval = d$tinterval
exponents = 0.4

d$STANDID = as.character(d$STANDID)
d$census = as.character(d$census)
d$sp = as.character(d$sp)

conspp = d[,which(substr(colnames(d),1,6) == "conspp")]
heterospp = d[,which(substr(colnames(d),1,9) == "heterospp")]
allspp = d[,which(substr(colnames(d),1,6) == "allspp")]

conmat = ((conspp^exponents) - mean(conhet)) / sd(conhet)
hetmat = ((heterospp^exponents) - mean(conhet)) / sd(conhet)

uniID = as.numeric(factor(d$uniqueID))
elevid = tapply(d$ELEVATION, uniID, mean)
dbhid = tapply(d$DBH_prev, uniID, mean)
yrid = tapply(d$julian_prev/365.25, uniID, mean)
ELEV = (d$ELEVATION - mean(elevid)) / sd(elevid)
dbh = (d$DBH_prev - mean(dbhid)) / sd(dbhid)
yr = ((d$julian_prev/365.25) - mean(yrid)) / sd(yrid)
yr2 = yr^2
census = as.numeric(as.character(factor(as.character(d$census)))) - 1
sp = as.numeric(factor(as.character(d$sp)))
sp.info = unique(data.frame(sp.name = d$sp, sp = sp))
plotsp = as.numeric(factor(as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID)))))
plotsp.info = unique(data.frame(sp = d$sp, plot = d$STANDID, combo = as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID))), plotELEV = ELEV, plotsp = plotsp))
plotcen = as.numeric(as.factor(d$plotcen))
plotcen.info = unique(data.frame(yr = d$census, plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID)):factor(as.character(d$census))), plotELEV = ELEV, plotcen = plotcen))
n.census = length(unique(census))
n.ID = length(unique(uniID))
n = nrow(d)
spINplot = plotsp.info$sp[order(plotsp.info$plotsp)]
plotELEV = plotsp.info$plotELEV[order(plotsp.info$plotsp)]
plot = as.numeric(as.factor(d$STANDID))
n.plotcen = length(unique(plotcen))
tinterval2 = rep(0, times = length(tinterval)); tinterval2[which(tinterval == 2)] = 1
tinterval3 = rep(0, times = length(tinterval)); tinterval3[which(tinterval == 3)] = 1
tinterval4 = rep(0, times = length(tinterval)); tinterval4[which(tinterval == 4)] = 1
tinterval5 = rep(0, times = length(tinterval)); tinterval5[which(tinterval == 5)] = 1
tinterval6 = rep(0, times = length(tinterval)); tinterval6[which(tinterval == 6)] = 1
tinterval7 = rep(0, times = length(tinterval)); tinterval7[which(tinterval == 7)] = 1


#for(t in 1:ncol(conspp)) {
con = conmat[,t]
het = hetmat[,t]
x = cbind(rep(1,times = n), dbh, tinterval2, tinterval3, tinterval4, tinterval5, tinterval6, tinterval7, yr, yr2, con, het, con*dbh, het*dbh)	
K = ncol(x)
PX = cbind(rep(1,times = n), con, het)
PK = ncol(PX)
PJ = length(unique(plotsp))
SX = cbind(rep(1,times = n), con, het)
SK = ncol(SX)
SJ = length(unique(sp))

# Bundle data
dat <- list(y = hazard, lgexposure = lgexposure, x = x, K = K, plotsp = plotsp, sp = sp, census = plotcen, 
	ncensus = n.plotcen, PJ = PJ, PK = PK, PX = PX, SJ = SJ, SK = SK, SX = SX, N = n)

# LMER model with ML for ranef variance estimates (once run, comment off with #)
set.seed(314)
m1 = lme4::glmer(hazard ~ dbh + factor(tinterval) + yr + yr2 + con + het + con:dbh + het:dbh + 
	(con + het|sp) + (con + het|plotsp) + (1|plotcen), family = poisson, offset = lgexposure, 
	control=glmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(m1)
sum(((predict(m1,type = "link")-lgexposure) * hazard) - exp(predict(m1,type = "link")))



### Fit stan model 
# HMC Parameters
nchains = 8
postburn = 4000
burnin = 2000
its = postburn + burnin
thin = 1					
hmc_seed = 55406

# Initial values from LMER model
vc <- VarCorr(m1)
sigma_SB_lmer = as.matrix(Matrix::bdiag(vc$sp))
sigma_PB_lmer = as.matrix(Matrix::bdiag(vc$plotsp))
inits <- replicate(nchains, list(
  Pz = t(data.matrix(ranef(m1)$'plotsp')),
  PL_Omega = sigma_PB_lmer,
  Ptau_unif = runif(PK),
  Sz = t(data.matrix(ranef(m1)$'sp')),
  SL_Omega = sigma_SB_lmer,
  Stau_unif = runif(SK),
  beta = fixef(m1),
  sigma_YEAR = attr(summary(m1)$varcor$plotcen,"stddev")[[1]]+0.001,
  YEAR = ranef(m1)$'plotcen'[[1]]+0.001, 
  PB = data.matrix(ranef(m1)$'plotsp'), 
  sigma_PB = sigma_PB_lmer, 
  Ptau = runif(PK), 
  SB = data.matrix(ranef(m1)$'sp'), 
  sigma_SB = sigma_SB_lmer, 
  Stau = runif(SK)
), simplify = F)


# Run model
begin = Sys.time()
fit <- stan(file = "HJA_GLMM_ExpHazard_Model_STAN.stan", 				# Stan model
  data = dat,   									# named list of data
  init = inits,										# initial values for parameters
  chains = nchains,             							# number of Markov chains
  warmup = burnin,          								# number of warmup iterations per chain
  iter = its,            								# total number of iterations per chain
  cores = nchains,              							# number of cores (could use one per chain)
  thin = thin,
  seed = hmc_seed,
  control = list(adapt_delta = 0.99)
  )
end = Sys.time()
(duration = end - begin)

elevlevel = c("Low_Elev", "Mid_Elev", "High_Elev")
save(fit, file = paste("HJA_Sap_Hazard_Bayesian_STAN_EAA_", elevlevel[j], "_Annuli_", t, "_20210514.RData", sep = ""))
}
}



# load(paste("HJA_Sap_Hazard_Bayesian_STAN_EAA_", elevlevel[j], "_Annuli_", t, "_20210514.RData", sep = ""))




divergent <- get_sampler_params(fit, inc_warmup=FALSE)
divergent2 = list()
for(i in 1:length(divergent)) {divergent2[[i]] = data.frame(div = divergent[[i]][,'divergent__'], chain = i)}
divergent = do.call('rbind', divergent2)
sum(divergent$div)
table(divergent$chain[which(divergent$div == 1)])

treedepth <- get_sampler_params(fit, inc_warmup=FALSE)
tree.depth = list()
for(i in 1:length(treedepth)) {tree.depth[[i]] = data.frame(treedepth = treedepth[[i]][,'treedepth__'], chain = i)}
tree.depth = do.call('rbind', tree.depth)
summary(tree.depth$treedepth)
table(tree.depth$treedepth)
table(tree.depth$chain[which(tree.depth$treedepth > 9)])




# Remove divergent chains
divergent <- get_sampler_params(fit, inc_warmup=FALSE)
divergent2 = list()
for(i in 1:length(divergent)) {divergent2[[i]] = data.frame(div = divergent[[i]][,'divergent__'], chain = i)}
divergent = do.call('rbind', divergent2)
sum(divergent$div)
table(divergent$chain[which(divergent$div == 1)])
div.chains = unique(divergent$chain[which(divergent$div == 1)])
draws <- extract(fit, permuted = FALSE)
draws = draws[,which(c(1:nchains) %in% div.chains == F),] # Remove chains 2 and 5, which had divergences (only 1 divergence on each chains) 



# test for thinning interval that removes auto-correlation in chains
#thin1 = 10
#acf(c(draws[seq(1,postburn,by=thin1),,"beta[1]"]), lag.max = 100)
#acf(c(draws[seq(1,postburn,by=thin1),,"beta[2]"]), lag.max = 100)
#acf(c(draws[seq(1,postburn,by=thin1),,"beta[3]"]), lag.max = 100)
#acf(c(draws[seq(1,postburn,by=thin1),,"beta[4]"]), lag.max = 100)
#acf(c(draws[seq(1,postburn,by=thin1),,"beta[5]"]), lag.max = 100)
#acf(c(draws[seq(1,postburn,by=thin1),,"beta[6]"]), lag.max = 100)
#acf(c(draws[seq(1,postburn,by=thin1),,"beta[7]"]), lag.max = 100)
#acf(c(draws[seq(1,postburn,by=thin1),,"sigma_YEAR"]), lag.max = 100)
#acf(c(draws[seq(1,postburn,by=thin1),,"sigma_PB[1,1]"]), lag.max = 100)
#acf(c(draws[seq(1,postburn,by=thin1),,"sigma_PB[2,2]"]), lag.max = 100)
#acf(c(draws[seq(1,postburn,by=thin1),,"sigma_PB[1,2]"]), lag.max = 100)
#acf(c(draws[seq(1,postburn,by=thin1),,"sigma_SB[1,1]"]), lag.max = 100)
#acf(c(draws[seq(1,postburn,by=thin1),,"sigma_SB[2,2]"]), lag.max = 100)
#acf(c(draws[seq(1,postburn,by=thin1),,"sigma_SB[1,2]"]), lag.max = 100)



# Extract estimates
thin1 = 10
beta.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta")])),3,c)
SB.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB")])),3,c)
SB.m = array(SB.m, dim = c(nrow(SB.m),SJ,SK), dimnames = list(paste("it",c(1:nrow(SB.m)),sep=""),paste("sp",c(1:SJ),sep=""),paste("SB",c(1:SK),sep="")))
PB.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB")])),3,c)
PB.m = array(PB.m, dim = c(nrow(PB.m),PJ,PK), dimnames = list(paste("it",c(1:nrow(PB.m)),sep=""),paste("plotsp",c(1:PJ),sep=""),paste("PB",c(1:PK),sep="")))
census.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")])),3,c)
plotcen.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")])),3,c)
sigmaSB.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB")])),3,c)
sigmaPB.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB")])),3,c)
sigmaYR.m = c(draws[seq(1,postburn,by=thin1),,"sigma_YEAR"])

Sz.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,2) == "Sz")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "Sz"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "Sz")])),3,c)

Stau.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,4) == "Stau")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "Stau"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "Stau")])),3,c)
SL_Omega.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,8) == "SL_Omega")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "SL_Omega"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "SL_Omega")])),3,c)
(SL_Cholesky = diag(apply(Stau.m,2,mean)[4:6])%*%matrix(apply(SL_Omega.m,2,mean),nrow=3,ncol=3))
Ptau.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,4) == "Ptau")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "Ptau"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "Ptau")])),3,c)
matrix(apply(sigmaSB.m,2,mean),nrow=3,ncol=3)
cov2cor(matrix(apply(sigmaSB.m,2,mean),nrow=3,ncol=3))

PL_Omega.m = apply(array(draws[seq(1,postburn,by=thin1),,which(substr(attributes(draws)$dimnames$parameters,1,8) == "PL_Omega")], dim = c(length(seq(1,postburn,by=thin1)), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "PL_Omega"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "PL_Omega")])),3,c)
(PL_Cholesky = diag(apply(Ptau.m,2,mean)[4:6])%*%matrix(apply(PL_Omega.m,2,mean),nrow=3,ncol=3))
matrix(apply(sigmaPB.m,2,mean),nrow=3,ncol=3)
cov2cor(matrix(apply(sigmaPB.m,2,mean),nrow=3,ncol=3))

getME(m1,"theta")	# Cholesky factors from the lmer model


# Estimates
t(apply(beta.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(beta.m,2,mean)
t(apply(sigmaSB.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(sigmaSB.m,2,mean)
t(apply(sigmaPB.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(sigmaPB.m,2,mean)
quantile(sigmaYR.m^2,c(0.025,0.975,0.05,0.95,0.5)); mean(sigmaYR.m^2)









dbhtest = 5
DenExp = 0.4
StdAdultDBH = 60
zerotree = (0 - mean(conhet)) / sd(conhet)
onetree = (((StdAdultDBH^alpha)^DenExp) - mean(conhet)) / sd(conhet)
plotsp.info2 = plotsp.info[order(plotsp.info$plotsp),]
names(plotsp.info2)[1] = "sp.name"
plotsp.info2 = merge(plotsp.info2, sp.info, by = "sp.name", all = T)
dbh.m = beta.m[,2]
dbhtest2 = (dbhtest - mean(dbhid)) / sd(dbhid)
cndd.m = beta.m[,11]
hndd.m = beta.m[,12]
cndddbh.m = beta.m[,13]
hndddbh.m = beta.m[,14]
alpha.m = beta.m[,1]
census.m = beta.m[,4]
plot.alpha = list()
plot.alpha2 = list()
cndd = list()
hndd = list()
realcon = list()
realhet = list()
realcndd = list()
sp.alpha = list()
sp.alpha2 = list()
for(i in 1:PJ) {
  plot.alpha[[i]] = alpha.m + census.m + (dbh.m*dbhtest2) + SB.m[,plotsp.info2$sp[i],1] + PB.m[,plotsp.info2$plotsp[i],1] 
  cndd[[i]] = cndd.m + (cndddbh.m*dbhtest2) + SB.m[,plotsp.info2$sp[i],2] + PB.m[,plotsp.info2$plotsp[i],2] 
  hndd[[i]] = hndd.m + (hndddbh.m*dbhtest2) + SB.m[,plotsp.info2$sp[i],3] + PB.m[,plotsp.info2$plotsp[i],3]
  realcndd[[i]] = exp(-exp(plot.alpha[[i]] + (cndd[[i]]*onetree) + (hndd[[i]]*zerotree))) - exp(-exp(plot.alpha[[i]] + (cndd[[i]]*zerotree) + (hndd[[i]]*onetree)))
  plot.alpha2[[i]] = plot.alpha[[i]] + (cndd[[i]]*onetree) + (hndd[[i]]*onetree)
  sp.alpha[[i]] = alpha.m + census.m + (dbh.m*dbhtest2) + SB.m[,plotsp.info2$sp[i],1] + PB.m[,plotsp.info2$plotsp[i],1]
  sp.alpha2[[i]] = alpha.m + census.m + (dbh.m*dbhtest2) + SB.m[,plotsp.info2$sp[i],1] + PB.m[,plotsp.info2$plotsp[i],1] + ((cndd.m + (cndddbh.m*dbhtest2) + SB.m[,plotsp.info2$sp[i],2] + PB.m[,plotsp.info2$plotsp[i],2])*onetree) + ((hndd.m + (hndddbh.m*dbhtest2) + SB.m[,plotsp.info2$sp[i],3] + PB.m[,plotsp.info2$plotsp[i],3])*onetree)
}
plot.alpha = do.call('cbind', plot.alpha)
plot.alpha2 = do.call('cbind', plot.alpha2)
cndd = do.call('cbind', cndd)
hndd = do.call('cbind', hndd)
realcndd = do.call('cbind', realcndd)

cnddmean.m = apply(realcndd,1,function(x) {lmer(x ~ 1 + (1|plotsp.info2$sp))})
cnddmean = unlist(lapply(cnddmean.m, function(x) {return(summary(x)$coef[1,1])}))
summary(cnddmean)
quantile(cnddmean, c(0.05,0.95))


elevlevel = c("Low_Elev", "Mid_Elev", "High_Elev")
save(cnddmean, file = paste("HJA_",dbhtest,"cmDBH_Hazard_Bayesian_EAA_CNDDMEAN_", elevlevel[j], "_Annuli_", t, "_20210524.RData", sep = ""))




hist(cnddmean, breaks = 50)
abline(v = 0, lty = 2)
abline(v = mean(cnddmean), lwd=2, col="red")
abline(v = quantile(cnddmean, c(0.05,0.95)), col="red")








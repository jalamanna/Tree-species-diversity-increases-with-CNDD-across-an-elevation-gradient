### Figures across DBH classes for HJA-CNDD study


ests1 = list()
ests2 = list()
ests3 = list()
gests1 = list()
gests2 = list()
gests3 = list()
dbh = list()
dbh[[1]] = 5
dbh[[2]] = 7
dbh[[3]] = 10
dbh[[4]] = 15
dbh[[5]] = 20
dbh[[6]] = 25
dbh[[7]] = 35
dbh[[8]] = 55
dbh[[9]] = 100
dbh[[10]] = 200


load("HJA_CNDDELEV_5cmDBH_Survival_20210914.RData")
ests1[[1]] = cndd.m3.wests
ests2[[1]] = cnddvar1.m3.wests
ests3[[1]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_7cmDBH_Survival_20210914.RData")
ests1[[2]] = cndd.m3.wests
ests2[[2]] = cnddvar1.m3.wests
ests3[[2]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_10cmDBH_Survival_20210914.RData")
ests1[[3]] = cndd.m3.wests
ests2[[3]] = cnddvar1.m3.wests
ests3[[3]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_15cmDBH_Survival_20210914.RData")
ests1[[4]] = cndd.m3.wests
ests2[[4]] = cnddvar1.m3.wests
ests3[[4]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_20cmDBH_Survival_20210914.RData")
ests1[[5]] = cndd.m3.wests
ests2[[5]] = cnddvar1.m3.wests
ests3[[5]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_25cmDBH_Survival_20210914.RData")
ests1[[6]] = cndd.m3.wests
ests2[[6]] = cnddvar1.m3.wests
ests3[[6]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_35cmDBH_Survival_20210914.RData")
ests1[[7]] = cndd.m3.wests
ests2[[7]] = cnddvar1.m3.wests
ests3[[7]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_55cmDBH_Survival_20210914.RData")
ests1[[8]] = cndd.m3.wests
ests2[[8]] = cnddvar1.m3.wests
ests3[[8]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_100cmDBH_Survival_20210914.RData")
ests1[[9]] = cndd.m3.wests
ests2[[9]] = cnddvar1.m3.wests
ests3[[9]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_200cmDBH_Survival_20210914.RData")
ests1[[10]] = cndd.m3.wests
ests2[[10]] = cnddvar1.m3.wests
ests3[[10]] = cnddvar2.m3.wests

load("HJA_CNDDELEV_Growth_5cmDBH_20210914.RData")
gests1[[1]] = cndd.m3.wests
gests2[[1]] = cnddvar1.m3.wests
gests3[[1]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_Growth_7cmDBH_20210914.RData")
gests1[[2]] = cndd.m3.wests
gests2[[2]] = cnddvar1.m3.wests
gests3[[2]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_Growth_10cmDBH_20210914.RData")
gests1[[3]] = cndd.m3.wests
gests2[[3]] = cnddvar1.m3.wests
gests3[[3]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_Growth_15cmDBH_DBHre_20210914.RData")
gests1[[4]] = cndd.m3.wests
gests2[[4]] = cnddvar1.m3.wests
gests3[[4]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_Growth_20cmDBH_DBHre_20210914.RData")
gests1[[5]] = cndd.m3.wests
gests2[[5]] = cnddvar1.m3.wests
gests3[[5]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_Growth_25cmDBH_20210914.RData")
gests1[[6]] = cndd.m3.wests
gests2[[6]] = cnddvar1.m3.wests
gests3[[6]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_Growth_35cmDBH_20210914.RData")
gests1[[7]] = cndd.m3.wests
gests2[[7]] = cnddvar1.m3.wests
gests3[[7]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_Growth_55cmDBH_20210914.RData")
gests1[[8]] = cndd.m3.wests
gests2[[8]] = cnddvar1.m3.wests
gests3[[8]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_Growth_100cmDBH_20210914.RData")
gests1[[9]] = cndd.m3.wests
gests2[[9]] = cnddvar1.m3.wests
gests3[[9]] = cnddvar2.m3.wests
load("HJA_CNDDELEV_Growth_200cmDBH_20210914.RData")
gests1[[10]] = cndd.m3.wests
gests2[[10]] = cnddvar1.m3.wests
gests3[[10]] = cnddvar2.m3.wests



elevmin = 11.802
elevmax = 7.446
upperquant = 0.95
lowerquant = 0.05


cnddLELEVupper = c()
cnddLELEVlower = c()
cnddLELEVmean = c()
cnddHELEVupper = c()
cnddHELEVlower = c()
cnddHELEVmean = c()
gcnddLELEVupper = c()
gcnddLELEVlower = c()
gcnddLELEVmean = c()
gcnddHELEVupper = c()
gcnddHELEVlower = c()
gcnddHELEVmean = c()
for(i in 1:length(ests1)) {
cnddLELEVupper[i] = quantile((ests1[[i]]+(ests2[[i]]*elevmin) + (6.509438*ests3[[i]])),c(upperquant))
cnddLELEVlower[i] = quantile((ests1[[i]]+(ests2[[i]]*elevmin) + (6.509438*ests3[[i]])),c(lowerquant))
cnddLELEVmean[i] = mean((ests1[[i]]+(ests2[[i]]*elevmin) + (6.509438*ests3[[i]])))
cnddHELEVupper[i] = quantile((ests1[[i]]+(ests2[[i]]*elevmax) + (6.509438*ests3[[i]])),c(upperquant))
cnddHELEVlower[i] = quantile((ests1[[i]]+(ests2[[i]]*elevmax) + (6.509438*ests3[[i]])),c(lowerquant))
cnddHELEVmean[i] = mean((ests1[[i]]+(ests2[[i]]*elevmax) + (6.509438*ests3[[i]])))
}
for(i in 1:length(gests1)) {
gcnddLELEVupper[i] = quantile((gests1[[i]]+(gests2[[i]]*elevmin) + (16.81713*gests3[[i]])),c(upperquant))
gcnddLELEVlower[i] = quantile((gests1[[i]]+(gests2[[i]]*elevmin) + (16.81713*gests3[[i]])),c(lowerquant))
gcnddLELEVmean[i] = mean((gests1[[i]]+(gests2[[i]]*elevmin) + (16.81713*gests3[[i]])))
gcnddHELEVupper[i] = quantile((gests1[[i]]+(gests2[[i]]*elevmax) + (16.81713*gests3[[i]])),c(upperquant))
gcnddHELEVlower[i] = quantile((gests1[[i]]+(gests2[[i]]*elevmax) + (16.81713*gests3[[i]])),c(lowerquant))
gcnddHELEVmean[i] = mean((gests1[[i]]+(gests2[[i]]*elevmax) + (16.81713*gests3[[i]])))
}
# 6.509438 = mean value of 'min spring temps' (other variable in phi models)
# 16.81713 = mean value of 'mean summer temps' (other variable in growth models)






pdf("HJA_CNDD_Across_DBH_Size_Classes_BAYES_wMeanSpTemp_20210914.pdf", height = 8, width = 6.5, useDingbats=FALSE)
par(mfrow=c(2,1))
par(mar = c(5, 5, 4, 2) + 0.1)
spacing = 0.05
marginadjust = 0.7
plot(c(0,1), c(0,1), las = 1, ylab = "", type = "n", 
	main = "CNDD in annual survival across size classes", xlim=c(1,10), ylim=c(-0.15,0.14), xlab = "Tree size class (cm DBH)", xaxt = "n")
mtext(side = 2, line = 3.5, "Change in annual survival from CNDD")
abline(h=0,lty=2)
lines((1:length(cnddLELEVmean))-spacing, cnddLELEVmean, col = "red", lwd = 1.5)
lines((1:length(cnddHELEVmean))+spacing, cnddHELEVmean, col = "blue", lwd = 1.5)
for(i in 1:10) {
segments(i-spacing ,cnddLELEVupper[i],i-spacing , cnddLELEVlower[i], col = "red", lwd = 1.5)
segments(i+spacing ,cnddHELEVupper[i],i+spacing , cnddHELEVlower[i], col = "blue", lwd = 1.5)
}
for(i in c(1:3)) {points(i-spacing , cnddLELEVmean[i], pch = 19, cex = 2, col = "red")}
#for(i in c(4:5)) {
#	points(i-spacing , cnddLELEVmean[i], pch = 19, cex = 2, col = "red", lwd = 3)
#	points(i-spacing , cnddLELEVmean[i], pch = 16, cex = 1.4, col = adjustcolor("white", alpha.f = marginadjust), lwd = 3)
#}
for(i in c(4:10)) {points(i-spacing , cnddLELEVmean[i], pch = 21, bg = "white", cex = 2, col = "red", lwd = 3)}
# for(i in c(0)) {points(i+spacing , cnddHELEVmean[i], pch = 19, cex = 2, col = "blue")}
for(i in c(1:10)) {points(i+spacing , cnddHELEVmean[i], pch = 21, bg = "white", cex = 2, col = "blue", lwd = 3)}
axis(side=1, at = 1:length(cnddLELEVmean), labels = unlist(dbh)[1:length(cnddLELEVmean)])
text(c(1,2,3),rep(0.138,times=2), "*", cex=2)
#text(c(3),rep(0.138,times=1), "�", cex=1)
legend("bottomright", legend = c("Warm mean spring temps", "Cold mean spring temps"), pch = 19, col = c("red", "blue"), bty = "n", lwd=1.5)

plot(c(0,1), c(0,1), las = 1, ylab = "", type = "n", 
	main = "CNDD in annual growth across size classes", xlim=c(1,10), ylim=c(-0.15,0.12), xlab = "Tree size class (cm DBH)", xaxt = "n")
mtext(side = 2, line = 3.5, "Change in annual growth from CNDD")
abline(h=0,lty=2)
lines((1:length(gcnddLELEVmean))-spacing, gcnddLELEVmean, col = "red", lwd = 1.5)
lines((1:length(gcnddHELEVmean))+spacing, gcnddHELEVmean, col = "blue", lwd = 1.5)
for(i in 1:10) {
segments(i-spacing ,gcnddLELEVupper[i],i-spacing , gcnddLELEVlower[i], col = "red", lwd = 1.5)
segments(i+spacing ,gcnddHELEVupper[i],i+spacing , gcnddHELEVlower[i], col = "blue", lwd = 1.5)
}
for(i in c(4,6)) {points(i-spacing , gcnddLELEVmean[i], pch = 19, cex = 2, col = "red")}
for(i in c(2,3,7,8,9,10)) {points(i-spacing , gcnddLELEVmean[i], pch = 21, bg = "white", cex = 2, col = "red", lwd = 3)}
for(i in c(1,5)) {
	points(i-spacing , gcnddLELEVmean[i], pch = 19, cex = 2, col = "red", lwd = 3)
	points(i-spacing , gcnddLELEVmean[i], pch = 16, cex = 1.4, col = adjustcolor("white", alpha.f = marginadjust), lwd = 3)
}
for(i in c(6)) {
	points(i+spacing , gcnddHELEVmean[i], pch = 19, cex = 2, col = "blue", lwd = 3)
	points(i+spacing , gcnddHELEVmean[i], pch = 16, cex = 1.4, col = adjustcolor("white", alpha.f = marginadjust), lwd = 3)
}
for(i in c(1:5,7:10)) {points(i+spacing , gcnddHELEVmean[i], pch = 21, bg = "white", cex = 2, col = "blue", lwd = 3)}
axis(side=1, at = 1:length(gcnddLELEVmean), labels = unlist(dbh)[1:length(gcnddLELEVmean)])
text(c(4,5),rep(0.115,times=2), "*", cex=2)
legend("bottomleft", legend = c("Warm mean spring temps", "Cold mean spring temps"), pch = 19, col = c("red", "blue"), bty = "n", lwd=1.5)

dev.off()


for(i in 1:10) {
estsL = (ests1[[i]]+(ests2[[i]]*elevmin) + (6.509438*ests3[[i]]))
estsH = (ests1[[i]]+(ests2[[i]]*elevmax) + (6.509438*ests3[[i]]))
print(sum((estsL - estsH) > 0) / length(estsL))
}

for(i in 1:10) {
estsL = (ests1[[i]]+(ests2[[i]]*elevmin) + (6.509438*ests3[[i]]))
print(sum(estsL > 0) / length(estsL))
}

for(i in 1:10) {
estsH = (ests1[[i]]+(ests2[[i]]*elevmax) + (6.509438*ests3[[i]]))
print(sum(estsH > 0) / length(estsH))
}


for(i in 1:10) {
estsL = (gests1[[i]]+(gests2[[i]]*elevmin) + (16.81713*gests3[[i]]))
estsH = (gests1[[i]]+(gests2[[i]]*elevmax) + (16.81713*gests3[[i]]))
print(sum((estsL - estsH) > 0) / length(estsL))
}

for(i in 1:10) {
estsL = (gests1[[i]]+(gests2[[i]]*elevmin) + (16.81713*gests3[[i]]))
print(sum((estsL) > 0) / length(estsL))
}

for(i in 1:10) {
estsH = (gests1[[i]]+(gests2[[i]]*elevmax) + (16.81713*gests3[[i]]))
print(sum((estsH) > 0) / length(estsH))
}








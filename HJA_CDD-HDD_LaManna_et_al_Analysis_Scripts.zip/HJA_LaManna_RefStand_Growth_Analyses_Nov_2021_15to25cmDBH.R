### Script to perform analyses of HJA reference stand data
### Data prep for survival and growth analyses
### By: J. LaManna, reference stand data accessed: 12-23-2017

# Load necessary R packages
library(vegan)
library(doBy)
library(arm)
library(reshape)
library(nlme)
library(spatstat)
library(lme4)
library(vegan)
library(boot)
library(lmtest)
library(abind)
library(optimx)
library(nloptr)
library(parallel)
library(MASS)
library(stats)
library(DescTools)
library(purrr)
library(rstan)
library(rstanarm)
# Code for multi-core
options(mc.cores = parallel::detectCores())
library(DHARMa)


# Load data for diversity analyses
load("HJA_LaManna_RefStand_Survival-Growth_Data_Prep.RData")

### IN ADDITION MAKE SURE THESE RData FILES ARE IN R WORKING DIRECTORY:
# "HJA_Species_Mean_Abundances_across_Censuses_by_Plot.RData"
# "HJA_CNDD_Analyses_Species_Colors_for_figures.RData"
# "HJA_GLMM_CENSORED_Growth_Model.stan"


# Load other analysis functions
# Function to calculate distance-weighted abundance based on methods in Uriarte et al. (2004) and Comita et al. (2010):
dist.weighted.abund.function = function(adultlocs = adultlocs, saplocs = saplocs, fix.rad = TRUE, rad = 10, alpha = 0, beta = 0.2) {
xdist = crossdist(adultlocs[,2], adultlocs[,3], saplocs[,2], saplocs[,3])
same.tree.row = which(adultlocs$id %in% saplocs$id == T)
same.tree.col = match(adultlocs$id, saplocs$id)[which(adultlocs$id %in% saplocs$id == T)]
xdist[as.matrix(data.frame(same.tree.row, same.tree.col))] = NA
weight.mat = matrix((adultlocs$dbh^alpha), nrow = nrow(xdist), ncol = ncol(xdist))
if(fix.rad) {
xdist2 = xdist
xdist2[which(xdist2 > rad)] = NA
xdist.weighted = weight.mat * exp((-beta) * xdist2) 
} else {
xdist.weighted = weight.mat * exp((-beta) * xdist2) 
}
xdist.weighted[is.na(xdist.weighted)] = 0
species.names = unique(adultlocs[,1])
adult.weights = data.frame(matrix(NA,nrow = nrow(saplocs), ncol = length(species.names)))
colnames(adult.weights) = species.names
rownames(adult.weights) = saplocs[,1]
if(nrow(adult.weights) == 0) {
return(adult.weights)
} else {
for(z in 1:ncol(adult.weights)) {
if(ncol(xdist.weighted) > 1) {
if(length(which(adultlocs[,1] == species.names[z])) > 1) {
adult.weights[,z] = colSums(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
} else {
adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
}
} else {
if(length(which(adultlocs[,1] == species.names[z])) > 1) {
adult.weights[,z] = sum(xdist.weighted[which(adultlocs[,1] == species.names[z]),])
} else {
adult.weights[,z] = xdist.weighted[which(adultlocs[,1] == species.names[z]),]
}
}}
return(adult.weights)
}}


# Function to add missing species names when calculating distance-wieghted abundance (add species with zero abundnace in a neighborhood to keep number of columns consistent across trees)
Add.missing.sp.names = function(test) {
names.toAdd = sp.list[which(sp.list %in% colnames(test) == F)]
test2 = data.frame(test, data.frame(matrix(0, nrow = nrow(test), ncol = length(names.toAdd))))
colnames(test2) = c(colnames(test), names.toAdd)
test2 = test2[,order(colnames(test2))]
return(test2)
}









########################################################################################################################
### DATA PREP FUNCTION -- Remember to set values for 'alpha' and 'beta' below, elim.radius set to 10 m

fd.focal.phi = list()
elim.radius = 10		# remove trees within 10 m of plot edge for survival/growth analyses (neighborhood density metrics, which have radii of 10 m, will be biased low for these individuals because we don't know what adults are outside the plot)
alpha = 1.1			# alpha parameter for distance-weighted abundance-based neighborhood metrics, DBH^alpha / exp(beta * distance), higher values weight larger-diameter trees more, 0 weights all trees evenly (i.e. abundance)
beta = 0.2			# Beta value determines the shape of the exponential decay of neighborhood effects across each 10-m radius neighborhood; 0 = no decay, higher values = stronger decay (Comita et al. 2010, Science)

sp.list

# The following code goes through the tree data, removes trees within 10 m of plot boundaries, and calculates distance-weighted abundance-based 
# neighborhood metrics for each tree using all trees >15 cm within 10 m of the focal tree.

for(q in 1:length(hja.survival.growth.data)) {
  test = hja.survival.growth.data[[q]]
  n.census = length(test)
  focal.phi.list = list()

  for(i in 2:n.census) {
    df = test[[i]]
    df$ba = (((df$DBH/100)/2)^2)*pi  		# Calculate basal area for each individual
    df$julian = as.numeric(julian(as.POSIXlt(df$SAMPLEDATE, format = "%Y-%m-%d")))
    adult.sp = tapply(df$DBH[which(df$DBH >= 15)], as.character(df$SPECIES[which(df$DBH >= 15)]), length)
    adult.sp2 = names(adult.sp)
    focal = data.frame(STANDID = df$STANDID, census = df$census, YEAR = df$YEAR, DBH = df$DBH, quad = df$quad, canopy_class = df$CANOPY_CLASS, vigor = df$TREE_VIGOR,
	uniqueID = df$uniqueID, sp = df$SPECIES, gx = df$XCOORD, gy = df$YCOORD, status = df$TREE_STATUS, dbh_code = df$DBH_CODE, julian = df$julian, min_dbh = df$MIN_DBH, notes = df$CHECK_NOTES)
    focal$sp = as.character(focal$sp)

    test.var = 1
    if(df$census[1] == 9 & df$STANDID[1] == "RS34") {test.var = 34}
    if(df$census[1] == 9 & df$STANDID[1] == "RS38") {test.var = 38}
    if(test.var == 34) {focal = focal[which(focal$gx >= 10 & focal$gx <= 190 & focal$gy >= 10 & focal$gy <= 90),]}
    if(test.var == 38) {focal = focal[which(focal$gx >= 10 & focal$gx <= 165 & focal$gy >= 10 & focal$gy <= 90),]}
    if(test.var == 1) {
      maxcol = max(as.numeric(substr(df$quad,1,2)))
      maxrow = max(as.numeric(substr(df$quad,3,4)))
      mincol = min(as.numeric(substr(df$quad,1,2)))
      minrow = min(as.numeric(substr(df$quad,3,4)))
      focal.good = focal[which(focal$quad == 9999),]
      for(k in mincol:maxcol) {
        df2 = df[which(as.numeric(substr(df$quad,1,2)) == k),]
        ymax = max(as.numeric(substr(df2$quad,3,4))) * 25
        ymin = (min(as.numeric(substr(df2$quad,3,4))) - 1) * 25
        focal.good = rbind(focal.good, focal[which(as.numeric(substr(focal$quad,1,2)) == k & focal$gy >= (ymin + elim.radius) & focal$gy <= (ymax - elim.radius)),])
      }
      focal.good2 = focal.good[which(focal.good$quad == 9999),]
      for(k in minrow:maxrow) {
        df2 = df[which(as.numeric(substr(df$quad,3,4)) == k),]
        xmax = max(as.numeric(substr(df2$quad,1,2))) * 25
        xmin = (min(as.numeric(substr(df2$quad,1,2))) - 1) * 25
        focal.good2 = rbind(focal.good2, focal.good[which(as.numeric(substr(focal.good$quad,3,4)) == k & focal.good$gx >= (xmin + elim.radius) & focal.good$gx <= (xmax - elim.radius)),])
      }
    
      focal = focal.good2
      focal$sp = as.character(focal$sp)
      if(nrow(focal) == 0) {print(paste("ERROR: No individuals within plot buffer!", "STAND", q, "census", i)); next}
      if(focal$STANDID[1] == "RS01" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 10 & focal$gx <= 40 & focal$gy >= 10 & focal$gy <= 40),]}
      if(focal$STANDID[1] == "RS02" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 35 & focal$gx <= 65 & focal$gy >= 35 & focal$gy <= 65),]}
      if(focal$STANDID[1] == "RS03" & focal$census[1] == 2) {focal = focal[which(focal$gx >= 60 & focal$gx <= 90 & focal$gy >= 60 & focal$gy <= 90),]}
    }
    focal$sp = as.character(focal$sp)
    
    # plot(df$XCOORD,df$YCOORD,asp=1)
    # points(focal$gx,focal$gy,pch=19,col="red")
    # points(focal.good2$gx,focal.good2$gy,pch=19,col="purple")
    
    df.prev = test[[i-1]]
    missing.and.found = df.prev[which(df.prev$uniqueID %in% c("RS03-12-6791", "RS21-14-45") == T & df.prev$TREE_STATUS %in% c(6,9) == T),]
    df.prev = df.prev[which(df.prev$TREE_STATUS %in% c(6,9) == F),]
    df.prev = rbind(df.prev, missing.and.found)
    df.prev$julian = as.numeric(julian(as.POSIXlt(df.prev$SAMPLEDATE, format = "%Y-%m-%d")))
    focal.prev.time = df.prev
    if(df$census[1] == 9 & df$STANDID[1] %in% c("RS34", "RS38") == T) {
    	focal.prev.time$gx = focal.prev.time$XCOORD
    	focal.prev.time$gy = focal.prev.time$YCOORD
    	focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$uniqueID %in% focal$uniqueID == T),]
    } else {
      maxcol = max(as.numeric(substr(df.prev$quad,1,2)))
      maxrow = max(as.numeric(substr(df.prev$quad,3,4)))
      mincol = min(as.numeric(substr(df.prev$quad,1,2)))
      minrow = min(as.numeric(substr(df.prev$quad,3,4)))
      focal.prev.time$gx = focal.prev.time$XCOORD
      focal.prev.time$gy = focal.prev.time$YCOORD
      focal.prev.time.good = focal.prev.time[which(focal.prev.time$quad == 9999),]
      for(k in mincol:maxcol) {
        df.prev2 = df.prev[which(as.numeric(substr(df.prev$quad,1,2)) == k),]
        ymax = max(as.numeric(substr(df.prev2$quad,3,4))) * 25
        ymin = (min(as.numeric(substr(df.prev2$quad,3,4))) - 1) * 25
        focal.prev.time.good = rbind(focal.prev.time.good, focal.prev.time[which(as.numeric(substr(focal.prev.time$quad,1,2)) == k & focal.prev.time$gy >= (ymin + elim.radius) & focal.prev.time$gy <= (ymax - elim.radius)),])
      }
      focal.prev.time.good2 = focal.prev.time.good[which(focal.prev.time.good$quad == 9999),]
      for(k in minrow:maxrow) {
        df.prev2 = df.prev[which(as.numeric(substr(df.prev$quad,3,4)) == k),]
        xmax = max(as.numeric(substr(df.prev2$quad,1,2))) * 25
        xmin = (min(as.numeric(substr(df.prev2$quad,1,2))) - 1) * 25
        focal.prev.time.good2 = rbind(focal.prev.time.good2, focal.prev.time.good[which(as.numeric(substr(focal.prev.time.good$quad,3,4)) == k & focal.prev.time.good$gx >= (xmin + elim.radius) & focal.prev.time.good$gx <= (xmax - elim.radius)),])
      }
      if(focal.prev.time$STANDID[1] == "RS01" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 10 & focal.prev.time$gx <= 40 & focal.prev.time$gy >= 10 & focal.prev.time$gy <= 40),]}
      if(focal.prev.time$STANDID[1] == "RS02" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 35 & focal.prev.time$gx <= 65 & focal.prev.time$gy >= 35 & focal.prev.time$gy <= 65),]}
      if(focal.prev.time$STANDID[1] == "RS03" & focal.prev.time$census[1] == 1) {focal.prev.time.good2 = focal.prev.time[which(focal.prev.time$gx >= 60 & focal.prev.time$gx <= 90 & focal.prev.time$gy >= 60 & focal.prev.time$gy <= 90),]}
    }
    
    # plot(df.prev$XCOORD,df.prev$YCOORD,asp=1)
    # points(focal.prev.time$gx,focal.prev.time$gy,pch=19,col="red")
    # points(focal.prev.time.good2$gx,focal.prev.time.good2$gy,pch=19,col="purple")
    
    focal.prev.time = focal.prev.time.good2[,c("uniqueID", "DBH", "SPECIES", "YEAR", "gx", "gy", "STANDID", "quad", "TREE_STATUS", "julian", "DBH_CODE", "CANOPY_CLASS", "TREE_VIGOR", "MIN_DBH")]
    names(focal.prev.time) = c("uniqueID", "DBH_prev", "sp", "YEAR_prev", "gx_prev", "gy_prev", "STANDID_prev", "quad_prev", "status_prev", "julian_prev", "dbh_code_prev", "canopy_class_prev", "vigor_prev", "min_dbh_prev")
    focal.prev.time$sp = as.character(focal.prev.time$sp)
    focal2 = merge(focal, focal.prev.time, by = c("uniqueID", "sp"), all = T)
    focal2$growth = focal2$DBH - focal2$DBH_prev
    focal2$numyr = (focal2$julian - focal2$julian_prev) / 365.25
    focal2$growth.per.yr = focal2$growth / focal2$numyr
    focal2$radial.growth.per.yr = (log(focal2$DBH/focal2$DBH_prev)) / focal2$numyr		# Relative Growth Rate per Wright et al. 2018 Ecology
    
    # plot(df$XCOORD,df$YCOORD,asp=1)
    # points(focal2$gx,focal2$gy,pch=19,col="red")
    # points(focal.good2$gx,focal.good2$gy,pch=19,col="purple")
    
    # Remove interior plot corners that are within 10 m of plot boundary (not captured in preceding code)
    if(focal2$STANDID[1] == "RS01") {if(nrow(focal2[which(focal2$gx > 40 & focal2$gx < 50 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 40 & focal2$gx < 50 & focal2$gy > 50 & focal2$gy < 60),]}}
    if(focal2$STANDID[1] == "RS03") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 40 & focal2$gy < 50),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 40 & focal2$gy < 50),]}}
    if(focal2$STANDID[1] == "RS03") {if(nrow(focal2[which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 40 & focal2$gy < 50),]) > 0) {focal2 = focal2[-which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 40 & focal2$gy < 50),]}}
    if(focal2$STANDID[1] == "RS23") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 50 & focal2$gy < 60),]}}
    if(focal2$STANDID[1] == "RS23") {if(nrow(focal2[which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 50 & focal2$gy < 60),]) > 0) {focal2 = focal2[-which(focal2$gx > 90 & focal2$gx < 100 & focal2$gy > 50 & focal2$gy < 60),]}}
    if(focal2$STANDID[1] == "RS38") {if(nrow(focal2[which(focal2$gx > 25 & focal2$gx < 35 & focal2$gy > 90 & focal2$gy < 100),]) > 0) {focal2 = focal2[-which(focal2$gx > 25 & focal2$gx < 35 & focal2$gy > 90 & focal2$gy < 100),]}}
    if(focal2$STANDID[1] == "RS38") {if(nrow(focal2[which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 115 & focal2$gy < 125),]) > 0) {focal2 = focal2[-which(focal2$gx > 50 & focal2$gx < 60 & focal2$gy > 115 & focal2$gy < 125),]}}
    
    focal2$phi = c(1)
    focal2$phi[is.na(focal2$DBH)] = 0
    focal2$phi[is.na(focal2$DBH_prev)] = NA
    focal2$gx[is.na(focal2$gx)] = focal2$gx_prev[is.na(focal2$gx)]
    focal2$gy[is.na(focal2$gy)] = focal2$gy_prev[is.na(focal2$gy)]
    focal2$quad = as.character(focal2$quad)
    focal2$quad_prev = as.character(focal2$quad_prev)
    focal2$STANDID = as.character(focal2$STANDID)
    focal2$STANDID_prev = as.character(focal2$STANDID_prev)
    focal2$quad[is.na(focal2$quad)] = focal2$quad_prev[is.na(focal2$quad)]
    focal2$STANDID[is.na(focal2$STANDID)] = focal2$STANDID_prev[is.na(focal2$STANDID)]
    focal2$census[is.na(focal2$census)] = c(unique(focal2$census[!is.na(focal2$YEAR)]))
    focal2$YEAR[is.na(focal2$YEAR)] = c(unique(focal2$YEAR[!is.na(focal2$DBH)]))
    
    # Calculate distance-based abundance metrics for neighborhood density
    adults = df[which(df$DBH >= 15),]
    adults = adults[which(adults$TREE_STATUS %in% c(6,9) == F),]
    adults.prev = df.prev[which(df.prev$DBH >= 15),]
    adults.prev = adults.prev[which(adults.prev$TREE_STATUS %in% c(6,9) == F),]
    adultlocs = data.frame(sp = adults$SPECIES, gx = adults$XCOORD, gy = adults$YCOORD, id = adults$uniqueID, dbh = adults$DBH)
    adultlocs.prev = data.frame(sp = adults.prev$SPECIES, gx = adults.prev$XCOORD, gy = adults.prev$YCOORD, id = adults.prev$uniqueID, dbh = adults.prev$DBH)
    unique.quads = unique(df$quad)
    quad.gx = c()
    quad.gy = c()
    for(z in 1:length(unique.quads)) {
      quad.gx[z] = (25*as.numeric(substr(unique.quads[z],1,2))-12.5)
      quad.gy[z] = (25*as.numeric(substr(unique.quads[z],3,4))-12.5)
    }
    quadlocs = data.frame(id = unique.quads, gx = quad.gx, gy = quad.gy)
    quad.weights.prev = dist.weighted.abund.function(adultlocs = adultlocs.prev, saplocs = quadlocs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
    quad.weights2.prev = Add.missing.sp.names(quad.weights.prev)
    if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
      quad.weights.combined = quad.weights2.prev
    } else {
      quad.weights = dist.weighted.abund.function(adultlocs = adultlocs, saplocs = quadlocs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
      quad.weights2 = Add.missing.sp.names(quad.weights)
      quad.weights.combined = (quad.weights2 + quad.weights2.prev) / 2
    }
    
    focal.phi = focal2[!is.na(focal2$DBH_prev),]
    if(nrow(focal.phi) > 0) {
      focal.phi$order = c(1:nrow(focal.phi))
      focal.phi = focal.phi[order(focal.phi$sp),]
      focal.phi.locs = data.frame(id = focal.phi$uniqueID, gx = focal.phi$gx, gy = focal.phi$gy)
      focal.phi.weights.prev = dist.weighted.abund.function(adultlocs = adultlocs.prev, saplocs = focal.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
      focal.phi.weights2.prev = Add.missing.sp.names(focal.phi.weights.prev)
      if(df$STANDID[1] %in% c("RS34", "RS38") == T & df$census[1] == 9) {
        focal.phi.weights.combined = focal.phi.weights2.prev
      } else {
        focal.phi.weights = dist.weighted.abund.function(adultlocs = adultlocs, saplocs = focal.phi.locs, fix.rad = TRUE, rad = 10, alpha = alpha, beta = beta)
        focal.phi.weights2 = Add.missing.sp.names(focal.phi.weights)
        focal.phi.weights.combined = (focal.phi.weights2 + focal.phi.weights2.prev) / 2
      }
      focal.phi = data.frame(focal.phi, focal.phi.weights.combined)
      focal.phi = focal.phi[order(focal.phi$order),]
      focal.phi.list[[i-1]] = focal.phi
    }
  }
  if(length(focal.phi.list) > 0) {
    focal.phi.list = focal.phi.list[which(lapply(focal.phi.list, function(x) {nrow(x) > 0}) == T)]
    focal.phi2 = do.call('rbind', focal.phi.list)
    focal.phi2$yr = focal.phi2$YEAR - 2000
    fd.focal.phi[[q]] = focal.phi2
  }
}




########################################
## Prepare data for analysis
yr.value = 2008
fd.focal.phi2 = do.call('rbind', fd.focal.phi)
fd.focal.phi2 = fd.focal.phi2[order(fd.focal.phi2$STANDID, fd.focal.phi2$sp, fd.focal.phi2$uniqueID, fd.focal.phi2$census),]
fd.focal.phi2$sizeclass = c(NA)
fd.focal.phi3 = split(fd.focal.phi2, as.character(fd.focal.phi2$uniqueID))

# Set sizeclasses for analysis (cutoff points based on data -- trees < 15 cm were only surveyed in subsets of some of the plots, so they are the first sizeclass,
# the other 3 size classes were determined by splitting the data above 15 cm into 3 approximately equal groups (equal number of individual trees)
for(i in 1:length(fd.focal.phi3)) {
  if(min(fd.focal.phi3[[i]]$DBH_prev) < 15 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] < 15) {fd.focal.phi3[[i]]$sizeclass = c(1)}			# Trees that stay in the 5-15 cm sizeclass
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 15 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] < 25.4) {fd.focal.phi3[[i]]$sizeclass = c(2)}		# Trees that stay in the 15-25 cm sizeclass (25.4 = 33rd percentile of DBH for all trees > 15 cm DBH)
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 25.4 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] < 52.06667) {fd.focal.phi3[[i]]$sizeclass = c(3)}	# Trees that stay in the 25-52 cm sizeclass (52.06667 = 67th percentile of DBH for all trees > 15 cm DBH)
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 52.06667) {fd.focal.phi3[[i]]$sizeclass = c(4)}														# Trees that stay in the >52 cm sizeclass
  if(min(fd.focal.phi3[[i]]$DBH_prev) < 15 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] >= 15) {									# Trees that start in the 5-15 cm sizeclass and transition to larger sizeclass
    fd.focal.phi3[[i]]$sizeclass[1:max(which(fd.focal.phi3[[i]]$DBH_prev < 15))] = 1
    fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 15))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 2
    if(max(fd.focal.phi3[[i]]$DBH_prev) >= 25.4) {fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 25.4))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 3}
    if(max(fd.focal.phi3[[i]]$DBH_prev) >= 52.06667) {fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 4}
  }
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 15 & min(fd.focal.phi3[[i]]$DBH_prev) < 25.4 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] >= 25.4) {	# Trees that start in the 15-25 cm sizeclass and transition to larger sizeclass
    fd.focal.phi3[[i]]$sizeclass[1:max(which(fd.focal.phi3[[i]]$DBH_prev < 25.4))] = 2
    fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 25.4))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 3
    if(max(fd.focal.phi3[[i]]$DBH_prev) >= 52.06667) {fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 4}
  }
  if(min(fd.focal.phi3[[i]]$DBH_prev) >= 25.4 & min(fd.focal.phi3[[i]]$DBH_prev) < 52.06667 & fd.focal.phi3[[i]]$DBH_prev[length(fd.focal.phi3[[i]]$DBH_prev)] >= 52.06667) {	# Trees that start in the 25-52 cm sizeclass and transition to larger sizeclass
    fd.focal.phi3[[i]]$sizeclass[1:max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))] = 3
    fd.focal.phi3[[i]]$sizeclass[(max(which(fd.focal.phi3[[i]]$DBH_prev < 52.06667))+1):length(fd.focal.phi3[[i]]$DBH_prev)] = 4
  }
}
fd.focal.phi4 = do.call('rbind', fd.focal.phi3)
fd.focal.grow5 = merge(fd.focal.phi4, standclimate, by = "STANDID", all.x = T)
fd.focal.grow5 = fd.focal.grow5[which(fd.focal.grow5$phi == 1),]
fd.focal.grow5 = fd.focal.grow5[!is.na(fd.focal.grow5$growth.per.yr),]
fd.focal.grow5$yr2 = fd.focal.grow5$YEAR - yr.value
fd.focal.grow5$conspp = c(NA)
fd.focal.grow5$allspp = c(NA)
fd.focal.grow5$heterospp = c(NA)
adult.cols = which(colnames(fd.focal.grow5) %in% sp.list == T)
# Sum conspecific and heterospecific local densities across species in each neighborhood
for(i in 1:nrow(fd.focal.grow5)) {
  fd.focal.grow5$conspp[i] = fd.focal.grow5[i,which(colnames(fd.focal.grow5) == fd.focal.grow5$sp[i])]
  fd.focal.grow5$allspp[i] = sum(fd.focal.grow5[i,adult.cols])
  fd.focal.grow5$heterospp[i] = sum(fd.focal.grow5[i,adult.cols[which(colnames(fd.focal.grow5[,adult.cols]) != fd.focal.grow5$sp[i])]])
}
fd.focal.grow5 = fd.focal.grow5[which(fd.focal.grow5$census < 9),]			# Remove census 9 (mortality checks only conducted in a small subset of plots)
fd.focal.grow5 = fd.focal.grow5[which(fd.focal.grow5$dbh_code == "G"),]			# Remove trees where measurements were not considered accurate
fd.focal.grow5 = fd.focal.grow5[which(fd.focal.grow5$dbh_code_prev == "G"),]		# Remove trees where measurements were not considered accurate
fd.focal.grow6 = fd.focal.grow5

# Measurements removed due to sloughing bark or tags falling off tree
fd.focal.grow6$growth.per.yr[which(fd.focal.grow6$uniqueID == "RS28-11-4200" & fd.focal.grow6$YEAR == 1983)] = NA
adult.growth.update = read.csv("HJA_RefStands_Adult_negGrowth_Checks_20200807update.csv", header = T)
adult.growth.update = adult.growth.update[,c("uniqueID", "YEAR", "growth.update")]
adult.growth.update = adult.growth.update[which(adult.growth.update$growth.update == 1),]
sap.growth.update = read.csv("HJA_RefStands_Sap_negGrowth_Checks.csv", header = T)
sap.growth.update = sap.growth.update[,c("uniqueID", "YEAR", "growth.update")]
sap.growth.update = sap.growth.update[which(sap.growth.update$growth.update == 1),]
focal.growth.update = rbind(sap.growth.update, adult.growth.update)
fd.focal.grow7 = fd.focal.grow6
for(i in 1:nrow(focal.growth.update)) {fd.focal.grow7$growth.per.yr[which(fd.focal.grow7$uniqueID == as.character(focal.growth.update$uniqueID[i]) & fd.focal.grow7$YEAR == focal.growth.update$YEAR[i])] = NA}
fd.focal.grow7 = fd.focal.grow7[!is.na(fd.focal.grow7$growth.per.yr),]









#############################################################################################
### LMER Analysis for large-tree growth 
### (use data to estimate values of 'alpha' (abundance-weighting parameter), 'beta' (distance-dependence parameter), and 'D' (the nonlinearity parameter)

d = fd.focal.grow7[order(fd.focal.grow7$uniqueID, fd.focal.grow7$census),]
d = d[which(d$sizeclass == 2),]	# Trees in the 15-25 cm sizeclass

d = d[order(d$uniqueID,d$census),]
d$ID = as.character(d$uniqueID)
growth = c(scale(log(d$growth.per.yr+1)))

uniID = as.numeric(factor(d$uniqueID))
consppid = tapply(d$conspp, uniID, mean)		# Mean conspecific density across individuals
heterosppid = tapply(d$heterospp, uniID, mean)	# Mean heterospecific density across individuals

# Test different values of D (nonlinearity parameter), make sure con- and heterospecific densities are scaled together, so a 1-unit change in one is equivalent to a 1-unit change in the other
conhetero1 = c(consppid^(0.1), heterosppid^(0.1))	# Collective mean across all con- and heterospecific densities trasnformed with D = 0.1
rtconspp1 = ((d$conspp^(0.1)) - mean(conhetero1)) / sd(conhetero1)	# Scaled conspecific densities
rtheterospp1 = ((d$heterospp^(0.1)) - mean(conhetero1)) / sd(conhetero1)	# Scaled heterospecific densities
conhetero2 = c(consppid^(0.2), heterosppid^(0.2))	# Mean across all con- and heterospecific densities trasnformed with D = 0.2
rtconspp2 = ((d$conspp^(0.2)) - mean(conhetero2)) / sd(conhetero2)
rtheterospp2 = ((d$heterospp^(0.2)) - mean(conhetero2)) / sd(conhetero2)
conhetero4 = c(consppid^(0.4), heterosppid^(0.4))	# Mean across all con- and heterospecific densities trasnformed with D = 0.4
rtconspp4 = ((d$conspp^(0.4)) - mean(conhetero4)) / sd(conhetero4)
rtheterospp4 = ((d$heterospp^(0.4)) - mean(conhetero4)) / sd(conhetero4)
conhetero5 = c(consppid^(0.5), heterosppid^(0.5))	# Mean across all con- and heterospecific densities trasnformed with D = 0.5
rtconspp5 = ((d$conspp^(0.5)) - mean(conhetero5)) / sd(conhetero5)
rtheterospp5 = ((d$heterospp^(0.5)) - mean(conhetero5)) / sd(conhetero5)
conhetero6 = c(consppid^(0.6), heterosppid^(0.6))	# Mean across all con- and heterospecific densities trasnformed with D = 0.6
rtconspp6 = ((d$conspp^(0.6)) - mean(conhetero6)) / sd(conhetero6)
rtheterospp6 = ((d$heterospp^(0.6)) - mean(conhetero6)) / sd(conhetero6)
conhetero7 = c(consppid^(0.7), heterosppid^(0.7))	# Mean across all con- and heterospecific densities trasnformed with D = 0.7
rtconspp7 = ((d$conspp^(0.7)) - mean(conhetero7)) / sd(conhetero7)
rtheterospp7 = ((d$heterospp^(0.7)) - mean(conhetero7)) / sd(conhetero7)
conhetero8 = c(consppid^(0.8), heterosppid^(0.8))	# Mean across all con- and heterospecific densities trasnformed with D = 0.8
rtconspp8 = ((d$conspp^(0.8)) - mean(conhetero8)) / sd(conhetero8)
rtheterospp8 = ((d$heterospp^(0.8)) - mean(conhetero8)) / sd(conhetero8)
conhetero10 = c(consppid^(1.0), heterosppid^(1.0))	# Mean across all con- and heterospecific densities trasnformed with D = 1.0
rtconspp10 = ((d$conspp^(1.0)) - mean(conhetero10)) / sd(conhetero10)
rtheterospp10 = ((d$heterospp^(1.0)) - mean(conhetero10)) / sd(conhetero10)
conhetero20 = c(consppid^(2.0), heterosppid^(2.0))	# Mean across all con- and heterospecific densities trasnformed with D = 2.0
rtconspp20 = ((d$conspp^(2.0)) - mean(conhetero20)) / sd(conhetero20)
rtheterospp20 = ((d$heterospp^(2.0)) - mean(conhetero20)) / sd(conhetero20)
conhetero30 = c(consppid^(3.0), heterosppid^(3.0))	# Mean across all con- and heterospecific densities trasnformed with D = 3.0
rtconspp30 = ((d$conspp^(3.0)) - mean(conhetero30)) / sd(conhetero30)
rtheterospp30 = ((d$heterospp^(3.0)) - mean(conhetero30)) / sd(conhetero30)

elevid = tapply(d$ELEVATION, uniID, mean)			# Mean Elevation across individuals (Elevation not used in first modeling step below)
dbhid = tapply(d$DBH_prev, uniID, mean)			# Mean DBH across individuals
yrid = tapply(d$julian_prev/365.25, uniID, mean)	# Census year
ELEV = (d$ELEVATION - mean(elevid)) / sd(elevid)	# Scaled Elevation (not used in first modeling step below)
dbh = (d$DBH_prev - mean(dbhid)) / sd(dbhid)		# Scaled DBH
yr = ((d$julian_prev/365.25) - mean(yrid)) / sd(yrid)	# Scaled census year
yr2 = yr^2								# census year squared
census = as.numeric(as.character(factor(as.character(d$census)))) - 1		# Census number (different from 'tinterval', all trees surveyed at the same timeframe (within a few years) receive the same value for census, but 'tinterval' depends on each individual tree and when they were first surveyed
sp = as.numeric(factor(as.character(d$sp)))			# unique numeric value for each species
sp.info = unique(data.frame(sp.name = d$sp, sp = sp))		# information table with each species' code
plotsp = as.numeric(factor(as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID)))))		# unique ID for each plot-by-species combination
plotsp.info = unique(data.frame(sp = d$sp, plot = d$STANDID, combo = as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID))), plotELEV = ELEV, plotsp = plotsp))	# 'plotsp' key
plotcen = as.numeric(factor(as.character(factor(as.character(d$STANDID)):factor(as.character(d$census)))))		# Unique ID for each plot-by-census combination
plotcen.info = unique(data.frame(yr = d$census, plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID)):factor(as.character(d$census))), plotELEV = ELEV, census = plotcen))	# 'plotcen' key
n.census = length(unique(census))	# number of censuses
n.ID = length(unique(uniID))		# number of unique individuals
n = nrow(d)					# number of observations
spINplot = plotsp.info$sp[order(plotsp.info$plotsp)]
plotELEV = plotsp.info$plotELEV[order(plotsp.info$plotsp)]
plotnum = as.numeric(factor(as.character(factor(as.character(d$STANDID)))))	# numeric ID for each plot
plot.info = unique(data.frame(plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID))), plotELEV = ELEV, plotnum = plotnum))	# 'plotnum' key


# Ues data to test for optimal values of alpha (size-dependence parameter), beta (distance-dependence parameter), and D (nonlinearity parameter)

adult.off.abs.growth.m1 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp1 + rtheterospp1 + dbh:rtconspp1 + dbh:rtheterospp1 +
	(rtconspp1 + rtheterospp1|sp) + (rtconspp1 + rtheterospp1|plotnum) + (rtconspp1 + rtheterospp1|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m1)

adult.off.abs.growth.m2 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp2 + rtheterospp2 + dbh:rtconspp2 + dbh:rtheterospp2 +  
	(rtconspp2 + rtheterospp2|sp) + (rtconspp2 + rtheterospp2|plotnum) + (rtconspp2 + rtheterospp2|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m2)

adult.off.abs.growth.m4 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp4 + rtheterospp4 + dbh:rtconspp4 + dbh:rtheterospp4 + 
	(rtconspp4 + rtheterospp4|sp) + (rtconspp4 + rtheterospp4|plotnum) + (rtconspp4 + rtheterospp4|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m4)

adult.off.abs.growth.m5 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp5 + rtheterospp5 + dbh:rtconspp5 + dbh:rtheterospp5 + 
	(rtconspp5 + rtheterospp5|sp) + (rtconspp5 + rtheterospp5|plotnum) + (rtconspp5 + rtheterospp5|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m5)

adult.off.abs.growth.m6 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp6 + rtheterospp6 + dbh:rtconspp6 + dbh:rtheterospp6 + 
	(rtconspp6 + rtheterospp6|sp) + (rtconspp6 + rtheterospp6|plotnum) + (rtconspp6 + rtheterospp6|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m6)

adult.off.abs.growth.m7 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp7 + rtheterospp7 + dbh:rtconspp7 + dbh:rtheterospp7 +  
	(rtconspp7 + rtheterospp7|sp) + (rtconspp7 + rtheterospp7|plotnum) + (rtconspp7 + rtheterospp7|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m7)

adult.off.abs.growth.m8 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp8 + rtheterospp8 + dbh:rtconspp8 + dbh:rtheterospp8 + 
	(rtconspp8 + rtheterospp8|sp) + (rtconspp8 + rtheterospp8|plotnum) + (rtconspp8 + rtheterospp8|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m8)

adult.off.abs.growth.m10 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp10 + rtheterospp10 + dbh:rtconspp10 + dbh:rtheterospp10 + 
	(rtconspp10 + rtheterospp10|sp) + (rtconspp10 + rtheterospp10|plotnum) + (rtconspp10 + rtheterospp10|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m10)

adult.off.abs.growth.m20 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp20 + rtheterospp20 + dbh:rtconspp20 + dbh:rtheterospp20 + 
	(rtconspp20 + rtheterospp20|sp) + (rtconspp20 + rtheterospp20|plotnum) + (rtconspp20 + rtheterospp20|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m20)

adult.off.abs.growth.m30 = lme4::lmer(growth ~ dbh + yr + yr2 + rtconspp30 + rtheterospp30 + dbh:rtconspp30 + dbh:rtheterospp30 + 
	(rtconspp30 + rtheterospp30|sp) + (rtconspp30 + rtheterospp30|plotnum) + (rtconspp30 + rtheterospp30|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(adult.off.abs.growth.m30)

anova(adult.off.abs.growth.m1, adult.off.abs.growth.m2, adult.off.abs.growth.m4, adult.off.abs.growth.m5, 
	adult.off.abs.growth.m6, adult.off.abs.growth.m7, adult.off.abs.growth.m8, adult.off.abs.growth.m10, adult.off.abs.growth.m20, adult.off.abs.growth.m30)
alpha
beta





# Test against model that does not differentiate btw conspecific and heterospecific density effects:
rtallspp7 = c(scale(d$allspp^(0.7)))
adult.off.abs.growth.m7a = lme4::lmer(growth ~ dbh + yr + yr2 + rtallspp7 + dbh:rtallspp7 +  
	(rtallspp7|sp) + (rtallspp7|plotnum) + (rtallspp7|plotsp) + (1|plotcen) + (1|uniID), REML = F, 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
anova(adult.off.abs.growth.m7a, adult.off.abs.growth.m7)







######################################
### GOODNESS OF FIT TESTS

# Residual plots
m1 = update(adult.off.abs.growth.m7, REML = T)
m1.noreml = adult.off.abs.growth.m7
conspp = rtconspp7
heterospp = rtheterospp7

plot(predict(m1), resid(m1, type = "pearson"))
plot(conspp, resid(m1, type = "pearson"), xlab = "Conspecific BA")
plot(heterospp, resid(m1, type = "pearson"), xlab = "Heterospecific BA")
plot(dbh, resid(m1, type = "pearson"), xlab = "DBH")
plot(yr, resid(m1, type = "pearson"), xlab = "DBH")
plot(yr2, resid(m1, type = "pearson"), xlab = "DBH2")
plot(ELEV, resid(m1, type = "pearson"), xlab = "Elevation")
plot(resid(m1, type = "pearson") ~ factor(plotcen))
plot(resid(m1, type = "pearson") ~ factor(sp))
plot(resid(m1, type = "pearson") ~ factor(plotsp))
plot(resid(m1, type = "pearson") ~ factor(ELEV))













#######################################################################################
### BAYESIAN MODEL OF ADULT GROWTH	

d = fd.focal.grow7[order(fd.focal.grow7$uniqueID, fd.focal.grow7$census),]
d = d[which(d$sizeclass == 2),]	# Trees in the 15-25 cm sizeclass

DenExp = 0.7		# D parameter (nonlinearity parameter selected during LMER analysis above)

d = d[order(d$uniqueID,d$census),]

# Prepare data for analysis (for description of variables, please see annotated LMER data set-up code above)
d$ID = as.character(d$uniqueID)
uniID = as.numeric(factor(d$uniqueID))
consppid = tapply(d$conspp, uniID, mean)
heterosppid = tapply(d$heterospp, uniID, mean)
growth = c(scale(log(d$growth.per.yr+1)))

conhetero = c(consppid^(DenExp), heterosppid^(DenExp))
conspp = ((d$conspp^(DenExp)) - mean(conhetero)) / sd(conhetero)
heterospp = ((d$heterospp^(DenExp)) - mean(conhetero)) / sd(conhetero)

elevid = tapply(d$ELEVATION, uniID, mean)
dbhid = tapply(d$DBH_prev, uniID, mean)
yrid = tapply(d$julian_prev/365.25, uniID, mean)
ELEV = (d$ELEVATION - mean(elevid)) / sd(elevid)
dbh = (d$DBH_prev - mean(dbhid)) / sd(dbhid)
yr = ((d$julian_prev/365.25) - mean(yrid)) / sd(yrid)
yr2 = yr^2
census = as.numeric(as.character(factor(as.character(d$census)))) - 1
sp = as.numeric(factor(as.character(d$sp)))
sp.info = unique(data.frame(sp.name = d$sp, sp = sp))
plotsp = as.numeric(factor(as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID)))))
plotsp.info = unique(data.frame(sp = d$sp, plot = d$STANDID, combo = as.character(factor(as.character(d$sp)):factor(as.character(d$STANDID))), plotELEV = ELEV, plotsp = plotsp))
plotcen = as.numeric(factor(as.character(factor(as.character(d$STANDID)):factor(as.character(d$census)))))
plotcen.info = unique(data.frame(yr = d$census, plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID)):factor(as.character(d$census))), plotELEV = ELEV, census = plotcen))
uniID = as.numeric(factor(d$uniqueID))
n.census = length(unique(census))
n.ID = length(unique(uniID))
n.plotcen = length(unique(plotcen))
plotnum = as.numeric(factor(as.character(factor(as.character(d$STANDID)))))
plot.info = unique(data.frame(plot = d$STANDID, combo = as.character(factor(as.character(d$STANDID))), plotELEV = ELEV, plotnum = plotnum))
n = nrow(d)
x = cbind(rep(1,times = n), dbh, yr, yr2, conspp, heterospp, conspp*dbh, heterospp*dbh)
K = ncol(x)
PX = cbind(rep(1,times = n), conspp, heterospp)
PK = ncol(PX)
PJ = length(unique(plotsp))
RX = cbind(rep(1,times = n), conspp, heterospp)
RK = ncol(RX)
RJ = length(unique(plotnum))
SX = cbind(rep(1,times = n), conspp, heterospp)
SK = ncol(SX)
SJ = length(unique(sp))
spINplot = plotsp.info$sp[order(plotsp.info$plotsp)]
plotELEV = plotsp.info$plotELEV[order(plotsp.info$plotsp)]


# Split data for censored regression (many zeros that are likely negative growth)

U = unique(growth[which(d$growth.per.yr == 0)])		# censor point

nonzero = which(growth != U)
zeros = which(growth == U)
growth.nonzero = growth[nonzero]
x.nonzero = x[nonzero,]
PX.nonzero = PX[nonzero,]
RX.nonzero = RX[nonzero,]
SX.nonzero = SX[nonzero,]
plotsp.nonzero = plotsp[nonzero]
plotnum.nonzero = plotnum[nonzero]
sp.nonzero = sp[nonzero]
uniID.nonzero = uniID[nonzero]
plotcen.nonzero = plotcen[nonzero]
yr.nonzero = yr[nonzero]
n.nonzero = length(growth.nonzero)

growth.zeros = growth[zeros]
x.zeros = x[zeros,]
PX.zeros = PX[zeros,]
RX.zeros = RX[zeros,]
SX.zeros = SX[zeros,]
plotsp.zeros = plotsp[zeros]
plotnum.zeros = plotnum[zeros]
sp.zeros = sp[zeros]
uniID.zeros = uniID[zeros]
plotcen.zeros = plotcen[zeros]
yr.zeros = yr[zeros]
n.zeros = length(growth.zeros)


# Bundle data
dat <- list(y = growth.nonzero, x = x.nonzero, xZ = x.zeros, K = K, plotsp = plotsp.nonzero, plotnum = plotnum.nonzero, sp = sp.nonzero, uniID = uniID.nonzero, census = plotcen.nonzero, yr = yr.nonzero,  
	ncensus = n.plotcen, PJ = PJ, PK = PK, PX = PX.nonzero, RJ = RJ, RK = RK, RX = RX.nonzero, SJ = SJ, SK = SK, SX = SX.nonzero, nID = n.ID, N = n.nonzero, U = U, 
	plotspZ = plotsp.zeros, plotnumZ = plotnum.zeros, spZ = sp.zeros, uniIDZ = uniID.zeros, censusZ = plotcen.zeros, yrZ = yr.zeros, PXZ = PX.zeros, RXZ = RX.zeros, SXZ = SX.zeros, NZ = n.zeros)

# LMER model with ML for ranef variance estimates (once run, comment off with #)
set.seed(314)
m1 = lme4::lmer(growth ~ dbh + yr + yr2 + conspp + heterospp + conspp:dbh + heterospp:dbh + 
	(conspp + heterospp|sp) + (conspp + heterospp|plotnum) + (conspp + heterospp|plotsp) + (1|uniID) + (1|plotcen), 
	control=lmerControl(optimizer='bobyqa',optCtrl=list(maxfun=2e6)))
summary(m1)



### Fit stan model 
# HMC Parameters
nchains = 5
postburn = 4000
burnin = 500
its = postburn + burnin
thin = 10					
hmc_seed = 55406

# Initial values from LMER model
vc <- VarCorr(m1)
sigma_SB_lmer = as.matrix(Matrix::bdiag(vc$sp))
sigma_PB_lmer = as.matrix(Matrix::bdiag(vc$plotsp))
sigma_RB_lmer = as.matrix(Matrix::bdiag(vc$plotnum))
inits <- replicate(nchains, list(
  Pz = t(data.matrix(ranef(m1)$'plotsp')),
  PL_Omega = sigma_PB_lmer,
  Ptau_unif = runif(PK),
  Rz = t(data.matrix(ranef(m1)$'plotnum')),
  RL_Omega = sigma_RB_lmer,
  Rtau_unif = runif(RK),
  Sz = t(data.matrix(ranef(m1)$'sp')),
  SL_Omega = sigma_SB_lmer,
  Stau_unif = runif(SK),
  beta = fixef(m1),
  sigma_ID = attr(summary(m1)$varcor$uniID,"stddev")[[1]], 
  uniqueID = ranef(m1)$'uniID'[[1]], 
  sigma_YEAR = attr(summary(m1)$varcor$plotcen,"stddev")[[1]],
  YEAR = ranef(m1)$'plotcen'[[1]], 
  PB = data.matrix(ranef(m1)$'plotsp'), 
  sigma_PB = sigma_PB_lmer, 
  Ptau = runif(PK), 
  RB = data.matrix(ranef(m1)$'plotnum'), 
  sigma_RB = sigma_RB_lmer, 
  Rtau = runif(RK), 
  SB = data.matrix(ranef(m1)$'sp'), 
  sigma_SB = sigma_SB_lmer, 
  Stau = runif(SK),
  sigma_res = summary(m1)$sigma, 
  yZ = rep(1.1*U, times = n.zeros)
), simplify = F)


# Run model
begin = Sys.time()
fit <- stan(file = "HJA_GLMM_CENSORED_Growth_Model.stan", 					# Stan model
  data = dat,   										# named list of data
  init = inits,											# initial values for parameters
  chains = nchains,             								# number of Markov chains
  warmup = burnin,          									# number of warmup iterations per chain
  iter = its,            									# total number of iterations per chain
  cores = nchains,              								# number of cores (could use one per chain)
  thin = thin,
  seed = hmc_seed,
  control = list(adapt_delta = 0.99, max_treedepth = 15)
  )
end = Sys.time()
(duration = end - begin)

# save(fit, file = "HJA_15to25cmDBH_Growth_Bayesian_alpha1-1_beta0-2_exp0-7_censored_STAN_20210912.RData")

# load("HJA_15to25cmDBH_Growth_Bayesian_alpha1-1_beta0-2_exp0-7_censored_STAN_20210912.RData")



# Extract estimates 
draws <- extract(fit, permuted = FALSE)
beta.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "beta")])),3,c)
SB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "SB")])),3,c)
SB.m = array(SB.m, dim = c(nrow(SB.m),SJ,SK), dimnames = list(paste("it",c(1:nrow(SB.m)),sep=""),paste("sp",c(1:SJ),sep=""),paste("SB",c(1:SK),sep="")))
PB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "PB")])),3,c)
PB.m = array(PB.m, dim = c(nrow(PB.m),PJ,PK), dimnames = list(paste("it",c(1:nrow(PB.m)),sep=""),paste("plotsp",c(1:PJ),sep=""),paste("PB",c(1:PK),sep="")))
RB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,2) == "RB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "RB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "RB")])),3,c)
RB.m = array(RB.m, dim = c(nrow(RB.m),RJ,RK), dimnames = list(paste("it",c(1:nrow(RB.m)),sep=""),paste("plotsp",c(1:RJ),sep=""),paste("RB",c(1:RK),sep="")))
census.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")])),3,c)
plotcen.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,4) == "YEAR")])),3,c)
sigmaSB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_SB")])),3,c)
sigmaPB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_PB")])),3,c)
sigmaRB.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_RB")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_RB"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "sigma_RB")])),3,c)
sigmaYR.m = c(draws[,,"sigma_YEAR"])
sigmaID.m = c(draws[,,"sigma_ID"])
sigmaRES.m = c(draws[,,"sigma_res"])
yZ.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,2) == "yZ")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,2) == "yZ"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,2) == "yZ")])),3,c)
ID.m = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,8) == "uniqueID")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,8) == "uniqueID"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,8) == "uniqueID")])),3,c)

fittedvalues = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,6) == "fitted")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,6) == "fitted"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,6) == "fitted")])),3,c)
fittedvaluesZ = apply(array(draws[,,which(substr(attributes(draws)$dimnames$parameters,1,7) == "fittedZ")], dim = c((dim(draws)[1]), dim(draws)[2], length(which(substr(attributes(draws)$dimnames$parameters,1,7) == "fittedZ"))),dimnames = list(c(),c(),attributes(draws)$dimnames$parameters[which(substr(attributes(draws)$dimnames$parameters,1,7) == "fittedZ")])),3,c)

# Estimates
t(apply(beta.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(beta.m,2,mean)
t(apply(sigmaSB.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(sigmaSB.m,2,mean)
t(apply(sigmaPB.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(sigmaPB.m,2,mean)
t(apply(sigmaRB.m,2,quantile,c(0.025,0.975,0.05,0.95,0.5))); apply(sigmaRB.m,2,mean)
quantile(sigmaYR.m^2,c(0.025,0.975,0.05,0.95,0.5)); mean(sigmaYR.m^2)
quantile(sigmaID.m^2,c(0.025,0.975,0.05,0.95,0.5)); mean(sigmaID.m^2)
quantile(sigmaRES.m^2,c(0.025,0.975,0.05,0.95,0.5)); mean(sigmaRES.m^2)









# Posterior point-wise log-likelihoods
Z = length(sigmaYR.m)
fitted.m = matrix(NA,nrow=Z,ncol=n)
log_lik = matrix(NA,nrow=Z,ncol=n)
res = matrix(NA,nrow=Z,ncol=n)
for(z in 1:Z) {
  SBbysp = matrix(NA,nrow=n,ncol=SK)
  for(i in 1:n) {SBbysp[i,] = SB.m[z,sp[i],]}
  RBbyplotsp = matrix(NA,nrow=n,ncol=RK)
  for(i in 1:n) {RBbyplotsp[i,] = RB.m[z,plotnum[i],]}
  PBbyplotsp = matrix(NA,nrow=n,ncol=PK)
  for(i in 1:n) {PBbyplotsp[i,] = PB.m[z,plotsp[i],]}
  IDbyind = c()
  for(i in 1:n) {IDbyind[i] = ID.m[z,uniID[i]]}
  YRbycensus = c()
  for(i in 1:n) {YRbycensus[i] = census.m[z,plotcen[i]]}
  fitted.m[z,] = (x %*% beta.m[z,]) + rowSums(SX*SBbysp) + rowSums(RX*RBbyplotsp) + rowSums(PX*PBbyplotsp) + IDbyind + YRbycensus
  for(i in 1:length(growth)) {
    if(growth[i] != U) {log_lik[z,i] = dnorm(growth[i], mean = fitted.m[z,i], sd = sigmaRES.m[z], log = T)}
    if(growth[i] == U) {log_lik[z,i] = pnorm(growth[i], mean = fitted.m[z,i], sd = sigmaRES.m[z], log = T)}
  }
  growth.wcens = growth
  growth.wcens[zeros] = yZ.m[z,]
  res[z,] = growth.wcens - fitted.m[z,]
}
loglik.m = rowSums(log_lik)
dev.m = rowSums(log_lik)*-2


# Approximate leave-one-out fit metrics
library(loo)
begin = Sys.time()
r_eff <- relative_eff(exp(log_lik), chain_id = rep(1:5,each=400), cores = 5)
loo_1 <- loo(log_lik, r_eff = r_eff, cores = 5)
end = Sys.time()
(duration = end - begin)
print(loo_1)


# save(loo_1, file = "HJA_Growth_15to25cmDBH_LOO_regular.RData")
load("HJA_Growth_15to25cmDBH_LOO_regular.RData")
loo_base = loo_1

# Comparison to model with DBH random slopes at the species level
load("HJA_Growth_15to25cmDBH_LOO_DBHre.RData")
# ELPD
sum(loo_base$pointwise[,1] - loo_1$pointwise[,1])		# Difference in ELPD between models (ELPD diff = -42.03799, DBHre model better fit)
sqrt(n*var(loo_base$pointwise[,1] - loo_1$pointwise[,1]))	# SE of difference in ELPD		(SE of diff = 9.172084, nearly 5 SE btw the models)
# LOOic
sum(loo_base$pointwise[,4] - loo_1$pointwise[,4])		# Difference in ELPD between models (ELPD diff = 84.07598, DBHre model slightly better fit)
sqrt(n*var(loo_base$pointwise[,4] - loo_1$pointwise[,4]))	# SE of difference in ELPD		(SE of diff = 18.34417, but models within 2 SE of each other)

# Comparision to model with separate heterospecific effects (heterospecific effects split into confamilial and heterofamilial effects)
# ELPD
load("HJA_Growth_15to25cmDBH_LOO_confam.RData")
sum(loo_base$pointwise[,1] - loo_1$pointwise[,1])		# Difference in ELPD between models	(ELPD diff = -2.715597, sep hetero effects model slightly better fit)
sqrt(n*var(loo_base$pointwise[,1] - loo_1$pointwise[,1]))	# SE of difference in ELPD		(SE of diff = 4.585266, but models are within 1 SE of each other)
# LOOic
sum(loo_base$pointwise[,4] - loo_1$pointwise[,4])		# Difference in ELPD between models (ELPD diff = 5.431195, DBHre model slightly better fit)
sqrt(n*var(loo_base$pointwise[,4] - loo_1$pointwise[,4]))	# SE of difference in ELPD		(SE of diff = 9.170532, but models within 2 SE of each other)












